#!/usr/bin/env python3
"""Validate the bounded post-v5 model-comparison bundle.

This validator checks hashes, table relationships, thresholds, and the stated
interpretation. It deliberately does not refit the models or constitute a
second adversarial audit.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
CANDIDATE = HERE / "candidate" / "post_v5_corrected_successor_675"
OUT = CANDIDATE / "results" / "post_v5_model_comparison_v1"
SUMMARY = OUT / "MODEL_COMPARISON_SUMMARY.json"
MANIFEST = OUT / "RESULTS_MANIFEST.json"
SUBSPACE = OUT / "subspace_metrics.csv"
VALIDATION = OUT / "MODEL_COMPARISON_VALIDATION.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def as_bool(value: str) -> bool:
    if value not in {"True", "False"}:
        raise RuntimeError(f"invalid serialized boolean: {value!r}")
    return value == "True"


def validate() -> dict[str, object]:
    summary = json.loads(SUMMARY.read_text(encoding="utf-8"))
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    patch_summary = json.loads((HERE / "CELL_PATCH_SUMMARY.json").read_text(encoding="utf-8"))
    candidate_manifest = json.loads((CANDIDATE / "candidate_manifest.json").read_text(encoding="utf-8"))

    if patch_summary["patched_cells"] != 117 or patch_summary["patched_events"] != 9:
        raise RuntimeError("adjudicated patch count differs")
    if candidate_manifest["active_events"] != 675 or candidate_manifest["corpus_rows"] != 748:
        raise RuntimeError("candidate roster count differs")
    if candidate_manifest["applied_cell_patches"] != 117:
        raise RuntimeError("candidate patch count differs")

    for relative, expected in manifest["input_sha256"].items():
        path = ROOT / relative
        if sha256(path) != expected:
            raise RuntimeError(f"input hash differs: {relative}")
    for name, expected in manifest["output_sha256"].items():
        path = OUT / name
        if sha256(path) != expected:
            raise RuntimeError(f"output hash differs: {name}")

    expected_rows = {
        "core_scenario_metrics.csv": 5,
        "factor_metrics.csv": 40,
        "weighting_metrics.csv": 3,
        "missingness_metrics.csv": 7,
        "imputation_metrics.csv": 4,
        "corrected_event_influence.csv": 9,
        "subspace_metrics.csv": 28,
    }
    for name, expected in expected_rows.items():
        actual = len(rows(OUT / name))
        if actual != expected:
            raise RuntimeError(f"row count differs for {name}: {actual} != {expected}")

    subspaces = rows(SUBSPACE)
    categories = Counter(row["category"] for row in subspaces)
    expected_categories = {
        "core_scenario": 5,
        "weighting": 3,
        "missingness_subset": 7,
        "imputation": 4,
        "corrected_event_influence": 9,
    }
    if dict(categories) != expected_categories:
        raise RuntimeError(f"subspace category counts differ: {dict(categories)}")
    corrected = next(
        row for row in subspaces
        if row["category"] == "core_scenario"
        and row["scenario"] == "corrected_successor_675"
    )
    if corrected["reference"] != "immutable_v5_676" or int(corrected["events"]) != 675:
        raise RuntimeError("corrected subspace comparator differs")
    angle8 = float(corrected["factor_8_maximum_principal_angle_degrees"])
    angle9 = float(corrected["factor_9_maximum_principal_angle_degrees"])
    if as_bool(corrected["factor_8_angle_above_5_degrees"]) != (angle8 > 5.0):
        raise RuntimeError("eight-factor angle flag differs")
    if as_bool(corrected["factor_9_angle_above_5_degrees"]) != (angle9 > 5.0):
        raise RuntimeError("nine-factor angle flag differs")
    if not (angle8 > 5.0 and angle9 <= 5.0):
        raise RuntimeError("expected eight/nine boundary pattern is absent")

    if summary["base_factor_count_recomputed"] != 9 or summary["corrected_factor_count"] != 9:
        raise RuntimeError("factor count differs")
    if summary["corrected_vs_v5"]["mode"] != "one_retirement_plus_117_cell_corrections":
        raise RuntimeError("corrected scenario label differs")
    if not summary["corrected_vs_v5"]["material_flag_vs_v5"]:
        raise RuntimeError("forced-eight warning was silently cleared")
    if summary["corrected_interpretation"] != "stable_nine_factor_subspace_with_forced_eight_axis_rotation":
        raise RuntimeError("subspace interpretation differs")
    if summary["individually_material_corrected_events"]:
        raise RuntimeError("unexpected individually material corrected event")
    if any(summary[key] for key in (
        "candidate_activation_authorized",
        "release_authorized",
        "atlas_change_authorized",
        "deployment_authorized",
    )):
        raise RuntimeError("diagnostic bundle grants downstream authority")

    result: dict[str, object] = {
        "schema": "post-v5-bounded-model-comparison-validation-v1",
        "status": "pass",
        "scope": "hashes_table_relationships_thresholds_and_interpretation_not_model_refit",
        "candidate_active_events": 675,
        "adjudicated_cell_patches": 117,
        "base_factor_count": 9,
        "corrected_factor_count": 9,
        "eight_factor_maximum_principal_angle_degrees": angle8,
        "nine_factor_maximum_principal_angle_degrees": angle9,
        "interpretation": summary["corrected_interpretation"],
        "candidate_activation_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    return result


def main() -> None:
    result = validate()
    VALIDATION.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
