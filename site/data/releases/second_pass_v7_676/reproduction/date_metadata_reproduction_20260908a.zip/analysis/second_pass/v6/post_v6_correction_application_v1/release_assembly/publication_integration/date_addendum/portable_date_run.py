#!/usr/bin/env python3
"""Two-event metadata addendum: reuse bound fits, compute affected branches only.

The old 565-scenario run is an immutable historical record. This additive
result contains exact scenario dispositions, amended date diagnostics and
two new matrix fits, not a relabeled or overwritten historical run.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PUB = HERE.parent
POST = PUB.parents[1]
ROOT = next(p for p in HERE.parents if (p / '.git').exists())
EXEC = POST / 'model_execution_v1'
sys.path.insert(0, str(EXEC))
sys.path.insert(0, str(PUB))

import numpy as np
import pandas as pd
import portable_date_fields as application
from inputs import Reader, load_contract, require, validate_dataset
from numerics import helpers, digest, SEED
from resume_cache import ResumeCache, json_bytes, pack, unpack, parse
from run_successor import (Engine, frame_key, date_diagnostics, public_result,
                           scenario_datasets, program_dataset, run_bindings)

OLD = EXEC / 'reproduced'
OUTPUT = HERE / 'reproduced_addendum'
APPLICATION_SHA = '2c3963027729a87c1836e062eb493f7c2363a3056036d09d9c43237fcf6f561f'
BACKUP_SHA = 'ab92ff6a2dcf3a198c4b6bdb8b78f1fc8b29fe3fda143f462086c8265f2bebcb'
ACCEPTANCE_SHA = '404a93c084fc034f69caa187790ba6e4d12f8103b36e43568c9c2c2615ab8ba9'
RESULT_SHA = '91cd3d38aaf3bae80a4d7972c935d020bd48c56e4e78d0cada34104ecd5008f9'


def same(a, b):
    return json_bytes(public_result(a)) == json_bytes(public_result(b))


from portable_saved_fits import SavedFits


def amended(data, delta):
    result = data.subset(list(data.scores.index))
    present = []
    for row in delta['changes']:
        event_id = row['event_id']
        if event_id not in result.scores.index:
            continue
        for field in application.DATE_FIELDS:
            require(result.corpus.at[event_id, field] == row['corpus_before'][field],
                    'Alternative already changes an affected date field: ' + event_id + '/' + field)
            result.corpus.at[event_id, field] = row['corpus_after'][field]
        for field in ('date_is_proxy', 'continuous_date_eligible', 'observed_date_year'):
            before = result.analysis.at[event_id, field]
            expected = row['analysis_before'][field]
            require((pd.isna(before) and expected is None) or before == expected,
                    'Alternative already changes date eligibility')
        for field, value in row['analysis_after'].items():
            if field != 'event_id':
                result.analysis.at[event_id, field] = deepcopy(value)
        present.append(event_id)
    require(result.scores.equals(data.scores) and result.na.equals(data.na), 'Metadata patch changed scores or U/NA')
    return validate_dataset(result, list(data.scores.columns)), present


def prepare():
    h = helpers()
    columns, _ = h.overlap.battery_columns()
    acceptance, datasets, scope, programs, reference, _, reader = load_contract(
        POST / 'complete_candidate_v1/complete/ACCEPTANCE.json', ACCEPTANCE_SHA, columns)
    manifest = reader.json({'path': str((application.TARGET / 'MANIFEST.json').relative_to(ROOT)), 'sha256': APPLICATION_SHA})
    delta = reader.json({'path': str((application.TARGET / 'DATE_ADDENDUM_INPUTS.json').relative_to(ROOT)),
                         'sha256': manifest['output_sha256']['DATE_ADDENDUM_INPUTS.json']})
    for name in ('AMENDED_DATE_CORPUS.json', 'AMENDED_ANALYSIS_METADATA.json'):
        reader.read({'path': str((application.TARGET / name).relative_to(ROOT)), 'sha256': manifest['output_sha256'][name]})
    require({r['event_id'] for r in delta['changes']} == application.DATE_IDS, 'Date delta scope differs')
    old = reader.json({'path': str((OLD / 'RESULTS.json').relative_to(ROOT)), 'sha256': RESULT_SHA})
    require(len(old['scenarios']) == 565, 'Original scientific scenario count differs')
    saved = SavedFits(reader)
    cases = scenario_datasets(datasets, scope)
    instructions = {i['id']: i for i in programs['instructions']}
    require(sum(i['kind'] == 'metadata_only' for i in instructions.values()) == 6, 'Metadata alternative scope differs')
    weights = [i for i in instructions.values() if i['kind'] == 'weighting']
    require(len(weights) == 6 and all(i['weight_kind'] in ('illustrative_upper_bound', 'linked_program_total_one') for i in weights),
            'A new calendar-dependent weight branch needs separate dependency treatment')
    program_data = {}
    plan, fit_changes = [], set()
    for row in old['scenarios']:
        name, result = row['scenario'], row['result']
        if name == 'baseline' or name.startswith('baseline/'):
            plan.append(dict(name=name, action='frozen_v6_baseline_unchanged'))
            continue
        if name in cases:
            data = cases[name]
        elif name.startswith('successor/'):
            data = datasets['successor']
        else:
            matching = [key for key in instructions if name == key or name.startswith(key + '/')]
            require(matching, 'Unmapped historical scenario: ' + name)
            key = max(matching, key=len)
            if key not in program_data:
                program_data[key] = program_dataset(instructions[key], datasets, reader, columns)
            data = program_data[key]
            require(data is not None, 'Unestimable/editorial-only instruction unexpectedly has fitted rows')
        data = data.subset(result['event_ids'])
        corrected, ids = amended(data, delta)
        action = 'unchanged_fit_and_dates'
        matrix, weight, method = None, None, result.get('preprocessing')
        if name == 'successor/equal_era' or (row['category'] == 'metadata_only_weighting' and name.endswith('/era')):
            matrix = corrected.scores.fillna(corrected.scores.median())
            weight = h.fairness.reciprocal_group_weights(corrected.corpus['era_bucket_v2'])
            old_weight = h.fairness.reciprocal_group_weights(data.corpus['era_bucket_v2'])
            require(frame_key(matrix, old_weight) == result['matrix_sha256'], 'Old equal-era fingerprint does not reproduce')
            require(frame_key(matrix, weight) != result['matrix_sha256'], 'Expected era-weight change absent')
            action = 'refit_amended_equal_era'
        elif method == 'era_specific_median':
            matrix = h.legacy.era_median_imputation(corrected.scores, corrected.corpus['era_bucket_v2'])
            old_matrix = h.legacy.era_median_imputation(data.scores, data.corpus['era_bucket_v2'])
            require(frame_key(old_matrix) == result['matrix_sha256'], 'Old era-imputation fingerprint does not reproduce')
            require(frame_key(matrix) != result['matrix_sha256'], 'Expected era-imputation change absent')
            action = 'refit_amended_era_imputation'
        elif ids and 'date_diagnostics' in row:
            action = 'reuse_fit_recompute_amended_dates'
        if matrix is not None:
            fit_changes.add((frame_key(matrix, weight), method, result['seed']))
        plan.append(dict(name=name, action=action, affected_ids=ids, row=row, before=data,
                         after=corrected, matrix=matrix, weights=weight))
    require(len(fit_changes) == 2, 'Only two unique matrix fits are authorized')
    canonical = next(r for r in old['scenarios'] if r['scenario'] == 'successor')['result']
    require(frame_key(datasets['successor'].scores.fillna(datasets['successor'].scores.median())) == canonical['matrix_sha256'],
            'Canonical score matrix identity differs')
    # Hash every reused cache in advance; execution/resume bindings cannot grow later.
    for item in plan:
        if item['action'] not in ('frozen_v6_baseline_unchanged', 'unchanged_fit_and_dates'):
            saved.fit(item['row']['result'])
    core = {label: saved.fit(next(r for r in old['scenarios'] if r['scenario'] == label)['result'])
            for label in ('baseline', 'successor')}
    reader.unchanged()
    return h, reader, reference, old, saved, plan, core


def execute(prepared, resume=False):
    h, reader, reference, old, saved, plan, core = prepared
    bindings = run_bindings(reader)
    bindings['addendum_implementation'] = {p.name: digest(p.read_bytes()) for p in sorted(HERE.glob('*.py'))}
    bindings['authority'] = 'Existing Batch18 adjudication; PRIOR_METADATA_DISPOSITION.md; fixed two-event application manifest.'

    def unchanged():
        reader.unchanged()
        require(bindings['addendum_implementation'] == {p.name: digest(p.read_bytes()) for p in sorted(HERE.glob('*.py'))},
                'Addendum implementation changed during run')

    with ResumeCache(OUTPUT, bindings, resume=resume, validate=unchanged) as cache:
        engine = Engine(h, reference, cache)
        patches, dispositions, new_fits, old_dates_checked = [], [], {}, 0
        for index, item in enumerate(plan):
            action, name = item['action'], item['name']
            disposition = {'scenario': name, 'action': action}
            dispositions.append(disposition)
            if action in ('frozen_v6_baseline_unchanged', 'unchanged_fit_and_dates'):
                continue
            row = item['row']
            old_fit = saved.fit(row['result'])
            patch = {'scenario': name, 'affected_ids': item['affected_ids'], 'action': action,
                     'original_matrix_sha256': old_fit['matrix_sha256']}
            if 'date_diagnostics' in row:
                reproduced = date_diagnostics(item['before'], old_fit, h)
                require(same(reproduced, row['date_diagnostics']), 'Original date result does not reproduce: ' + name)
                old_dates_checked += 1
            if item['matrix'] is not None:
                fit = engine.fit(item['matrix'], weights=item['weights'], seed_offset=1,
                                 preprocessing=old_fit['preprocessing'], checkpoint_label=action)
                require(fit['status'] == 'computed_diagnostic' and all(fit['fits'][str(k)]['status'] == 'computed' for k in (8, 9)),
                        'Amended branch did not produce valid full-rank fits')
                key = fit['matrix_sha256']
                if key not in new_fits:
                    new_fits[key] = {'result': public_result(fit),
                        'compared_with_original_same_branch': public_result(engine.compare(old_fit, fit)),
                        'comparisons': {label: public_result(engine.compare(ref, fit)) for label, ref in core.items()}}
                patch['amended_fit_ref'] = key
            else:
                fit = old_fit
                patch['fit_reused_without_recalculation'] = True
            if 'date_diagnostics' in row:
                patch['date_diagnostics'] = date_diagnostics(item['after'], fit, h)
            patches.append(patch)
            if index % 50 == 0:
                print(json.dumps({'status': 'date_addendum_progress', 'historical_rows_inspected': index,
                                  'new_unique_fits': len(engine.fits), 'patches': len(patches)}), flush=True)
        require(len(engine.fits) == len(new_fits) == 2, 'Unexpected new-fit count')
        updated = {p['scenario']: new_fits[p['amended_fit_ref']]['result'] for p in patches if 'amended_fit_ref' in p}
        counts = lambda rows: dict(sorted(Counter(str(r.get('retained_factors', 'not_estimated')) for r in rows).items()))
        summary = {'schema': 'two-event-metadata-addendum-v1', 'status': 'COMPUTED_ADDENDUM_NOT_ACTIVATION_AUTHORITY',
            'original_result_sha256': RESULT_SHA, 'application_manifest_sha256': APPLICATION_SHA,
            'canonical_fit_matrix_sha256': core['successor']['matrix_sha256'], 'canonical_fit_reused': True,
            'new_unique_preprocessed_fits': 2, 'original_scenarios': 565, 'new_era_fit_scenario_aliases': len(updated),
            'original_date_diagnostics_reproduced_before_amendment': old_dates_checked,
            'amended_date_diagnostic_records': sum('date_diagnostics' in p for p in patches),
            'action_counts': dict(Counter(d['action'] for d in dispositions)),
            'original_retention_counts': counts(r['result'] for r in old['scenarios']),
            'retention_counts_with_explicit_addendum': counts(updated.get(r['scenario'], r['result']) for r in old['scenarios']),
            'dispositions': dispositions, 'amended_fits': new_fits, 'scenario_patches': public_result(patches),
            'limits': 'Frozen v6 baseline remains unchanged. Nonbaseline historical score counterfactuals retain their exact old fits, except the two amended era-dependent matrices. Where present, their date diagnostics use the accepted two-event metadata. Six fixed influence/program weight vectors are unchanged. Original 565 records remain separately hash-bound; this is an explicit overlay, not a new admission/score/family decision or proof of unbiased coverage.',
            'activation_authorized': False, 'deployment_authorized': False}
        result_bytes = json_bytes(summary)
        manifest = {'schema': 'two-event-addendum-run-manifest-v1', 'status': 'complete_not_activated',
                    'bindings': bindings, 'output_sha256': {'RESULTS.json': digest(result_bytes)},
                    'new_unique_fits': 2, 'old_result_unchanged': True}
        cache.finish(result_bytes, json_bytes(manifest))
    print(json.dumps({k: v for k, v in summary.items() if k not in ('dispositions', 'amended_fits', 'scenario_patches')}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    require(not args.resume or args.execute, '--resume requires --execute')
    prepared = prepare()
    print(json.dumps({'status': 'BOUND_DEPENDENCIES_CHECKED_NO_NEW_FITS_YET',
                      'actions': dict(Counter(p['action'] for p in prepared[5])),
                      'new_unique_matrix_fits_authorized': 2}), flush=True)
    if args.execute:
        execute(prepared, args.resume)


if __name__ == '__main__':
    main()
