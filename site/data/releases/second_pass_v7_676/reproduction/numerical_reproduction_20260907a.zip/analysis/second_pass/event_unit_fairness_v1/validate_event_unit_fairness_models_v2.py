#!/usr/bin/env python3
"""Validate scope-corrected event-unit fairness outputs without refitting."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
CANDIDATES = HERE / "candidate_models_v2"
RESULTS = CANDIDATES / "model_results_v2"
VALIDATION = RESULTS / "MODEL_RESULTS_VALIDATION.json"
AUTHORITY = {
    "candidate_activation_authorized",
    "fairness_conclusion_authorized",
    "release_authorized",
    "atlas_change_authorized",
    "deployment_authorized",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(name: str) -> list[dict[str, str]]:
    with (RESULTS / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def boolean(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if str(value).lower() == "true":
        return True
    if str(value).lower() == "false":
        return False
    raise RuntimeError(f"invalid boolean: {value}")


def number(value: Any) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise RuntimeError(f"nonfinite number: {value}")
    return result


def material(row: dict[str, str], suffix: str, factor_reference: int) -> bool:
    return bool(
        int(row["parallel_analysis_factors"]) != factor_reference
        or number(row[f"minimum_loading_tucker_vs_{suffix}"]) < 0.85
        or number(row[f"minimum_shared_score_spearman_vs_{suffix}"]) < 0.90
        or number(row[f"aligned_k6_changed_share_vs_{suffix}"]) > 0.05
    )


def build_validation() -> dict[str, Any]:
    manifest = json.loads((RESULTS / "RESULTS_MANIFEST.json").read_text(encoding="utf-8"))
    summary = json.loads((RESULTS / "MODEL_RESULTS_SUMMARY.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "event-unit-fairness-model-results-manifest-v1":
        raise RuntimeError("results manifest schema differs")
    if manifest.get("status") != "reproducible_diagnostic_not_active":
        raise RuntimeError("results manifest status differs")
    for field in AUTHORITY:
        if manifest.get(field) is not False:
            raise RuntimeError(f"results manifest improperly authorizes {field}")
    for raw, digest in manifest["input_sha256"].items():
        path = ROOT / raw
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"bound input differs: {raw}")
    for name, digest in manifest["output_sha256"].items():
        path = RESULTS / name
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"bound output differs: {name}")

    core = read_csv("core_scenario_metrics.csv")
    factors = read_csv("factor_metrics.csv")
    programs = read_csv("program_sensitivity_metrics.csv")
    weights = read_csv("weighting_metrics.csv")
    documentation = read_csv("documentation_strata.csv")
    source = read_csv("source_resolution_strata.csv")
    imputations = read_csv("imputation_metrics.csv")
    influence = read_csv("event_influence.csv")
    coverage = read_csv("metadata_stratum_coverage.csv")
    expected_core = {
        "published_v4_583": 583,
        "corrected_parent_reference_580": 580,
        "complete_parent_alternative_589": 589,
        "canonical_successor_676": 676,
        "grouped_program_medians_588": 588,
        "all_successors_one_median_520": 520,
        "canonical_without_date_proxies_637": 637,
        "prior_corrected_hellenistic_675": 675,
        "prior_hellenistic_successor_671": 671,
    }
    core_by_name = {row["scenario"]: row for row in core}
    if len(core) != 9 or set(core_by_name) != set(expected_core):
        raise RuntimeError("core scenario universe differs")
    if any(int(core_by_name[name]["rows_in_model_or_sensitivity"]) != count for name, count in expected_core.items()):
        raise RuntimeError("core scenario row count differs")
    v4_factor_count = int(core_by_name["published_v4_583"]["parallel_analysis_factors"])
    parent_factor_count = int(core_by_name["corrected_parent_reference_580"]["parallel_analysis_factors"])
    canonical_factor_count = int(core_by_name["canonical_successor_676"]["parallel_analysis_factors"])
    if (v4_factor_count, parent_factor_count, canonical_factor_count) != (8, 8, 9):
        raise RuntimeError("reference factor-count boundary differs")
    for row in core + programs:
        if boolean(row["material_flag_vs_v4"]) != material(row, "v4", v4_factor_count):
            raise RuntimeError(f"v4 material flag differs: {row['scenario']}")
        if boolean(row["material_flag_vs_corrected_parent"]) != material(
            row, "corrected_parent", parent_factor_count
        ):
            raise RuntimeError(f"parent material flag differs: {row['scenario']}")
        if boolean(row["material_flag_vs_canonical_successor"]) != material(
            row, "canonical_successor", canonical_factor_count
        ):
            raise RuntimeError(f"canonical material flag differs: {row['scenario']}")
    if len(programs) != 138:
        raise RuntimeError("program scenario count differs")
    program_modes = Counter(row["mode"] for row in programs)
    if program_modes != Counter({"swap_successors_to_parents": 69, "leave_program_out": 69}):
        raise RuntimeError("program scenario modes differ")
    group_modes = Counter((row["sensitivity_group_id"], row["mode"]) for row in programs)
    if len(group_modes) != 138 or any(count != 1 for count in group_modes.values()):
        raise RuntimeError("program/group scenarios duplicate")
    if len(factors) != (len(core) + len(programs)) * 8:
        raise RuntimeError("factor row count differs")
    factor_counts = Counter(row["scenario"] for row in factors)
    if set(factor_counts) != set(core_by_name) | {row["scenario"] for row in programs}:
        raise RuntimeError("factor scenario universe differs")
    if any(count != 8 for count in factor_counts.values()):
        raise RuntimeError("a factor scenario lacks eight aligned rows")

    expected_weights = {
        "unweighted_equal_event",
        "equal_total_weight_per_era",
        "equal_total_weight_per_raw_region_string",
        "equal_total_weight_per_raw_mechanism_string",
        "equal_total_weight_per_atlas_status",
        "linked_successor_program_total_weight_one",
        "bounded_log_duration_observed_bounds_only_proxy_neutral",
    }
    if len(weights) != 7 or {row["weighting"] for row in weights} != expected_weights:
        raise RuntimeError("weighting universe differs")
    for row in weights:
        wanted = bool(
            int(row["parallel_analysis_factors"]) != canonical_factor_count
            or number(row["minimum_loading_tucker_vs_canonical_unweighted"]) < 0.85
        )
        if boolean(row["material_factor_or_loading_flag_vs_canonical_unweighted"]) != wanted:
            raise RuntimeError(f"weighting canonical flag differs: {row['weighting']}")
    if len(documentation) != 16 or len(source) < 3 or len(imputations) != 4 or len(coverage) != 8:
        raise RuntimeError("stratum or imputation output count differs")

    candidate_scores = read_csv_candidate(CANDIDATES / "canonical_successor_676" / "data" / "scores_v2.csv")
    influence_by_id = {row["event_id"]: row for row in influence}
    if len(influence) != 676 or set(influence_by_id) != {row["event_id"] for row in candidate_scores}:
        raise RuntimeError("leave-one-event universe differs")
    recomputed_flags = 0
    frozen_flags = 0
    median_change_events = 0
    for row in influence:
        for prefix in ("recomputed_median", "frozen_median"):
            wanted = bool(
                number(row[f"{prefix}_minimum_loading_tucker"]) < 0.85
                or number(row[f"{prefix}_minimum_shared_score_spearman"]) < 0.90
                or number(row[f"{prefix}_aligned_k6_changed_share"]) > 0.05
            )
            if boolean(row[f"{prefix}_material_flag"]) != wanted:
                raise RuntimeError(f"influence flag differs: {row['event_id']} {prefix}")
        recomputed_flags += int(boolean(row["recomputed_median_material_flag"]))
        frozen_flags += int(boolean(row["frozen_median_material_flag"]))
        median_change_events += int(int(row["median_imputation_dimensions_changed_when_removed"]) > 0)
    influence_summary = summary["leave_one_event_out"]
    if influence_summary["events_tested"] != 676:
        raise RuntimeError("influence summary count differs")
    if influence_summary["recomputed_median_material_flags"] != recomputed_flags:
        raise RuntimeError("recomputed influence summary differs")
    if influence_summary["frozen_median_material_flags"] != frozen_flags:
        raise RuntimeError("frozen influence summary differs")
    if influence_summary["events_changing_at_least_one_imputation_median"] != median_change_events:
        raise RuntimeError("median-change influence summary differs")
    for field in (
        "procedural_boundary_fairness_conclusion_authorized",
        "measurement_robustness_conclusion_authorized",
        "coverage_completeness_claim_authorized",
        "candidate_activation_authorized",
        "release_authorized",
        "atlas_change_authorized",
        "deployment_authorized",
    ):
        if summary.get(field) is not False:
            raise RuntimeError(f"summary improperly authorizes {field}")
    return {
        "schema": "event-unit-fairness-model-independent-validation-v1",
        "status": "pass_results_internally_consistent_not_release_authorized",
        "core_scenarios": len(core),
        "program_scenarios": len(programs),
        "weighting_scenarios": len(weights),
        "documentation_scenarios": len(documentation),
        "imputation_scenarios": len(imputations),
        "leave_one_event_scenarios": len(influence),
        "factor_count_reference_boundary": {
            "published_v4": v4_factor_count,
            "corrected_parent": parent_factor_count,
            "canonical_successor": canonical_factor_count,
        },
        "recomputed_median_influence_flags": recomputed_flags,
        "frozen_median_influence_flags": frozen_flags,
        "events_changing_imputation_median": median_change_events,
        "candidate_activation_authorized": False,
        "fairness_conclusion_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }


def read_csv_candidate(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    content = (json.dumps(build_validation(), ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if args.check:
        if not VALIDATION.is_file() or VALIDATION.read_bytes() != content:
            raise SystemExit("event-unit fairness result validation does not reproduce")
        print("event_unit_fairness_result_validation_reproduces")
        return
    VALIDATION.write_bytes(content)
    print("validated event-unit fairness model result bundle")


if __name__ == "__main__":
    main()
