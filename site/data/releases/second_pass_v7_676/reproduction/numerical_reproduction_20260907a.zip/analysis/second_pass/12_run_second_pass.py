#!/usr/bin/env python3
"""Run the statistical second pass on the cleaned, versioned event matrix.

This is a diagnostic rather than an automatic publication classifier. It:

1. re-estimates and aligns the eight latent factors with the first pass;
2. measures how much duplicate/missing-cell repair changes the k=6 solution;
3. restores all dated events to the era-confounding tests;
4. tests structural N/A values directly with a mixed-data distance;
5. evaluates the proposed outcome-first editorial families;
6. emits soft resemblance weights and case-card factor percentiles; and
7. produces a boundary-review queue for historical/editorial adjudication.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.linalg import subspace_angles
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist, squareform
from scipy.stats import pearsonr, rankdata, spearmanr
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.metrics import (
    adjusted_rand_score,
    balanced_accuracy_score,
    confusion_matrix,
    silhouette_samples,
    silhouette_score,
)
from sklearn.model_selection import StratifiedKFold


BASE = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
OUT = HERE / "results"
OUT.mkdir(parents=True, exist_ok=True)

SEED = 12082026
RNG = np.random.default_rng(SEED)

FACTOR_NAMES = {
    "F1": "state_orchestration",
    "F2": "legal_proprietary_machinery",
    "F3": "settler_implantation",
    "F4": "elimination_vs_incorporation",
    "F5": "lethal_coercion",
    "F6": "durability_of_outcome",
    "F7": "displacement_into_occupied_space",
    "F8": "coerced_exogenous_labor",
}

DISCOVERED_SHAPES = {
    0: "low_state_durable_expansion",
    1: "exodus_without_replacement",
    2: "conquest_and_incorporation",
    3: "settler_replacement",
    4: "state_directed_demographic_remaking",
    5: "transient_conflict_displacement",
}

OUTCOME_FAMILIES = [
    "low_state_durable_expansion",
    "settler_replacement",
    "conquest_and_incorporation",
    "state_directed_demographic_remaking",
    "expulsion_or_flight_without_replacement",
    "land_clearance_for_state_or_project_use",
]

BASE_FAMILY_BY_FROZEN_CLUSTER = {
    0: "low_state_durable_expansion",
    1: "expulsion_or_flight_without_replacement",
    2: "conquest_and_incorporation",
    3: "settler_replacement",
    4: "state_directed_demographic_remaking",
    5: "expulsion_or_flight_without_replacement",
}

# These are source-reviewed editorial hypotheses for additions, never inputs to
# factor estimation or k-means. They let the outcome-family diagnostics include
# new rows without pretending that those rows existed in the first-pass labels.
ADDITION_EDITORIAL_FAMILIES = {
    "ancient-roman-apuan-ligures-resettlement": "state_directed_demographic_remaking",
    "ancient-athenian-melos-destruction-colony": "settler_replacement",
    "late-antique-sasanian-antioch-weh-antioch": "state_directed_demographic_remaking",
    "ancient-mauryan-kalinga-war-removal": "expulsion_or_flight_without_replacement",
    "ancient-hittite-mursili-arzawa-deportation": "conquest_and_incorporation",
    "ancient-qin-nanyang-clearance-convict-colony": "state_directed_demographic_remaking",
    "ancient-qin-eastern-elites-xianyang-resettlement": "state_directed_demographic_remaking",
    "medieval-nikephoros-asia-minor-balkan-transfer": "state_directed_demographic_remaking",
    "medieval-carolingian-nordalbingian-saxon-removal": "state_directed_demographic_remaking",
    "ancient-achaemenid-barcaeans-bactria": "state_directed_demographic_remaking",
    "ancient-achaemenid-paeonians-phrygia-return": "state_directed_demographic_remaking",
    "ancient-achaemenid-miletus-ampe-land-redistribution": "settler_replacement",
    "ancient-achaemenid-eretria-ardericca": "state_directed_demographic_remaking",
    "ancient-achaemenid-sidonians-susa-babylon": "state_directed_demographic_remaking",
    "late-antique-sasanian-hatra-depopulation": "expulsion_or_flight_without_replacement",
    "late-antique-sasanian-shapur-antioch-captivity": "state_directed_demographic_remaking",
    "late-antique-sasanian-shapur-dura-europos-deportation": "expulsion_or_flight_without_replacement",
    "late-antique-sasanian-shapur-third-campaign-provincials": "state_directed_demographic_remaking",
    "ancient-egypt-thutmose-iii-megiddo-captive-communities": "state_directed_demographic_remaking",
    "ancient-egypt-amenhotep-ii-year7-year9-deportations": "state_directed_demographic_remaking",
    "medieval-mongol-samarkand-artisan-and-youth-removals": "state_directed_demographic_remaking",
    "medieval-mongol-urgench-destruction-and-artisan-removal": "state_directed_demographic_remaking",
    "medieval-mongol-merv-selective-captivity-and-depopulation": "expulsion_or_flight_without_replacement",
    "medieval-mongol-nishapur-massacre-and-artisan-removal": "expulsion_or_flight_without_replacement",
    "medieval-mongol-herat-weavers-beshbaliq-return": "state_directed_demographic_remaking",
    "medieval-mongol-bukhara-capture-dispersal-levy": "expulsion_or_flight_without_replacement",
    "medieval-mongol-balkh-punitive-destruction": "expulsion_or_flight_without_replacement",
    "medieval-mongol-bamiyan-retaliatory-destruction": "expulsion_or_flight_without_replacement",
    "medieval-mongol-herat-rebellion-punitive-destruction": "expulsion_or_flight_without_replacement",
    "ancient-neo-assyrian-unqi-annexation-cross-resettlement": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-damascus-punitive-deportations": "expulsion_or_flight_without_replacement",
    "ancient-neo-assyrian-northern-israel-galilee-deportation": "expulsion_or_flight_without_replacement",
    "ancient-neo-assyrian-samaria-deportation-resettlement": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-carchemish-deportation-resettlement": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-bit-purutas-replacement": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-til-garimme-replacement": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-babylonia-703-mass-deportation": "expulsion_or_flight_without_replacement",
    "ancient-neo-assyrian-judah-deportation-land-transfer": "conquest_and_incorporation",
    "ancient-neo-assyrian-sidon-destruction-kar-esarhaddon": "state_directed_demographic_remaking",
    "ancient-neo-assyrian-elam-susa-destruction-deportation": "expulsion_or_flight_without_replacement",
}

# The early Neo-Assyrian hypotheses live with their source-reviewed records so
# the model runner cannot silently assign them from their numerical profiles.
# Patterns distinguish taking/outpost, removal/clearance, and state remaking;
# the later manual pass is free to adjudicate individual hybrids.
EARLY_ADDITIONS_FILE = HERE / "early_neo_assyrian_additions.json"
if EARLY_ADDITIONS_FILE.exists():
    early_additions = json.loads(EARLY_ADDITIONS_FILE.read_text())
    if len(early_additions) != 44:
        raise ValueError(
            f"Expected 44 early Neo-Assyrian editorial hypotheses, found {len(early_additions)}"
        )
    for item in early_additions:
        event_id = item["event"]["event_id"]
        family = item.get("editorial_family_hypothesis")
        if family not in OUTCOME_FAMILIES:
            raise ValueError(f"Invalid early Neo-Assyrian family hypothesis: {event_id}/{family}")
        if event_id in ADDITION_EDITORIAL_FAMILIES:
            raise ValueError(f"Duplicate addition editorial hypothesis: {event_id}")
        ADDITION_EDITORIAL_FAMILIES[event_id] = family

# Roman hypotheses are likewise source-reviewed metadata rather than model
# inputs. Loading them here lets the same frozen pipeline run against isolated
# 546- and 583-event candidate directories without editing the active data.
ROMAN_ADDITIONS_FILE = HERE / "roman_additions.json"
if ROMAN_ADDITIONS_FILE.exists():
    roman_additions = json.loads(ROMAN_ADDITIONS_FILE.read_text())
    if len(roman_additions) != 95:
        raise ValueError(
            f"Expected 95 Roman editorial hypotheses, found {len(roman_additions)}"
        )
    for item in roman_additions:
        event_id = item["event"]["event_id"]
        family = item.get("editorial_family_hypothesis")
        if family not in OUTCOME_FAMILIES:
            raise ValueError(f"Invalid Roman editorial family hypothesis: {event_id}/{family}")
        if event_id in ADDITION_EDITORIAL_FAMILIES:
            raise ValueError(f"Duplicate addition editorial hypothesis: {event_id}")
        ADDITION_EDITORIAL_FAMILIES[event_id] = family


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=1, ensure_ascii=False) + "\n")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def finite_float(value: float) -> float | None:
    value = float(value)
    return value if np.isfinite(value) else None


def parallel_analysis(X: np.ndarray, n_sims: int = 500) -> tuple[int, np.ndarray, np.ndarray]:
    """Horn parallel analysis against 95th-percentile random eigenvalues."""
    corr = np.corrcoef(X, rowvar=False)
    observed = np.sort(np.linalg.eigvalsh(corr))[::-1]
    sims = np.empty((n_sims, X.shape[1]))
    local_rng = np.random.default_rng(SEED + 1)
    for i in range(n_sims):
        random_x = local_rng.normal(size=X.shape)
        sims[i] = np.sort(np.linalg.eigvalsh(np.corrcoef(random_x, rowvar=False)))[::-1]
    threshold = np.percentile(sims, 95, axis=0)
    return int(np.sum(observed > threshold)), observed, threshold


def loading_congruence(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Signed Tucker congruence between every column of A and B."""
    numer = A.T @ B
    denom = np.sqrt((A * A).sum(axis=0)[:, None] * (B * B).sum(axis=0)[None, :])
    return np.divide(numer, denom, out=np.zeros_like(numer), where=denom != 0)


def align_factors(old_loadings: pd.DataFrame, new_loadings: pd.DataFrame,
                  new_scores: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, list[dict]]:
    common = old_loadings.index.intersection(new_loadings.index)
    congr = loading_congruence(old_loadings.loc[common].values,
                               new_loadings.loc[common].values)
    old_ix, new_ix = linear_sum_assignment(-np.abs(congr))
    assignments: list[dict] = []
    aligned_loadings = pd.DataFrame(index=new_loadings.index)
    aligned_scores = pd.DataFrame(index=new_scores.index)
    for oi, ni in sorted(zip(old_ix, new_ix)):
        old_name = old_loadings.columns[oi]
        new_name = new_loadings.columns[ni]
        signed = float(congr[oi, ni])
        sign = 1.0 if signed >= 0 else -1.0
        aligned_loadings[old_name] = new_loadings[new_name] * sign
        aligned_scores[old_name] = new_scores[new_name] * sign
        assignments.append({
            "old_factor": old_name,
            "new_unaligned_factor": new_name,
            "sign_flipped": bool(sign < 0),
            "tucker_congruence": abs(signed),
        })
    return aligned_loadings, aligned_scores, assignments


def align_cluster_labels(reference: np.ndarray, candidate: np.ndarray,
                         k: int = 6) -> tuple[np.ndarray, dict[int, int], np.ndarray]:
    table = np.zeros((k, k), dtype=int)
    for r, c in zip(reference, candidate):
        table[int(r), int(c)] += 1
    ref_ix, cand_ix = linear_sum_assignment(-table)
    mapping = {int(c): int(r) for r, c in zip(ref_ix, cand_ix)}
    aligned = np.array([mapping[int(v)] for v in candidate], dtype=int)
    return aligned, mapping, table


def bootstrap_stability(X: np.ndarray, k: int = 6, n_boot: int = 200) -> dict:
    base = KMeans(n_clusters=k, n_init=100, random_state=0).fit_predict(X)
    by_cluster: dict[int, list[float]] = {c: [] for c in range(k)}
    local_rng = np.random.default_rng(SEED + 2)
    universe = set(range(len(X)))
    for b in range(n_boot):
        sampled = local_rng.choice(len(X), len(X), replace=True)
        unique = np.unique(sampled)
        labels = KMeans(n_clusters=k, n_init=30, random_state=b + 1).fit_predict(X[unique])
        label_by_index = dict(zip(unique.tolist(), labels.tolist()))
        represented = set(unique.tolist())
        for c in range(k):
            original = set(np.where(base == c)[0].tolist()) & represented
            if not original:
                continue
            best = 0.0
            for c2 in range(k):
                new = {i for i in represented if label_by_index[i] == c2}
                if new:
                    best = max(best, len(original & new) / len(original | new))
            by_cluster[c].append(best)
    means = {str(c): float(np.mean(values)) for c, values in by_cluster.items()}
    return {
        "n_boot": n_boot,
        "mean_jaccard": float(np.mean(list(means.values()))),
        "per_cluster": means,
        "n_clusters_at_or_above_0_75": int(sum(v >= 0.75 for v in means.values())),
    }


def fuzzy_weights(distances: np.ndarray, power: float = 2.0) -> np.ndarray:
    """Turn centroid distances into fuzzy resemblance weights (not probabilities)."""
    d = np.maximum(distances, 1e-9)
    weights = d ** (-power)
    exact = distances <= 1e-9
    for i in np.where(exact.any(axis=1))[0]:
        weights[i] = exact[i].astype(float)
    return weights / weights.sum(axis=1, keepdims=True)


def mixed_distance(scores: pd.DataFrame, na_types: pd.DataFrame,
                   na_numeric_penalty: float) -> np.ndarray:
    """Gower-like distance preserving structural N/A and ignoring unknown pairs.

    Numeric-vs-numeric is absolute score difference / 4. Structural N/A matches
    structural N/A at zero distance. Structural N/A vs numeric receives the
    stated penalty. A pair is ignored for a dimension when either value is U.
    """
    X = scores.values.astype(float)
    kinds = na_types.values.astype(str)
    n, p = X.shape
    total = np.zeros((n, n), dtype=float)
    compared = np.zeros((n, n), dtype=np.int16)
    for j in range(p):
        values = X[:, j]
        unknown = kinds[:, j] == "U"
        structural = kinds[:, j] == "NA"
        numeric = np.isfinite(values)
        valid_pair = ~(unknown[:, None] | unknown[None, :])
        compared += valid_pair.astype(np.int16)

        d = np.zeros((n, n), dtype=float)
        both_numeric = numeric[:, None] & numeric[None, :]
        d[both_numeric] = np.abs(values[:, None] - values[None, :])[both_numeric] / 4.0
        one_structural = structural[:, None] ^ structural[None, :]
        d[one_structural & valid_pair] = na_numeric_penalty
        total += d
    if np.any(compared == 0):
        raise ValueError("At least one event pair has no comparable dimensions")
    distance = total / compared
    np.fill_diagonal(distance, 0.0)
    return distance


def alternate_k_medoids(distance: np.ndarray, k: int = 6, n_init: int = 100,
                        max_iter: int = 100, seed: int = SEED) -> tuple[np.ndarray, np.ndarray, float]:
    """Cluster a precomputed distance matrix with deterministic multi-start k-medoids.

    This avoids the severe chaining/size imbalance that average-linkage can
    produce on Gower-like distances. Average-linkage is still reported as a
    sensitivity result below rather than silently discarded.
    """
    rng = np.random.default_rng(seed)
    n = len(distance)
    best: tuple[float, np.ndarray, np.ndarray] | None = None
    for _ in range(n_init):
        medoids = [int(rng.integers(n))]
        while len(medoids) < k:
            nearest = distance[:, medoids].min(axis=1)
            nearest[medoids] = 0.0
            weights = nearest ** 2
            if weights.sum() == 0:
                choices = np.setdiff1d(np.arange(n), medoids)
                medoids.append(int(rng.choice(choices)))
            else:
                medoids.append(int(rng.choice(n, p=weights / weights.sum())))
        medoids_array = np.array(medoids, dtype=int)

        for _iteration in range(max_iter):
            labels = distance[:, medoids_array].argmin(axis=1)
            updated = medoids_array.copy()
            for cluster in range(k):
                members = np.where(labels == cluster)[0]
                if len(members):
                    within = distance[np.ix_(members, members)].sum(axis=1)
                    updated[cluster] = members[int(np.argmin(within))]
                else:
                    nearest = distance[:, updated].min(axis=1)
                    nearest[updated] = -1
                    updated[cluster] = int(np.argmax(nearest))
            if np.array_equal(updated, medoids_array):
                break
            medoids_array = updated

        labels = distance[:, medoids_array].argmin(axis=1)
        objective = float(distance[np.arange(n), medoids_array[labels]].sum())
        if best is None or objective < best[0]:
            best = (objective, labels.copy(), medoids_array.copy())
    assert best is not None
    return best[1], best[2], best[0]


def weighted_correlation(X: np.ndarray, weights: np.ndarray) -> np.ndarray:
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    mean = np.sum(X * weights[:, None], axis=0)
    centered = X - mean
    covariance = (centered * weights[:, None]).T @ centered
    scale = np.sqrt(np.diag(covariance))
    corr = covariance / np.outer(scale, scale)
    corr = np.nan_to_num(corr, nan=0.0)
    np.fill_diagonal(corr, 1.0)
    return corr


def partial_spearman(x: np.ndarray, y: np.ndarray, controls: np.ndarray) -> tuple[float, float]:
    xr = rankdata(x)
    yr = rankdata(y)
    cr = np.column_stack([rankdata(controls[:, j]) for j in range(controls.shape[1])])
    design = np.column_stack([np.ones(len(x)), cr])
    xres = xr - design @ np.linalg.lstsq(design, xr, rcond=None)[0]
    yres = yr - design @ np.linalg.lstsq(design, yr, rcond=None)[0]
    return tuple(float(v) for v in pearsonr(xres, yres))


def leave_one_out_centroid_distances(X: np.ndarray, labels: np.ndarray,
                                     family_names: list[str]) -> np.ndarray:
    out = np.zeros((len(X), len(family_names)), dtype=float)
    for j, family in enumerate(family_names):
        members = labels == family
        count = int(members.sum())
        total = X[members].sum(axis=0)
        centroid = total / count
        out[:, j] = np.linalg.norm(X - centroid, axis=1)
        if count > 1:
            own_rows = np.where(members)[0]
            own_centroids = (total - X[own_rows]) / (count - 1)
            out[own_rows, j] = np.linalg.norm(X[own_rows] - own_centroids, axis=1)
    return out


def nearest_centroid_cv(X: np.ndarray, labels: np.ndarray,
                        family_names: list[str]) -> dict:
    code = {name: i for i, name in enumerate(family_names)}
    y = np.array([code[v] for v in labels])
    predicted = np.empty_like(y)
    cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=SEED)
    for train, test in cv.split(X, y):
        centroids = np.vstack([X[train][y[train] == i].mean(axis=0)
                               for i in range(len(family_names))])
        predicted[test] = cdist(X[test], centroids).argmin(axis=1)
    return {
        "accuracy": float(np.mean(predicted == y)),
        "balanced_accuracy": float(balanced_accuracy_score(y, predicted)),
        "confusion_matrix": confusion_matrix(y, predicted).tolist(),
        "family_order": family_names,
    }


def main() -> None:
    global DATA, OUT
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=DATA,
        help="Directory containing corpus_v2.json, scores_v2.csv, and na_types_v2.csv.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=OUT,
        help="Directory for this run's statistical outputs.",
    )
    parser.add_argument(
        "--run-label",
        default="second-pass-v2",
        help="Version label recorded in second_pass_results.json.",
    )
    parser.add_argument(
        "--family-hypotheses",
        type=Path,
        help="Optional JSON object mapping newly added event IDs to reviewed editorial families.",
    )
    args = parser.parse_args()
    DATA = args.data_dir.resolve()
    OUT = args.out_dir.resolve()
    OUT.mkdir(parents=True, exist_ok=True)

    if args.family_hypotheses:
        external_hypotheses = json.loads(args.family_hypotheses.read_text())
        if not isinstance(external_hypotheses, dict):
            raise ValueError("External family hypotheses must be a JSON object")
        for event_id, family in external_hypotheses.items():
            if family not in OUTCOME_FAMILIES:
                raise ValueError(f"Invalid external editorial family hypothesis: {event_id}/{family}")
            if event_id in ADDITION_EDITORIAL_FAMILIES:
                raise ValueError(f"Duplicate external editorial family hypothesis: {event_id}")
            ADDITION_EDITORIAL_FAMILIES[event_id] = family

    scores = pd.read_csv(DATA / "scores_v2.csv", index_col="event_id").astype(float)
    na_types = pd.read_csv(DATA / "na_types_v2.csv", index_col="event_id",
                           keep_default_na=False, dtype=str).loc[scores.index]
    corpus_all = pd.DataFrame(json.loads((DATA / "corpus_v2.json").read_text()))
    corpus = corpus_all[corpus_all["in_model"] == True].set_index("event_id").loc[scores.index]  # noqa: E712
    old_loadings = pd.read_csv(BASE / "results" / "loadings_oblimin_main.csv", index_col=0)
    old_scores_all = pd.read_csv(BASE / "results" / "factor_scores_main.csv", index_col=0)
    old_assignments_all = pd.read_csv(BASE / "results" / "final_k6_assignments.csv", index_col=0)
    shared_ids = scores.index[scores.index.isin(old_assignments_all.index)]
    added_ids = scores.index[~scores.index.isin(old_assignments_all.index)]
    old_scores = old_scores_all.loc[shared_ids]
    old_assignments = old_assignments_all.loc[shared_ids]
    old_labels = old_assignments["cluster"].astype(int).values
    shared_positions = scores.index.get_indexer(shared_ids)

    unexpected_additions = set(added_ids) - set(ADDITION_EDITORIAL_FAMILIES)
    if unexpected_additions:
        raise ValueError(f"Missing editorial-family hypothesis for additions: {sorted(unexpected_additions)}")

    if scores.shape[1] != 60 or len(scores) < 407:
        raise ValueError(f"Unexpected clean matrix shape: {scores.shape}")
    true_blank = scores.isna() & (na_types == "")
    if true_blank.any().any():
        raise ValueError("Clean input still contains untyped blanks")

    # --- Re-estimate the factor model and align it with the named first-pass axes.
    medians = scores.median()
    imputed = scores.fillna(medians)
    k_parallel, eigenvalues, thresholds = parallel_analysis(imputed.values)
    fa = FactorAnalyzer(n_factors=8, rotation="oblimin", method="minres")
    fa.fit(imputed.values)
    raw_loadings = pd.DataFrame(fa.loadings_, index=scores.columns,
                                columns=[f"N{i+1}" for i in range(8)])
    raw_factor_scores = pd.DataFrame(fa.transform(imputed.values), index=scores.index,
                                     columns=raw_loadings.columns)
    loadings, factor_scores, factor_alignment = align_factors(
        old_loadings, raw_loadings, raw_factor_scores)
    loadings.to_csv(OUT / "loadings_aligned.csv")
    factor_scores.to_csv(OUT / "factor_scores_aligned.csv")

    score_correlations = {}
    for f in old_scores.columns:
        rho, p = spearmanr(old_scores[f], factor_scores.loc[shared_ids, f])
        score_correlations[f] = {"spearman_rho": float(rho), "p": float(p)}

    # --- Cleaned k=6 statistical neighborhoods and soft memberships.
    X = factor_scores.values
    km = KMeans(n_clusters=6, n_init=100, random_state=0).fit(X)
    _, cluster_map, contingency = align_cluster_labels(
        old_labels, km.labels_[shared_positions])
    aligned_labels = np.array([cluster_map[int(v)] for v in km.labels_], dtype=int)
    centers = np.vstack([X[aligned_labels == c].mean(axis=0) for c in range(6)])
    sil = silhouette_samples(X, aligned_labels)
    cluster_dist = cdist(X, centers)
    cluster_soft = fuzzy_weights(cluster_dist)
    cluster_top = cluster_soft.argmax(axis=1)
    cluster_ordered = np.sort(cluster_soft, axis=1)

    clean_clusters = factor_scores.copy()
    clean_clusters.insert(0, "cluster", aligned_labels)
    clean_clusters.insert(1, "cluster_name", [DISCOVERED_SHAPES[v] for v in aligned_labels])
    old_cluster_full = pd.Series(pd.NA, index=scores.index, dtype="Int64")
    old_cluster_full.loc[shared_ids] = old_labels
    changed_full = pd.Series(pd.NA, index=scores.index, dtype="boolean")
    changed_full.loc[shared_ids] = aligned_labels[shared_positions] != old_labels
    clean_clusters.insert(2, "old_cluster", old_cluster_full)
    clean_clusters.insert(3, "changed_from_first_pass", changed_full)
    clean_clusters["silhouette"] = sil
    clean_clusters["soft_top_cluster"] = cluster_top
    clean_clusters["soft_top_name"] = [DISCOVERED_SHAPES[v] for v in cluster_top]
    clean_clusters["soft_top_weight"] = cluster_ordered[:, -1]
    clean_clusters["soft_margin"] = cluster_ordered[:, -1] - cluster_ordered[:, -2]
    clean_clusters["name"] = corpus["name"]
    clean_clusters["mechanism"] = corpus["mechanism"]
    clean_clusters["start"] = corpus["start"]
    clean_clusters["era"] = corpus["era_bucket_v2"]
    clean_clusters["on_atlas"] = corpus["on_atlas"]
    clean_clusters.to_csv(OUT / "clean_k6_assignments.csv")

    # Percentiles are display-ready inputs for the approved eight-bar case card.
    card = pd.DataFrame(index=factor_scores.index)
    card["name"] = corpus["name"]
    for f, label in FACTOR_NAMES.items():
        card[f"{f}_{label}_score"] = factor_scores[f]
        card[f"{f}_{label}_percentile"] = factor_scores[f].rank(pct=True) * 100
    card.to_csv(OUT / "eight_trait_card_values.csv", float_format="%.3f")

    stability = bootstrap_stability(X)
    factor_k_sweep = {}
    for k in range(2, 13):
        labels_k = KMeans(n_clusters=k, n_init=50, random_state=0).fit_predict(X)
        factor_k_sweep[str(k)] = {
            "silhouette": float(silhouette_score(X, labels_k)),
            "sizes": sorted(np.bincount(labels_k, minlength=k).tolist()),
        }
    cluster_summary = {
        "comparison_scope": "shared baseline events only",
        "n_shared_with_first_pass": int(len(shared_ids)),
        "n_added_after_first_pass": int(len(added_ids)),
        "ari_vs_first_pass": float(adjusted_rand_score(
            old_labels, aligned_labels[shared_positions])),
        "exact_agreement_after_label_alignment": float(np.mean(
            old_labels == aligned_labels[shared_positions])),
        "n_changed_after_label_alignment": int(np.sum(
            old_labels != aligned_labels[shared_positions])),
        "mean_silhouette": float(np.mean(sil)),
        "n_negative_silhouette": int(np.sum(sil < 0)),
        "n_below_0_20": int(np.sum(sil < 0.20)),
        "sizes": {DISCOVERED_SHAPES[c]: int(np.sum(aligned_labels == c)) for c in range(6)},
        "bootstrap_stability": stability,
        "k_sweep": factor_k_sweep,
        "unaligned_to_first_pass_cluster_map": {str(k): v for k, v in cluster_map.items()},
        "pre_alignment_contingency_old_rows_new_columns": contingency.tolist(),
    }

    # --- Corrected era diagnostics, including documentation-density controls.
    starts = corpus["start"].astype(float).values
    n_unknown = (na_types == "U").sum(axis=1).values.astype(float)
    n_structural = (na_types == "NA").sum(axis=1).values.astype(float)
    era_rows = []
    era_summary = {}
    for f in factor_scores.columns:
        rho, p = spearmanr(starts, factor_scores[f].values)
        partial_u, partial_u_p = partial_spearman(
            starts, factor_scores[f].values, n_unknown[:, None])
        partial_both, partial_both_p = partial_spearman(
            starts, factor_scores[f].values, np.column_stack([n_unknown, n_structural]))
        era_summary[f] = {
            "rho": float(rho), "p": float(p),
            "partial_controlling_unknown": partial_u,
            "partial_controlling_unknown_p": partial_u_p,
            "partial_controlling_unknown_and_structural_na": partial_both,
            "partial_controlling_unknown_and_structural_na_p": partial_both_p,
        }
    doc_rho, doc_p = spearmanr(starts, n_unknown)
    era_summary["documentation_density"] = {
        "start_year_vs_unknown_count_rho": float(doc_rho),
        "p": float(doc_p),
    }
    for era, ids in corpus.groupby("era_bucket_v2").groups.items():
        idx = scores.index.get_indexer(ids)
        row = {"era": era, "n": len(ids),
               "mean_unknown": float(n_unknown[idx].mean()),
               "mean_structural_na": float(n_structural[idx].mean())}
        for f in factor_scores.columns:
            row[f] = float(factor_scores.iloc[idx][f].mean())
        era_rows.append(row)
    pd.DataFrame(era_rows).sort_values("era").to_csv(OUT / "era_profiles.csv", index=False)

    # Equal total weight per era: asks whether modern-heavy sampling defines the axes.
    era_counts = corpus["era_bucket_v2"].value_counts()
    era_weights = corpus["era_bucket_v2"].map(lambda e: 1.0 / era_counts[e]).values
    balanced_corr = weighted_correlation(imputed.values, era_weights)
    fa_balanced = FactorAnalyzer(n_factors=8, rotation="oblimin", method="minres",
                                 is_corr_matrix=True)
    fa_balanced.fit(balanced_corr)
    balanced_loadings_raw = pd.DataFrame(
        fa_balanced.loadings_, index=scores.columns, columns=[f"B{i+1}" for i in range(8)])
    dummy_scores = pd.DataFrame(np.zeros((len(scores), 8)), index=scores.index,
                                columns=balanced_loadings_raw.columns)
    balanced_loadings, _, balanced_alignment = align_factors(
        loadings, balanced_loadings_raw, dummy_scores)
    balanced_loadings.to_csv(OUT / "loadings_era_balanced.csv")

    # Oblique factors can trade loadings within a correlated block even when
    # the block's shared subspace is stable. Preserve both the per-axis Tucker
    # result and grouped principal-angle sensitivity so an apparently weak F1
    # match is not either hidden or overinterpreted.
    era_balanced_subspaces = {}
    for label, columns in {
        "state_and_legal_F1_F2": ["F1", "F2"],
        "state_legal_and_coerced_labor_F1_F2_F8": ["F1", "F2", "F8"],
        "all_eight_axes": [f"F{i}" for i in range(1, 9)],
    }.items():
        angles = np.degrees(subspace_angles(
            loadings[columns].values, balanced_loadings[columns].values))
        era_balanced_subspaces[label] = {
            "principal_angles_degrees": [float(v) for v in angles],
            "cosines": [float(v) for v in np.cos(np.radians(angles))],
        }

    # --- Treat structural N/A as data, not median values.
    gower_results = {}
    gower_labels: dict[float, np.ndarray] = {}
    gower_distances: dict[float, np.ndarray] = {}
    for penalty in (0.50, 0.75, 1.00):
        distance = mixed_distance(scores, na_types, penalty)
        labels_raw, medoids, objective = alternate_k_medoids(
            distance, seed=SEED + int(penalty * 100))
        labels_aligned, mapping, _ = align_cluster_labels(aligned_labels, labels_raw)

        # Average-linkage is retained as a sensitivity check. It is not the
        # primary result because it creates one giant cluster on these data.
        average_raw = AgglomerativeClustering(
            n_clusters=6, metric="precomputed", linkage="average").fit_predict(distance)
        average_aligned, _, _ = align_cluster_labels(aligned_labels, average_raw)
        gower_labels[penalty] = labels_aligned
        gower_distances[penalty] = distance
        gower_results[f"penalty_{penalty:.2f}"] = {
            "primary_method": "alternate_k_medoids_100_starts",
            "total_distance_to_medoids": objective,
            "silhouette_precomputed_distance": float(
                silhouette_score(distance, labels_aligned, metric="precomputed")),
            "ari_vs_clean_factor_k6": float(adjusted_rand_score(aligned_labels, labels_aligned)),
            "ari_vs_first_pass_k6": float(adjusted_rand_score(
                old_labels, labels_aligned[shared_positions])),
            "sizes": {DISCOVERED_SHAPES[c]: int(np.sum(labels_aligned == c)) for c in range(6)},
            "medoid_event_ids": [str(scores.index[i]) for i in medoids],
            "unaligned_cluster_map": {str(k): v for k, v in mapping.items()},
            "average_linkage_sensitivity": {
                "ari_vs_clean_factor_k6": float(
                    adjusted_rand_score(aligned_labels, average_aligned)),
                "sizes": sorted(np.bincount(average_raw, minlength=6).tolist()),
            },
        }
    gower_results["weight_sensitivity_ari"] = {
        "0.50_vs_0.75": float(adjusted_rand_score(gower_labels[0.50], gower_labels[0.75])),
        "0.50_vs_1.00": float(adjusted_rand_score(gower_labels[0.50], gower_labels[1.00])),
        "0.75_vs_1.00": float(adjusted_rand_score(gower_labels[0.75], gower_labels[1.00])),
    }
    mixed_k_sweep = {}
    for k in range(2, 11):
        labels_k, _, objective_k = alternate_k_medoids(
            gower_distances[0.75], k=k, n_init=50, seed=SEED + 750 + k)
        mixed_k_sweep[str(k)] = {
            "silhouette": float(silhouette_score(
                gower_distances[0.75], labels_k, metric="precomputed")),
            "total_distance_to_medoids": objective_k,
            "sizes": sorted(np.bincount(labels_k, minlength=k).tolist()),
        }
    gower_results["k_sweep_penalty_0.75"] = mixed_k_sweep
    gower_df = pd.DataFrame(index=scores.index)
    for penalty in (0.50, 0.75, 1.00):
        gower_df[f"cluster_penalty_{penalty:.2f}"] = gower_labels[penalty]
    gower_df["factor_cluster"] = aligned_labels
    gower_df["name"] = corpus["name"]
    gower_df["n_unknown"] = n_unknown
    gower_df["n_structural_na"] = n_structural
    gower_df.to_csv(OUT / "structural_distance_clusters.csv")
    np.save(OUT / "mixed_distance_penalty_0_75.npy", gower_distances[0.75])

    # --- Frozen outcome-first hypothesis, assessed against the repaired data.
    editorial_family = np.empty(len(scores), dtype=object)
    editorial_family[shared_positions] = [
        BASE_FAMILY_BY_FROZEN_CLUSTER[int(c)] for c in old_labels]
    for eid in added_ids:
        editorial_family[scores.index.get_loc(eid)] = ADDITION_EDITORIAL_FAMILIES[eid]
    project_mask = corpus["mechanism"].eq("development/conservation displacement").values
    editorial_family[project_mask] = "land_clearance_for_state_or_project_use"
    family_code = np.array([OUTCOME_FAMILIES.index(v) for v in editorial_family])
    outcome_sil_factor = silhouette_samples(X, family_code)
    outcome_sil_gower = silhouette_samples(
        gower_distances[0.75], family_code, metric="precomputed")

    family_dist = leave_one_out_centroid_distances(X, editorial_family, OUTCOME_FAMILIES)
    family_soft = fuzzy_weights(family_dist)
    nearest_family_code = family_dist.argmin(axis=1)
    nearest_family = np.array([OUTCOME_FAMILIES[v] for v in nearest_family_code])
    ordered_family_weights = np.sort(family_soft, axis=1)

    family_df = pd.DataFrame(index=scores.index)
    family_df["name"] = corpus["name"]
    family_df["date_label"] = corpus["date_label"]
    family_df["era"] = corpus["era_bucket_v2"]
    family_df["mechanism"] = corpus["mechanism"]
    family_df["frozen_first_pass_cluster"] = old_cluster_full
    family_df["clean_statistical_cluster"] = aligned_labels
    family_df["proposed_primary_family"] = editorial_family
    family_df["nearest_factor_profile_family"] = nearest_family
    family_df["prototype_conflict"] = nearest_family != editorial_family
    family_df["factor_space_silhouette"] = outcome_sil_factor
    family_df["mixed_distance_silhouette"] = outcome_sil_gower
    family_df["own_family_weight"] = [family_soft[i, family_code[i]] for i in range(len(scores))]
    family_df["top_family_weight"] = ordered_family_weights[:, -1]
    family_df["top_two_margin"] = ordered_family_weights[:, -1] - ordered_family_weights[:, -2]
    for j, family in enumerate(OUTCOME_FAMILIES):
        family_df[f"weight__{family}"] = family_soft[:, j]
    family_df.to_csv(OUT / "outcome_family_diagnostics.csv", float_format="%.5f")

    cv = nearest_centroid_cv(X, editorial_family, OUTCOME_FAMILIES)
    outcome_summary = {
        "status": "provisional_editorial_hypothesis_not_final_labels",
        "construction": (
            "For the shared baseline, first-pass cluster assignments were frozen and "
            "mapped to the proposed outcome families, clusters 1 and 5 were merged, "
            "and development/conservation cases were moved to the land-clearance "
            "family. New source-reviewed ancient rows use the explicit editorial "
            "hypotheses in ADDITION_EDITORIAL_FAMILIES; these labels were not inputs "
            "to factor estimation or statistical clustering."
        ),
        "n_shared_baseline_events": int(len(shared_ids)),
        "n_added_events": int(len(added_ids)),
        "sizes": {family: int(np.sum(editorial_family == family))
                  for family in OUTCOME_FAMILIES},
        "mean_factor_space_silhouette": float(outcome_sil_factor.mean()),
        "mean_mixed_distance_silhouette": float(outcome_sil_gower.mean()),
        "n_negative_factor_space_silhouette": int(np.sum(outcome_sil_factor < 0)),
        "n_prototype_conflicts": int(np.sum(nearest_family != editorial_family)),
        "n_low_margin_below_0_05": int(np.sum(
            (ordered_family_weights[:, -1] - ordered_family_weights[:, -2]) < 0.05)),
        "ari_vs_clean_factor_k6": float(adjusted_rand_score(family_code, aligned_labels)),
        "ari_vs_mixed_distance_k6": float(
            adjusted_rand_score(family_code, gower_labels[0.75])),
        "per_family": {},
        "nearest_centroid_10_fold_cv": cv,
    }
    for family in OUTCOME_FAMILIES:
        m = editorial_family == family
        family_shared_positions = np.where(m & scores.index.isin(shared_ids))[0]
        original_clusters = Counter(
            aligned for aligned in old_cluster_full.iloc[family_shared_positions].dropna().astype(int).tolist())
        outcome_summary["per_family"][family] = {
            "n": int(m.sum()),
            "mean_factor_space_silhouette": float(outcome_sil_factor[m].mean()),
            "mean_mixed_distance_silhouette": float(outcome_sil_gower[m].mean()),
            "prototype_conflicts": int(np.sum(nearest_family[m] != family)),
            "low_margin_below_0_05": int(np.sum(
                (ordered_family_weights[m, -1] - ordered_family_weights[m, -2]) < 0.05)),
            "frozen_cluster_composition": {str(k): int(v) for k, v in sorted(original_clusters.items())},
        }

    # Project-clearance cases need individual review because their shared outcome
    # deliberately cuts across several statistical neighborhoods.
    clearance_review = family_df[project_mask].copy()
    clearance_review = clearance_review.sort_values(
        ["prototype_conflict", "own_family_weight", "top_two_margin"],
        ascending=[False, True, True])
    clearance_review.to_csv(OUT / "land_clearance_case_review.csv", float_format="%.5f")

    # Boundary queue combines weak statistical fit and weak editorial fit.
    boundary = family_df.copy()
    boundary["statistical_cluster_silhouette"] = sil
    boundary["statistical_soft_margin"] = clean_clusters["soft_margin"]
    boundary["boundary_priority"] = (
        (boundary["factor_space_silhouette"] < 0).astype(int) * 3
        + boundary["prototype_conflict"].astype(int) * 2
        + (boundary["top_two_margin"] < 0.05).astype(int) * 2
        + (boundary["statistical_cluster_silhouette"] < 0).astype(int) * 2
        + (boundary["statistical_soft_margin"] < 0.05).astype(int)
    )
    boundary.sort_values(
        ["boundary_priority", "factor_space_silhouette", "top_two_margin"],
        ascending=[False, True, True]).head(100).to_csv(
            OUT / "boundary_review_queue.csv", float_format="%.5f")

    analysis = {
        "version": args.run_label,
        "created": "2026-08-17",
        "n_events": int(len(scores)),
        "n_shared_with_first_pass": int(len(shared_ids)),
        "n_added_after_first_pass": int(len(added_ids)),
        "n_dimensions": int(scores.shape[1]),
        "factor_model": {
            "parallel_analysis_factors": k_parallel,
            "retained_for_comparison_and_case_cards": 8,
            "parallel_analysis_eigenvalues_first_15": eigenvalues[:15].tolist(),
            "parallel_analysis_thresholds_first_15": thresholds[:15].tolist(),
            "factor_alignment": factor_alignment,
            "old_vs_clean_factor_score_correlations": score_correlations,
            "era_balanced_loading_alignment": balanced_alignment,
            "era_balanced_subspace_sensitivity": era_balanced_subspaces,
            "mean_communality": float(np.mean(fa.get_communalities())),
            "variance_explained_proportion": fa.get_factor_variance()[1].tolist(),
            "variance_explained_cumulative": fa.get_factor_variance()[2].tolist(),
        },
        "clean_k6": cluster_summary,
        "era": era_summary,
        "structural_missingness": gower_results,
        "outcome_first_hypothesis": outcome_summary,
    }
    write_json(OUT / "second_pass_results.json", analysis)

    manifest_paths = [
        OUT / "loadings_aligned.csv",
        OUT / "factor_scores_aligned.csv",
        OUT / "clean_k6_assignments.csv",
        OUT / "eight_trait_card_values.csv",
        OUT / "era_profiles.csv",
        OUT / "loadings_era_balanced.csv",
        OUT / "structural_distance_clusters.csv",
        OUT / "mixed_distance_penalty_0_75.npy",
        OUT / "outcome_family_diagnostics.csv",
        OUT / "land_clearance_case_review.csv",
        OUT / "boundary_review_queue.csv",
        OUT / "second_pass_results.json",
    ]
    manifest_inputs = {
        "scores_v2.csv": sha256(DATA / "scores_v2.csv"),
        "na_types_v2.csv": sha256(DATA / "na_types_v2.csv"),
        "corpus_v2.json": sha256(DATA / "corpus_v2.json"),
        "generator": sha256(Path(__file__).resolve()),
        "first_pass_loadings": sha256(
            BASE / "results" / "loadings_oblimin_main.csv"
        ),
        "first_pass_factor_scores": sha256(
            BASE / "results" / "factor_scores_main.csv"
        ),
        "first_pass_k6_labels": sha256(
            BASE / "results" / "final_k6_assignments.csv"
        ),
    }
    if args.family_hypotheses:
        manifest_inputs["family_hypotheses"] = sha256(
            args.family_hypotheses.resolve()
        )
    write_json(OUT / "results_manifest.json", {
        "status": "reproducible_statistical_output",
        "generator": str(Path(__file__).resolve()),
        "run_label": args.run_label,
        "invocation": {
            "data_dir": str(DATA),
            "out_dir": str(OUT),
            "family_hypotheses": (
                str(args.family_hypotheses.resolve())
                if args.family_hypotheses
                else None
            ),
        },
        "runtime": {
            "python": sys.version.split()[0],
            "python_executable": str(Path(sys.executable)),
            "platform": platform.platform(),
            "packages": {
                distribution: importlib.metadata.version(distribution)
                for distribution in (
                    "numpy",
                    "pandas",
                    "scipy",
                    "scikit-learn",
                    "factor-analyzer",
                )
            },
        },
        "randomness": {
            "global_seed": SEED,
            "kmeans_random_state": 0,
            "kmeans_n_init": 100,
        },
        "inputs": {
            **manifest_inputs,
        },
        "outputs": {path.name: sha256(path) for path in manifest_paths},
    })

    print(json.dumps({
        "run_label": args.run_label,
        "n_events": int(len(scores)),
        "parallel_analysis_factors": k_parallel,
        "factor_congruence": [round(v["tucker_congruence"], 3)
                               for v in factor_alignment],
        "clean_k6_ari_vs_first_pass": round(cluster_summary["ari_vs_first_pass"], 3),
        "clean_k6_changed": cluster_summary["n_changed_after_label_alignment"],
        "clean_k6_silhouette": round(cluster_summary["mean_silhouette"], 3),
        "clean_k6_bootstrap_jaccard": round(stability["mean_jaccard"], 3),
        "structural_ari_vs_factor_k6_at_0_75": round(
            gower_results["penalty_0.75"]["ari_vs_clean_factor_k6"], 3),
        "outcome_family_sizes": outcome_summary["sizes"],
        "outcome_family_silhouette": round(
            outcome_summary["mean_factor_space_silhouette"], 3),
        "outcome_prototype_conflicts": outcome_summary["n_prototype_conflicts"],
    }, indent=1))


if __name__ == "__main__":
    main()
