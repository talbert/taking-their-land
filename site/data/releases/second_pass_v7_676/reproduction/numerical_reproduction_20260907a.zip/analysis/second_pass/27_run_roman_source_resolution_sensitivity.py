#!/usr/bin/env python3
"""Run every executable Roman source-resolution sensitivity scenario.

Median and replicated-node rows are diagnostic pseudo-observations. They never
enter a corpus or atlas. All eleven linked wrappers are canonically retained,
and the 583-event candidate remains unchanged.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.stats import spearmanr
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REGISTRY = HERE / "roman_sensitivity_registry.json"
LINKED_RESOLUTIONS = HERE / "roman_linked_event_resolutions.csv"
ROMAN_ADDITIONS = HERE / "roman_additions.json"
RECODE = HERE / "roman_apuan_recode.json"
ACTIVE_DATA = HERE / "data"
PARENT_DATA = HERE / "roman_candidates" / "parent_only_546"
FULL_DATA = HERE / "roman_candidates" / "full_583"
FULL_RESULTS = FULL_DATA / "results"
OUT = HERE / "roman_candidates" / "sensitivity_results"
OUT_JSON = OUT / "roman_source_resolution_sensitivity.json"
OUT_SCENARIOS = OUT / "roman_source_resolution_scenarios.csv"
OUT_FACTORS = OUT / "roman_source_resolution_factor_metrics.csv"
OUT_MANIFEST = OUT / "results_manifest.json"

CAESARIAN_PARENT = "med-roman-caesarian-augustan-veteran-colonies"
SEED = 12082026


def load_pipeline_module():
    spec = importlib.util.spec_from_file_location(
        "second_pass_pipeline_roman_resolution", HERE / "12_run_second_pass.py"
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load second-pass pipeline module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PIPELINE = load_pipeline_module()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tucker(a: pd.Series, b: pd.Series) -> float:
    denominator = float(np.sqrt(np.dot(a, a) * np.dot(b, b)))
    return float(np.dot(a, b) / denominator) if denominator else 0.0


def safe_rho(a: pd.Series, b: pd.Series) -> float:
    value, _ = spearmanr(a, b)
    return float(value) if np.isfinite(value) else 0.0


def fit_scenario(
    scores: pd.DataFrame, reference_loadings: pd.DataFrame
) -> dict[str, Any]:
    imputed = scores.fillna(scores.median())
    fa = FactorAnalyzer(n_factors=8, rotation="oblimin", method="minres")
    fa.fit(imputed.values)
    raw_loadings = pd.DataFrame(
        fa.loadings_, index=scores.columns, columns=[f"N{i + 1}" for i in range(8)]
    )
    raw_scores = pd.DataFrame(
        fa.transform(imputed.values), index=scores.index, columns=raw_loadings.columns
    )
    loadings, factors, alignment = PIPELINE.align_factors(
        reference_loadings, raw_loadings, raw_scores
    )
    kmeans = KMeans(n_clusters=6, n_init=100, random_state=0).fit(factors.values)
    return {
        "loadings": loadings,
        "factors": factors,
        "labels": kmeans.labels_,
        "inertia": float(kmeans.inertia_),
        "silhouette": float(silhouette_score(factors.values, kmeans.labels_)),
        "alignment": alignment,
    }


def median_rows(
    scores: pd.DataFrame,
    member_ids: list[str],
    scenario: str,
    family_by_id: dict[str, str] | None = None,
) -> pd.DataFrame:
    if family_by_id is None:
        row = scores.loc[member_ids].median(axis=0, skipna=True)
        return pd.DataFrame([row], index=[f"__roman_resolution_{scenario}"])
    rows = []
    names = []
    families = sorted({family_by_id[event_id] for event_id in member_ids})
    for family in families:
        ids = [event_id for event_id in member_ids if family_by_id[event_id] == family]
        rows.append(scores.loc[ids].median(axis=0, skipna=True))
        names.append(f"__roman_resolution_{scenario}_{family}")
    return pd.DataFrame(rows, index=names, columns=scores.columns)


def compare(
    scenario: str,
    mode: str,
    scores: pd.DataFrame,
    fit: dict[str, Any],
    reference_scores: pd.DataFrame,
    reference_loadings: pd.DataFrame,
    reference_factors: pd.DataFrame,
    reference_labels: pd.Series,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    shared = reference_scores.index.intersection(scores.index)
    scenario_positions = scores.index.get_indexer(shared)
    prior_labels = reference_labels.loc[shared].astype(int).values
    scenario_labels = fit["labels"][scenario_positions]
    aligned_labels, _, _ = PIPELINE.align_cluster_labels(prior_labels, scenario_labels)

    factor_rows = []
    for factor in reference_loadings.columns:
        congruence = abs(tucker(reference_loadings[factor], fit["loadings"][factor]))
        rho = safe_rho(reference_factors.loc[shared, factor], fit["factors"].loc[shared, factor])
        factor_rows.append(
            {
                "scenario": scenario,
                "mode": mode,
                "factor": factor,
                "loading_tucker_vs_full_583": congruence,
                "shared_score_spearman_vs_full_583": rho,
            }
        )
    congruences = [row["loading_tucker_vs_full_583"] for row in factor_rows]
    correlations = [row["shared_score_spearman_vs_full_583"] for row in factor_rows]
    changed = int(np.sum(prior_labels != aligned_labels))
    result = {
        "scenario": scenario,
        "mode": mode,
        "events_or_pseudo_events": int(len(scores)),
        "shared_full_candidate_events": int(len(shared)),
        "pseudo_rows": int(sum(str(index).startswith("__roman_resolution_") for index in scores.index)),
        "factor_loading_tucker_min": float(min(congruences)),
        "factor_loading_tucker_mean": float(np.mean(congruences)),
        "shared_factor_score_spearman_min": float(min(correlations)),
        "shared_factor_score_spearman_mean": float(np.mean(correlations)),
        "k6_adjusted_rand_vs_full_583": float(adjusted_rand_score(prior_labels, scenario_labels)),
        "k6_changed_after_label_alignment": changed,
        "k6_changed_share": float(changed / len(shared)),
        "k6_silhouette": fit["silhouette"],
        "k6_inertia": fit["inertia"],
        "material_flag": bool(
            min(congruences) < 0.85
            or min(correlations) < 0.90
            or changed / len(shared) > 0.05
        ),
    }
    return result, factor_rows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    registry = json.loads(REGISTRY.read_text())
    if registry.get("status") != "all_named_roman_sensitivity_groups_dispositioned":
        raise ValueError("Roman sensitivity registry is not complete")
    full_scores = pd.read_csv(FULL_DATA / "scores_v2.csv", index_col="event_id").astype(float)
    parent_scores = pd.read_csv(PARENT_DATA / "scores_v2.csv", index_col="event_id").astype(float)
    active_scores = pd.read_csv(ACTIVE_DATA / "scores_v2.csv", index_col="event_id").astype(float)
    if len(full_scores) != 583 or len(parent_scores) != 546 or len(active_scores) != 490:
        raise ValueError("Roman sensitivity input counts changed")

    reference_loadings = pd.read_csv(FULL_RESULTS / "loadings_aligned.csv", index_col=0)
    reference_factors = pd.read_csv(FULL_RESULTS / "factor_scores_aligned.csv", index_col=0)
    reference_assignments = pd.read_csv(FULL_RESULTS / "clean_k6_assignments.csv", index_col=0)
    reference_labels = reference_assignments["cluster"].astype(int)
    if not (
        list(reference_factors.index) == list(full_scores.index)
        and list(reference_labels.index) == list(full_scores.index)
    ):
        raise ValueError("Full-candidate result rows differ from full-candidate scores")

    additions = json.loads(ROMAN_ADDITIONS.read_text())
    family_by_id = {
        item["event"]["event_id"]: item["editorial_family_hypothesis"]
        for item in additions
    }
    recode = json.loads(RECODE.read_text())
    family_by_id[recode["event"]["event_id"]] = "state_directed_demographic_remaking"

    scenarios: dict[str, tuple[str, pd.DataFrame]] = {
        "active_490_broad_parent_baseline": ("candidate_comparison", active_scores),
        "parent_only_546": ("candidate_comparison", parent_scores),
    }
    group_metadata = {record["group"]: record for record in registry["groups"]}

    for record in registry["groups"]:
        group = record["group"]
        members = record["member_event_ids"]
        mode = record["mode"]
        if mode == "aggregate_existing_event_profiles":
            base = full_scores.drop(index=members)
            one_name = f"{group}__one_group_median"
            scenarios[one_name] = (
                "one_group_median",
                pd.concat([base, median_rows(full_scores, members, one_name)]),
            )
            family_name = f"{group}__outcome_family_medians"
            scenarios[family_name] = (
                "outcome_family_medians",
                pd.concat(
                    [
                        base,
                        median_rows(
                            full_scores,
                            members,
                            family_name,
                            family_by_id=family_by_id,
                        ),
                    ]
                ),
            )
            scenarios[f"{group}__leave_group_out"] = (
                "leave_group_out",
                base,
            )
        elif mode == "linked_event_resolution_upper_bound":
            event_id = members[0]
            base = full_scores.drop(index=event_id)
            replication_name = f"{group}__identical_node_replication_upper_bound"
            node_count = int(record["diagnostic_node_count"])
            copies = pd.DataFrame(
                [full_scores.loc[event_id]] * node_count,
                index=[
                    f"__roman_resolution_{group}_node_{index + 1}"
                    for index in range(node_count)
                ],
                columns=full_scores.columns,
            )
            scenarios[replication_name] = (
                "identical_node_replication_upper_bound",
                pd.concat([base, copies]),
            )
            scenarios[f"{group}__leave_event_out"] = ("leave_event_out", base)
        elif mode == "active_parent_chronology_boundary":
            scenarios[f"{group}__drop_sullan_boundary_children"] = (
                "drop_boundary_children",
                full_scores.drop(index=members),
            )
            if CAESARIAN_PARENT not in full_scores.index:
                raise ValueError("Caesarian-Augustan parent is absent from full candidate")
            scenarios[f"{group}__drop_later_caesarian_parent"] = (
                "drop_later_parent_upper_bound",
                full_scores.drop(index=CAESARIAN_PARENT),
            )
        elif mode == "later_deduction_boundary":
            scenarios[f"{group}__leave_118_event_out"] = (
                "leave_event_out",
                full_scores.drop(index=members),
            )

    expected_scenarios = int(registry["executable_scenarios"]) + 2
    if len(scenarios) != expected_scenarios:
        raise ValueError(
            f"Expected {expected_scenarios} non-reference scenarios, found {len(scenarios)}"
        )

    results = {
        "full_583_reference": {
            "scenario": "full_583_reference",
            "mode": "reference",
            "events_or_pseudo_events": 583,
            "shared_full_candidate_events": 583,
            "pseudo_rows": 0,
            "factor_loading_tucker_min": 1.0,
            "factor_loading_tucker_mean": 1.0,
            "shared_factor_score_spearman_min": 1.0,
            "shared_factor_score_spearman_mean": 1.0,
            "k6_adjusted_rand_vs_full_583": 1.0,
            "k6_changed_after_label_alignment": 0,
            "k6_changed_share": 0.0,
            "k6_silhouette": float(reference_assignments["silhouette"].mean()),
            "k6_inertia": None,
            "material_flag": False,
        }
    }
    factor_rows: list[dict[str, Any]] = []
    for index, (name, (mode, scores)) in enumerate(scenarios.items(), start=1):
        print(f"[{index}/{len(scenarios)}] {name}", flush=True)
        fit = fit_scenario(scores, reference_loadings)
        result, rows = compare(
            name,
            mode,
            scores,
            fit,
            full_scores,
            reference_loadings,
            reference_factors,
            reference_labels,
        )
        results[name] = result
        factor_rows.extend(rows)

    scenario_frame = pd.DataFrame(results.values()).sort_values(
        ["material_flag", "k6_changed_share", "factor_loading_tucker_min"],
        ascending=[False, False, True],
    )
    scenario_frame.to_csv(OUT_SCENARIOS, index=False, float_format="%.10f")
    pd.DataFrame(factor_rows).to_csv(OUT_FACTORS, index=False, float_format="%.10f")

    material = scenario_frame[scenario_frame["material_flag"] == True]  # noqa: E712
    non_reference = scenario_frame[scenario_frame["mode"] != "reference"]
    worst_loading = non_reference.nsmallest(10, "factor_loading_tucker_min")[
        ["scenario", "mode", "factor_loading_tucker_min"]
    ].to_dict("records")
    worst_cluster = non_reference.nlargest(10, "k6_changed_share")[
        ["scenario", "mode", "k6_changed_after_label_alignment", "k6_changed_share"]
    ].to_dict("records")

    output = {
        "status": "validated_roman_source_resolution_sensitivity",
        "checkpoint_date": "2026-08-20",
        "active_event_register_unchanged": True,
        "active_events": 490,
        "reference_candidate_events": 583,
        "named_groups_dispositioned": registry["named_groups"],
        "executable_group_scenarios": registry["executable_scenarios"],
        "candidate_comparison_scenarios": 2,
        "total_scenarios_including_reference": len(results),
        "linked_event_canonical_resolutions_complete": registry[
            "linked_single_event_resolutions_complete"
        ],
        "linked_groups_retained_as_canonical_events": registry[
            "linked_single_event_resolutions_complete"
        ],
        "linked_groups_with_true_node_profiles_pending": registry[
            "linked_single_event_node_profiles_pending"
        ],
        "canonical_event_count_effect_of_linked_resolutions": registry[
            "canonical_event_count_effect"
        ],
        "material_flag_rule": (
            "minimum factor-loading Tucker congruence below 0.85, minimum shared-event "
            "factor-score Spearman below 0.90, or more than 5% of shared events changing "
            "aligned k=6 cluster"
        ),
        "material_scenario_count": int(len(material)),
        "material_scenarios": material["scenario"].tolist(),
        "worst_loading_scenarios": worst_loading,
        "worst_cluster_scenarios": worst_cluster,
        "scenarios": results,
        "group_registry": group_metadata,
        "interpretation_rule": (
            "Median and replicated-node rows are diagnostic only. A median result can "
            "show source-density leverage but cannot erase valid events; identical-node "
            "replication is only an upper-bound weighting test. Source review retains all "
            "eleven linked wrappers as canonical events; independently sourced local "
            "profiles become necessary only if new evidence reopens a node-level split."
        ),
    }
    OUT_JSON.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
    inputs = [
        REGISTRY,
        LINKED_RESOLUTIONS,
        ROMAN_ADDITIONS,
        RECODE,
        ACTIVE_DATA / "scores_v2.csv",
        PARENT_DATA / "scores_v2.csv",
        FULL_DATA / "scores_v2.csv",
        FULL_RESULTS / "loadings_aligned.csv",
        FULL_RESULTS / "factor_scores_aligned.csv",
        FULL_RESULTS / "clean_k6_assignments.csv",
        HERE / "12_run_second_pass.py",
        HERE / "26_build_roman_sensitivity_registry.py",
        HERE / "27_run_roman_source_resolution_sensitivity.py",
    ]
    OUT_MANIFEST.write_text(
        json.dumps(
            {
                "inputs": {str(path.relative_to(BASE)): sha256(path) for path in inputs},
                "outputs": {
                    path.name: sha256(path)
                    for path in (OUT_JSON, OUT_SCENARIOS, OUT_FACTORS)
                },
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "status": output["status"],
                "total_scenarios": output["total_scenarios_including_reference"],
                "material_scenario_count": output["material_scenario_count"],
                "linked_canonical_resolutions_complete": output[
                    "linked_event_canonical_resolutions_complete"
                ],
                "linked_true_node_profiles_pending": output[
                    "linked_groups_with_true_node_profiles_pending"
                ],
                "active_event_register_unchanged": True,
                "output": str(OUT_JSON.relative_to(HERE)),
            },
            indent=1,
        )
    )


if __name__ == "__main__":
    main()
