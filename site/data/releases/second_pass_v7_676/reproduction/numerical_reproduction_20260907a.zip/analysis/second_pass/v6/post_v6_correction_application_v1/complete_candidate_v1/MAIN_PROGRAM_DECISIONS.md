# Main program-input decisions

2026-09-07. Prospective decisions, before any corrected-data model fit.
These complete the finite projection; they are not a result, release vote,
new historical admission or public deployment. Main has read the saved
projection builder, its tests, the actual archived parent metadata, the
relevant original controls and the execution contract.

## Historical parents and geography

Use the seventy actual parent profiles selected by the established61+9
archive rule. Keep all raw values, U/NA, dates and original metadata unchanged.
Construct their analysis joins from their own metadata and original
dimension-specific codebook horizons, not their children's dates or scores.
An archive's unflagged nominal date is not exact chronology. Explicit proxies
stay excluded from continuous-date diagnostics. No movement-duration series
is available and no calendar subtraction supplies one. These historical
counterfactuals neither reinstate the parents nor claim their old evidence is
the accepted current definition.

Use the established sixteen-category vocabulary and exact raw-region rules.
The finite exceptions for broad archive labels are recorded by exact ID in
the builder: Saint-Pierre is NORTH_AMERICA; St Helena SOUTHERN_AFRICA; the
Canaries NORTH_AFRICA; the named Israeli-settlement, Kuwait and Palestinian
displacement parents WEST_ASIA; Christmas/Cocos SOUTHEAST_ASIA; Melanesia and
Queensland OCEANIA. Broad Africa/Indian-Ocean, Caucasus/Russia/Central-Asia,
Baltic/Soviet-interior, Ottoman-Circassian, Egyptian/Mediterranean and
Indochinese/Pacific wrappers remain explicitly MULTIREGIONAL. Safavid
Caucasus/Iran is WEST_ASIA under the same territory vocabulary. This is
normalization of the archived units, not an actor-nationality assignment or
a newly reviewed seventy-event geography corpus. Parent swaps retain their
different event definitions and nominal date limits openly.

## Date-only alternatives

Bind exact whole-roster metadata variants for Antioch253 and256, Dura256
and257, and Egypt640 versus the accepted639 start. Antioch's canonical start
remains null; Dura retains its approximate preferred256. The chosen dates are
explicit counterfactual nominal coordinates, not evidence that a disputed
date became certain. Mark them eligible only within their labeled alternative
diagnostic. Preserve each era, raw score, U/NA and observation horizon. Single-
capture alternatives use the same alternate start/end; Egypt retains646 as
its closing fence. No alternative creates movement duration or extra events.
Tigranokerta's requested missing-date variant is already the canonical state;
record that identity without inventing a new coordinate.

## Program weights and legacy repeated-node stresses

Accept the literal77-group total-one vector:170 disjoint members, all other
rows weight1. It is explicitly not a global solution to historical dependence.
Broader overlapping Roman controls remain separate omissions. Unqi and
Tīl-karme and the two Circeii actions do not become one event through a weight
assignment; their accepted scope rulings still govern.

The current execution plan specifies illustrative upper-bound weighting, not
construction of synthetic historical rows. Implement the four old Roman
overcount magnitudes as labeled influence weights on their actual complete
profiles: Pometia2, Velitrae2, Veii3, Marian-Africa4. Retain Shapur3 on the same
basis. Do not recreate old identical-node expansions or median/family pseudo-
profiles. This is a prospective, explicit method translation: weighted676-row
diagnostics are not a numerical reproduction of expanded-row imputation or
expanded-n Horn thresholds. The latter remain historical results. The new
comparison keeps canonical imputation and actual row count, testing influence
without pretending repeated values are independent evidence. No weighted
variant enters the historical corpus or changes the canonical event count.

## Explicit limits and deferred public work

The independently uncoded Egypt-through642-only and internal Kitakami-phase
profiles remain unestimable, with no new coding request. Existing whole-
program, real-parent, omission and date/horizon diagnostics are available.
Family-only comparisons remain editorial, not new factor fits. Source and
public-output corrections retained in the authority ledger are downstream
obligations, not completed merely because the registry consumes their IDs.

Once final input validation passes, main may authorize the already approved
diagnostic cycle on the complete candidate. One bounded independent check and
main disposition still precede promotion. No results were used to choose
these alternatives, and stability cannot authenticate historical boundaries.
