#!/usr/bin/env python3
"""Test factor-subspace stability on the scope-corrected 676 candidate."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.linalg import subspace_angles
from scipy.optimize import linear_sum_assignment
from sklearn.impute import KNNImputer


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
SECOND = ROOT / "analysis" / "second_pass"
CANDIDATES = HERE / "candidate_models_v2"
SUCCESSOR = CANDIDATES / "canonical_successor_676"
PARENT = CANDIDATES / "corrected_parent_reference_580"
PRIOR = SECOND / "v5" / "recode_application_v1" / "model_rerun_v1" / "candidates" / "corrected_full_equal_event_675"
GROUPS = CANDIDATES / "sensitivity_groups.csv"
DISPOSITIONS = CANDIDATES / "parent_replacement_dispositions.csv"
OUT = CANDIDATES / "subspace_stability_v2"
EVENTS = OUT / "event_subspace_influence.csv"
PROGRAMS = OUT / "program_subspace_sensitivity.csv"
SCENARIOS = OUT / "scenario_subspace_sensitivity.csv"
SUMMARY = OUT / "SUBSPACE_STABILITY_SUMMARY.json"
MANIFEST = OUT / "RESULTS_MANIFEST.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def render(rows: list[dict[str, Any]]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def load_dataset(path: Path) -> dict[str, Any]:
    data = path / "data"
    scores = pd.read_csv(data / "scores_v2.csv", index_col="event_id").astype(float)
    na_types = pd.read_csv(
        data / "na_types_v2.csv", index_col="event_id", keep_default_na=False, dtype=str
    ).loc[scores.index]
    corpus_all = pd.DataFrame(json.loads((data / "corpus_v2.json").read_text(encoding="utf-8")))
    corpus = corpus_all[corpus_all["in_model"] == True].set_index("event_id").loc[scores.index]  # noqa: E712
    return {"scores": scores, "na_types": na_types, "corpus": corpus}


def fit_loadings(
    matrix: pd.DataFrame,
    factors: int,
    *,
    correlation: np.ndarray | None = None,
) -> pd.DataFrame:
    analyzer = FactorAnalyzer(
        n_factors=factors,
        rotation="oblimin",
        method="minres",
        is_corr_matrix=correlation is not None,
    )
    analyzer.fit(correlation if correlation is not None else matrix.values)
    return pd.DataFrame(
        analyzer.loadings_,
        index=matrix.columns,
        columns=[f"N{index + 1}" for index in range(factors)],
    )


def loading_congruence(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    numerator = left.T @ right
    denominator = np.sqrt(
        (left * left).sum(axis=0)[:, None] * (right * right).sum(axis=0)[None, :]
    )
    return np.divide(numerator, denominator, out=np.zeros_like(numerator), where=denominator != 0)


def compare(reference: pd.DataFrame, candidate: pd.DataFrame) -> dict[str, float]:
    angles = np.degrees(subspace_angles(reference.values, candidate.values))
    congruence = loading_congruence(reference.values, candidate.values)
    left, right = linear_sum_assignment(-np.abs(congruence))
    aligned = [abs(float(congruence[lindex, rindex])) for lindex, rindex in zip(left, right)]
    return {
        "maximum_principal_angle_degrees": float(max(angles)),
        "mean_principal_angle_degrees": float(np.mean(angles)),
        "minimum_principal_angle_cosine": float(min(np.cos(np.radians(angles)))),
        "minimum_aligned_axis_tucker": float(min(aligned)),
        "mean_aligned_axis_tucker": float(np.mean(aligned)),
    }


def comparison_fields(prefix: str, values: dict[str, float]) -> dict[str, float]:
    return {f"{prefix}_{field}": value for field, value in values.items()}


def weighted_correlation(values: np.ndarray, weights: np.ndarray) -> np.ndarray:
    normalized = weights / weights.sum()
    mean = np.sum(values * normalized[:, None], axis=0)
    centered = values - mean
    covariance = (centered * normalized[:, None]).T @ centered
    scale = np.sqrt(np.diag(covariance))
    correlation = covariance / np.outer(scale, scale)
    correlation = np.nan_to_num(correlation, nan=0.0)
    np.fill_diagonal(correlation, 1.0)
    return correlation


def era_imputation(scores: pd.DataFrame, eras: pd.Series) -> pd.DataFrame:
    result = scores.copy()
    for _, ids in eras.groupby(eras).groups.items():
        ids = result.index.intersection(ids)
        result.loc[ids] = result.loc[ids].fillna(result.loc[ids].median())
    return result.fillna(scores.median())


def structural_zero_imputation(scores: pd.DataFrame, na_types: pd.DataFrame) -> pd.DataFrame:
    result = scores.copy()
    medians = scores.median()
    for column in result.columns:
        result.loc[na_types[column] == "NA", column] = 0.0
        result.loc[na_types[column] == "U", column] = medians[column]
    return result


def knn_imputation(scores: pd.DataFrame, na_types: pd.DataFrame) -> pd.DataFrame:
    staged = scores.copy()
    medians = scores.median()
    for column in staged.columns:
        staged.loc[na_types[column] == "NA", column] = medians[column]
    values = KNNImputer(n_neighbors=10, weights="distance").fit_transform(staged)
    return pd.DataFrame(values, index=scores.index, columns=scores.columns)


def complete_parent(parent: dict[str, Any], prior: dict[str, Any]) -> pd.DataFrame:
    ids = [
        row["parent_event_id"]
        for row in read_csv(DISPOSITIONS)
        if row["active_in_v4"] == "false"
    ]
    return pd.concat([parent["scores"], prior["scores"].loc[ids]])


def group_register() -> dict[str, dict[str, list[str]]]:
    return {
        row["sensitivity_group_id"]: {
            "parents": [part.strip() for part in row["parent_event_ids"].split("|") if part.strip()],
            "targets": [part.strip() for part in row["target_event_ids"].split("|") if part.strip()],
        }
        for row in read_csv(GROUPS)
    }


def build() -> dict[str, Any]:
    successor = load_dataset(SUCCESSOR)
    parent = load_dataset(PARENT)
    prior = load_dataset(PRIOR)
    scores = successor["scores"]
    na_types = successor["na_types"]
    corpus = successor["corpus"]
    if len(scores) != 676:
        raise RuntimeError("successor count differs")
    imputed = scores.fillna(scores.median())
    reference8 = fit_loadings(imputed, 8)
    reference9 = fit_loadings(imputed, 9)
    event_rows: list[dict[str, Any]] = []
    for order, event_id in enumerate(scores.index, start=1):
        subset = imputed.drop(index=event_id)
        loadings8 = fit_loadings(subset, 8)
        loadings9 = fit_loadings(subset, 9)
        event_rows.append(
            {
                "event_id": event_id,
                "membership_origin": (
                    "prospective_successor"
                    if str(corpus.loc[event_id].get("origin", "")) == "event_unit_fairness_candidate_v1"
                    else "v4_retained"
                ),
                **comparison_fields("eight_factor", compare(reference8, loadings8)),
                **comparison_fields("nine_factor", compare(reference9, loadings9)),
            }
        )
        if order % 100 == 0:
            print(f"subspace_event_progress={order}/676", flush=True)
    event_rows.sort(
        key=lambda row: (
            -row["eight_factor_maximum_principal_angle_degrees"],
            row["event_id"],
        )
    )

    groups = group_register()
    complete = complete_parent(parent, prior)
    program_rows: list[dict[str, Any]] = []
    for group_id, members in groups.items():
        for mode, matrix in (
            (
                "swap_successors_to_parents",
                pd.concat([scores.drop(index=members["targets"]), complete.loc[members["parents"]]]),
            ),
            ("leave_program_out", scores.drop(index=members["targets"])),
        ):
            candidate = matrix.fillna(matrix.median())
            program_rows.append(
                {
                    "sensitivity_group_id": group_id,
                    "mode": mode,
                    "rows": len(candidate),
                    "parent_count": len(members["parents"]),
                    "target_count": len(members["targets"]),
                    **comparison_fields("eight_factor", compare(reference8, fit_loadings(candidate, 8))),
                    **comparison_fields("nine_factor", compare(reference9, fit_loadings(candidate, 9))),
                }
            )

    proxy_mask = corpus.get("date_numeric_proxy_used", False).fillna(False).astype(bool)
    proxy_ids = list(corpus.index[proxy_mask])
    targets = [target for members in groups.values() for target in members["targets"]]
    grouped = scores.drop(index=targets)
    pseudo = pd.DataFrame(
        [scores.loc[members["targets"]].median(axis=0, skipna=True) for members in groups.values()],
        index=[f"__group_{group}" for group in groups],
        columns=scores.columns,
    )
    grouped = pd.concat([grouped, pseudo])
    scenario_matrices: dict[str, tuple[str, pd.DataFrame]] = {
        "global_median": ("imputation", imputed),
        "era_specific_median": ("imputation", era_imputation(scores, corpus["era_bucket_v2"])),
        "unknown_knn_structural_median": ("imputation", knn_imputation(scores, na_types)),
        "unknown_median_structural_zero_bound": ("imputation", structural_zero_imputation(scores, na_types)),
        "canonical_without_date_proxies": (
            "membership",
            scores.drop(index=proxy_ids).fillna(scores.drop(index=proxy_ids).median()),
        ),
        "grouped_program_medians": ("membership", grouped.fillna(grouped.median())),
        "complete_parent_alternative": (
            "membership",
            complete.fillna(complete.median()),
        ),
        "prior_corrected_hellenistic_675": (
            "membership",
            prior["scores"].fillna(prior["scores"].median()),
        ),
    }
    scenario_rows: list[dict[str, Any]] = []
    for name, (mode, matrix) in scenario_matrices.items():
        scenario_rows.append(
            {
                "scenario": name,
                "mode": mode,
                "rows": len(matrix),
                **comparison_fields("eight_factor", compare(reference8, fit_loadings(matrix, 8))),
                **comparison_fields("nine_factor", compare(reference9, fit_loadings(matrix, 9))),
            }
        )
    era_counts = corpus["era_bucket_v2"].value_counts()
    era_weights = corpus["era_bucket_v2"].map(lambda value: 1.0 / era_counts[value]).to_numpy(dtype=float)
    program_weights = np.ones(len(scores), dtype=float)
    for members in groups.values():
        for event_id in members["targets"]:
            program_weights[scores.index.get_loc(event_id)] = 1.0 / len(members["targets"])
    for name, weights in (
        ("equal_total_weight_per_era", era_weights),
        ("linked_successor_program_total_weight_one", program_weights),
    ):
        correlation = weighted_correlation(imputed.values, weights)
        scenario_rows.append(
            {
                "scenario": name,
                "mode": "weighted_correlation",
                "rows": len(imputed),
                **comparison_fields(
                    "eight_factor",
                    compare(reference8, fit_loadings(imputed, 8, correlation=correlation)),
                ),
                **comparison_fields(
                    "nine_factor",
                    compare(reference9, fit_loadings(imputed, 9, correlation=correlation)),
                ),
            }
        )

    outputs = {
        EVENTS: render(event_rows),
        PROGRAMS: render(program_rows),
        SCENARIOS: render(scenario_rows),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    for path, content in outputs.items():
        path.write_bytes(content)

    def angle_summary(rows: list[dict[str, Any]], prefix: str) -> dict[str, Any]:
        values = np.asarray([row[f"{prefix}_maximum_principal_angle_degrees"] for row in rows])
        return {
            "minimum": float(values.min()),
            "median": float(np.median(values)),
            "percentile_95": float(np.percentile(values, 95)),
            "maximum": float(values.max()),
            "count_above_5_degrees": int(np.sum(values > 5.0)),
            "count_above_10_degrees": int(np.sum(values > 10.0)),
        }

    summary = {
        "schema": "event-unit-factor-subspace-stability-v1",
        "status": "diagnostic_complete_not_release_authorized",
        "candidate": "canonical_successor_676",
        "leave_one_event_out": {
            "events_tested": len(event_rows),
            "eight_factor_maximum_principal_angle": angle_summary(event_rows, "eight_factor"),
            "nine_factor_maximum_principal_angle": angle_summary(event_rows, "nine_factor"),
        },
        "program_scenarios": {
            "scenarios_tested": len(program_rows),
            "eight_factor_maximum_principal_angle": angle_summary(program_rows, "eight_factor"),
            "nine_factor_maximum_principal_angle": angle_summary(program_rows, "nine_factor"),
        },
        "interpretation_rule": (
            "Principal angles assess the factor space as a whole. Small angles alongside "
            "low per-axis Tucker values indicate rotation or splitting within a stable "
            "subspace; they do not rescue any particular named axis or factor count."
        ),
        "candidate_activation_authorized": False,
        "fairness_conclusion_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    SUMMARY.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    input_paths = [
        Path(__file__).resolve(),
        GROUPS,
        DISPOSITIONS,
        *[
            root / "data" / filename
            for root in (SUCCESSOR, PARENT, PRIOR)
            for filename in ("corpus_v2.json", "scores_v2.csv", "na_types_v2.csv")
        ],
    ]
    output_paths = [*outputs, SUMMARY]
    manifest = {
        "schema": "event-unit-factor-subspace-results-manifest-v1",
        "status": "reproducible_diagnostic_not_active",
        "input_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in input_paths},
        "output_sha256": {path.name: sha256(path) for path in output_paths},
        "candidate_activation_authorized": False,
        "fairness_conclusion_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def output_paths() -> list[Path]:
    return [EVENTS, PROGRAMS, SCENARIOS, SUMMARY, MANIFEST]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    before = {path: path.read_bytes() for path in output_paths() if path.exists()}
    summary = build()
    if args.check:
        missing = [path for path in output_paths() if path not in before]
        changed = [path for path, content in before.items() if path.read_bytes() != content]
        if missing or changed:
            raise SystemExit(f"subspace stability rerun differs: missing={missing}; changed={changed}")
        print("event_unit_subspace_stability_reproduces")
        return
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
