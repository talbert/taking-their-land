# Metadata consumer compatibility — bounded technical note

Snapshot: 2026-09-06 05:53 UTC. Normal implementation support, not another
assurance or historical-review layer. Main is still judging the fourteen
proposals. **No proposal, validator, receipt, historical confidence, family,
date, model, source body or shared file was changed.**

## Bottom line

The rows are compatible with the existing flexible **metadata storage shape**,
but are not yet a complete successor-consumer contract. Confidence prose is
already an established corpus representation, not automatically missing data.
The concrete integration risks are raw-region weighting, nullable/proxy date
handling, duration eligibility, and older hard-coded metadata crosswalks.

The present v3 coding consumer is not an admission/metadata normalizer: it
reads the existing corpus bytes, requires 748 rows/663 active rows, and returns
those same bytes while staging new coding separately
([build_checkpoint.py:602](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/closed_coding_integration_v3/build_checkpoint.py:602>),
lines602–620; [outputs:818](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/closed_coding_integration_v3/build_checkpoint.py:818>),
lines818–852). It does not consume ROWS.json or silently repair its fields.
Its fit/promotion flags remain false. The existing metadata-patch consumer
also fixes the old roster/count and preserves unpatched fields
([build_metadata_checkpoint.py:32](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/build_metadata_checkpoint.py:32>),
lines32–60).

The planned complete successor must adapt established methods and inputs,
not rerun their hard-coded old rosters:
[MODEL_EXECUTION_PLAN.md:16](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/MODEL_EXECUTION_PLAN.md:16>)
and lines34–45. At this inspection, the identified v6 implementation was the
partial coding consumer plus this execution plan, not an implemented accepted
fourteen-row metadata/activation adapter. No such adapter's behavior is assumed.

## 1. Actual schema versus assumed canonical categories

Read-only JSON inspection, without matrices or model outputs:

| Metadata file | Rows | Exact high/medium/low | Other nonempty confidence | Empty confidence | Distinct region strings | Null start/end rows |
| --- | ---: | --- | ---: | ---: | ---: | ---: |
| Frozen v6 corpus |748|273 /106 /0|337|32|163|0|
| Current metadata checkpoint |748|273 /106 /0|337|32|163|12|
| Proposed ROWS |14|0 /0 /0|14|0|14|1|

The checkpoint's twelve null-date rows are active in that intermediate copy;
nullable dates are therefore a current consumer issue beyond Circeii.
All fourteen proposed region strings are different from existing checkpoint
strings. All proposals remain inactive, so none currently affects any model.

Sources:
[frozen corpus](</Users/talbert/settler colonalism visualization/analysis/second_pass/releases/second_pass_v6_675/data/corpus_v2.json>),
[current checkpoint](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/metadata_checkpoint/data/corpus_v2.json>),
[unchanged proposed rows](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/new_event_metadata_v1/ROWS.json>).
These counts characterize actual JSON, not a newly invented formal schema.
The existing sidecar validator checks common fields/types and permits string
confidence/region and integer-or-null dates; it does not certify every old
consumer's assumptions
([validate.py:164](</Users/talbert/settler colonalism visualization/analysis/second_pass/v6/post_v6_correction_application_v1/new_event_metadata_v1/validate.py:164>),
lines164–169,201–207). It was neither edited nor rerun here.

## 2. Confidence: preserve the prose; do not coerce it to missing

Historical builders explicitly populate corpus confidence from a
confidence_statement, or from a source-gate disposition:
[build_hellenistic_candidates.py:218](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/build_hellenistic_candidates.py:218>);
[build_event_unit_candidate_models.py:269](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/build_event_unit_candidate_models.py:269>).
Thus the fourteen prose strings are not a new type violation.

The shared dataset loader constructs the corpus DataFrame, filters in_model,
and aligns IDs without mapping confidence to an enum or number
([run_hellenistic_sensitivities.py:120](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/run_hellenistic_sensitivities.py:120>),
lines120–138). The identified factor/weighting runners do not use corpus
confidence as a weight. Post-v5 documentation weight comes from cell
missingness, not prose
([run_model_comparison.py:367](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/post_v5_correction_application_v1/run_model_comparison.py:367>),
lines367–375). This code was inspected, not run.

A different field with the same name exists in family-review returns:
[validate_candidate_family_review_return.py:20](</Users/talbert/settler colonalism visualization/analysis/second_pass/mechanism_family_v1/validate_candidate_family_review_return.py:20>)
and lines65–66 enforce high/medium/low. That is a **review-return contract**,
not the corpus confidence schema. Copying corpus prose into that field would
fail validation; mapping unmatched prose to null would manufacture missingness.

Minimal handling: retain the full statement. If main wants a canonical
occurrence-confidence class for a new interface or stratum, make that a
separate, explicitly judged adapter field while retaining the prose and
distinguishing occurrence from numbers/biography uncertainty. No automatic
prefix matching, default medium, low-confidence imputation, or equivalence with
family confidence/source resolution. This note chooses no class.

## 3. Region: do not make fourteen singleton weighting strata

The event-unit runner implements reciprocal frequency of the **literal string**:
[run_event_unit_fairness_models_v2.py:326](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:326>),
lines326–328 and
[region weights:559](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:559>),
lines559–588. Its own coverage note calls this an intentionally harsh,
non-publication-ready diagnostic (lines409–416). Directly activating all
fourteen distinct proposed strings in that diagnostic creates fourteen new
singleton strata, each receiving a full stratum's total weight. Renaming that
scenario “equal macroregion” would be incorrect.

A real normalized route already exists. Its sixteen-category vocabulary is at
[build_candidate_676_macroregions.py:36](</Users/talbert/settler colonalism visualization/analysis/second_pass/mechanism_family_v1/build_candidate_676_macroregions.py:36>),
lines36–53. It resolves by explicit event-ID rule or exact region-string rule
and fails unresolved geography (lines283–301). Static inspection of those
literal rule tables found **0/14** proposal matches. The old builder also
asserts exactly676 rows (lines307–312). The normalized analysis joins that
crosswalk by event_id and selects normalized_macroregion, not raw prose:
[analyze_candidate_676_mechanism_family_v2.py:343](</Users/talbert/settler colonalism visualization/analysis/second_pass/mechanism_family_v1/analyze_candidate_676_mechanism_family_v2.py:343>),
lines343–372.

Minimal adapter/main choice: retain detailed geographic prose and supply a
versioned, complete event-ID-to-macroregion crosswalk using the established
vocabulary; main judges the mapping, including operative source/destination
versus affected geography where material. Point the successor's equal-region
scenario at that categorical crosswalk, with exact active-ID coverage and
fail-on-unmapped behavior. Do not inherit the acting polity's capital/parent
region mechanically. If raw-string weighting is also retained, keep it clearly
named as the separate established stress test. No geographic categories are
selected in this note.

## 4. Dates, nulls and proxies: distinct concrete paths

**Safe storage/load path.** JSON null survives the v3 byte copy. In the shared
DataFrame loader, numeric-column nulls remain missing values; there is no
start/end zero fill. Circeii is not silently year0 through this path.

**Safe skip, but not complete semantics.** The event-unit duration diagnostic
starts with neutral weights, skips proxy IDs, and skips missing operative bounds
([run_event_unit_fairness_models_v2.py:468](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:468>),
lines468–474;
[duration loop:568](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:568>),
lines568–583). Circeii's null/null therefore retains neutral weight, not an
observed zero duration or year. Tīl-karme/Sutrium/Nepet's true proxy flags also
exclude them from the observed-duration transformation.

**Old integer preparation is incompatible with nulls.**
[11_prepare_data.py:145](</Users/talbert/settler colonalism visualization/analysis/second_pass/11_prepare_data.py:145>),
lines145–161, requires explicit date-repair coverage and casts active dates to
int. Reusing this old journal-preparation path would reject unresolved dates,
not supply a legitimate historical year. It must not be bypassed with “or0” or
fillna(0). It is not the current v3 byte-copy path.

**An old helper can substitute an unwanted date.**
[build_event_unit_candidate_models.py:184](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/build_event_unit_candidate_models.py:184>),
lines184–222, expects start_year/end_year and substitutes the median of parent
midpoints when both are unresolved. The proposal rows instead carry start/end.
Unadapted reuse can ignore even provided row dates; after a key adapter,
Circeii's unresolved dates can still trigger parent-midpoint substitution.
The helper marks that proxy, but it does not implement the submitted “leave
numeric dates null” proposal. Its surrounding new_event_row also inherits
parent region and sets in_model:true (lines234–259,278–281). Do not reuse that
constructor as an innocent serializer for this sidecar.

**Era recalculation can silently misclassify numeric missingness.**
The numeric comparison chain in
[11_prepare_data.py:96](</Users/talbert/settler colonalism visualization/analysis/second_pass/11_prepare_data.py:96>),
lines96–111, has a final 1990-present return. An isolated execution of this
pure function only—not its module/workflow—gave TypeError for None but
1990-present for float NaN. The same shape appears in the older candidate
builder's era_bucket (lines111–126). Preserve the provided valid era category;
do not recalculate it from missing coordinates.

**Continuous-time diagnostics need an explicit finite-date mask.**
[12_run_second_pass.py:584](</Users/talbert/settler colonalism visualization/analysis/second_pass/12_run_second_pass.py:584>),
lines584–605, feeds start values directly to ordinary/partial correlations.
There is no finite-date mask there. A null can propagate NaN into diagnostics;
it must not be turned into year0 or a default year to make a calculation run.
Report the eligible-date subset and proxy treatment separately; this does not
justify dropping the event from the main factor dataset.

**Duration semantics are not read by the old runner.** It ignores
metadata_date_semantics.duration_years and computes abs(end-start)+1 for
nonproxy numeric operative bounds. The proposed Judean envelope would thereby
become12 inclusive years of “observed duration”; equal annual bounds become1.
Neither follows from the proposals' explicit unknown-duration/discontinuous
semantics. Main's later adapter must define diagnostic eligibility by the
measurand/phase record, not just numeric availability. Keep missing duration
neutral or explicitly excluded as the chosen diagnostic requires; never use
an envelope as measured transport/influx duration by default.

Minimum date guard: preserve null as null, retain explicit era and proxy
metadata, prohibit implicit parent/default dates, and join an explicit
duration/observation-horizon eligibility record. No new date or horizon choice
is made here.

## 5. Era buckets and origin

The nine ancient and five medieval proposal labels exactly match the established
era_bucket strings (11_prepare_data.py lines96–103). Equal-era weighting and
era-specific imputation use era_bucket_v2, not region or confidence:
[run_model_comparison.py:368](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/post_v5_correction_application_v1/run_model_comparison.py:368>),
line444;
[run_hellenistic_sensitivities.py:356](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/run_hellenistic_sensitivities.py:356>).
Those strings are compatible as supplied. Validate vocabulary/nonmissingness
without re-deriving them from Circeii's null dates or a conventional sort proxy.

Origin is provenance, not mover geography. It is copied to editorial outputs
([build_editorial_outputs.py:102](</Users/talbert/settler colonalism visualization/analysis/second_pass/v5/post_v5_correction_application_v1/build_editorial_outputs.py:102>),
lines102–107) and to the normalized analysis frame (analysis_v2 lines371–374).
The core loader does not restrict its vocabulary. Legacy inclusion reporting
does test exact old provenance labels, however:
[13_build_inclusion_register.py:44](</Users/talbert/settler colonalism visualization/analysis/second_pass/13_build_inclusion_register.py:44>),
lines44–48,80–86. New provenance will not automatically enter those old groups.
Use explicit successor membership/action IDs rather than relabeling the rows
as old gapscan/ancient-crosswalk additions. That old report also expects optional
recommendation and atlas_status_preapply columns, absent from these standalone
rows; a reused reporting interface needs explicit presentation defaults or a
new projection, not a new historical admission decision.

## 6. Source objects: shape compatible, downstream meaning needs care

The proposed embedded objects use id/title/url/locator, all present in frozen
and current corpus source objects. No new object-type incompatibility was found.
The larger SOURCE_RECORDS fields (edition, role, dependence/access limits) are
sidecar metadata and are not automatically joined by existing model loaders.

Do not feed embedded source objects into the old dossier constructor:
build_event_unit_candidate_models.py lines239–246 expects source_id,
source_works_context and access_target. Without an explicit projection it can
raise for missing source_id or replace precision with “opened source”/blank URL.

More importantly, the normalized analysis counts len(corpus.sources)
([analysis_v2:379](</Users/talbert/settler colonalism visualization/analysis/second_pass/mechanism_family_v1/analyze_candidate_676_mechanism_family_v2.py:379>))
and turns that into high/low documentation strata at its median
([analysis_v2:427](</Users/talbert/settler colonalism visualization/analysis/second_pass/mechanism_family_v1/analyze_candidate_676_mechanism_family_v2.py:427>)).
That is a reference-count diagnostic—not corpus confidence or independent
witness count. The proposals include an edition-only Alstola crosswalk,
metadata-only KAKEN and non-load-bearing Rajala, plus dependent representations.
Blind counting would count those roles equally. Preserve the existing diagnostic's
name/limitations, or have main specify a separately labeled work/role-aware
projection; do not manufacture independence or silently change the baseline
counting rule. No source quota follows.

The older event-unit source-resolution routine defaults unmatched IDs to
UNRESOLVED_METADATA and fills them from its specific old boundary/packet paths
([run_event_unit_fairness_models_v2.py:331](</Users/talbert/settler colonalism visualization/analysis/second_pass/event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:331>),
lines331–380). It never reads full confidence prose as source resolution.
Adapt that metadata join if reused; distinguish unresolved **adapter metadata**
from absent historical evidence.

The bibliography census similarly reads old registries and old corpus/globs,
not this sidecar
([build_bibliography_census.py:73](</Users/talbert/settler colonalism visualization/monograph/build_bibliography_census.py:73>),
lines73–103). New IDs and precise editions will need an explicit authorized
consumer path; do not assume that merely writing the sidecar updates citations.

## Finite handoff and preservation

No replacement schema or implementation was installed. Main's minimal next
implementation choices are: preserve prose confidence or explicitly add a
separate class; supply categorical macroregion coverage; preserve nullable and
proxy date semantics with diagnostic eligibility; project provenance/reporting
fields; and retain source identity/role precision in any chosen diagnostics.
These are ordinary successor implementation decisions, not new qualification
reviews or requests to change historical confidence/family/dates.

No model runner was executed. No raw matrix, coding return or source body was
opened; no network research or agent was used. Checks were standard-library
JSON/AST inspection, metadata
counts, literal geographic-rule coverage, hashes and the isolated pure era
function. The six files covered by the existing receipt's output hashes still
match it exactly. VALIDATION.json itself remains
56f4b6af9fd1d95e6ba8844fd1229a37aa69e4a3696c71839fe511cc2b6e2b34.

Snapshot bindings for the key inputs:

- ROWS.json:90faa95200baee769ea93b8039b49c63242006ccd12cf2dac44b2574607356d6.
- Frozen corpus:6b54b4f159a20b51c3389a4d4290dabf613a2f0159f9d517c67eac647ebe6a3d.
- Current checkpoint:013aa44cbef6abd3ff40f61d37691264c5a62bd754f01266f7dd1481aaeebe7d.
- v3 build_checkpoint.py:b9aa1c784f9c962d28a9f6f6af37a98ce04dbb51e32ae8847c839823f6e8a89d.
- MODEL_EXECUTION_PLAN.md:9aaca650d109605b3081caf15bd6402240c75b081c9003c3fc69764f3f1477ff.
- run_hellenistic_sensitivities.py:caaf54b6b07d14afbd50719aa8c97f2ed858577daa4d12fec79b9ad90fded98d.
- run_event_unit_fairness_models_v2.py:ece5d95488c2ec0be9cb3835ed77284d13f9a178f9c4a4cad8066f7c47837563.

The v3 code is being developed in parallel; its line references describe the
bound inspection snapshot, not a claim about future versions. This file alone
is the new authored output. The original proposal receipt was not extended or
rewritten to cover this subsequent support note.
