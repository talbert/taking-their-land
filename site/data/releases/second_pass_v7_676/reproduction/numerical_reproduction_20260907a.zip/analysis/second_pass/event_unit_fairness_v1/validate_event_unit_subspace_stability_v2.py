#!/usr/bin/env python3
"""Validate scope-corrected event-unit subspace outputs without refitting."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
OUT = HERE / "candidate_models_v2" / "subspace_stability_v2"
VALIDATION = OUT / "SUBSPACE_STABILITY_VALIDATION.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(name: str) -> list[dict[str, str]]:
    with (OUT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def aggregate(records: list[dict[str, str]], prefix: str) -> dict[str, Any]:
    values = np.asarray(
        [float(row[f"{prefix}_maximum_principal_angle_degrees"]) for row in records]
    )
    return {
        "minimum": float(values.min()),
        "median": float(np.median(values)),
        "percentile_95": float(np.percentile(values, 95)),
        "maximum": float(values.max()),
        "count_above_5_degrees": int(np.sum(values > 5.0)),
        "count_above_10_degrees": int(np.sum(values > 10.0)),
    }


def same(left: dict[str, Any], right: dict[str, Any]) -> bool:
    if set(left) != set(right):
        return False
    for key in left:
        if isinstance(left[key], float) or isinstance(right[key], float):
            if not math.isclose(float(left[key]), float(right[key]), rel_tol=0.0, abs_tol=1e-10):
                return False
        elif left[key] != right[key]:
            return False
    return True


def build() -> dict[str, Any]:
    manifest = json.loads((OUT / "RESULTS_MANIFEST.json").read_text(encoding="utf-8"))
    summary = json.loads((OUT / "SUBSPACE_STABILITY_SUMMARY.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "event-unit-factor-subspace-results-manifest-v1":
        raise RuntimeError("subspace manifest schema differs")
    for field in (
        "candidate_activation_authorized",
        "fairness_conclusion_authorized",
        "release_authorized",
        "atlas_change_authorized",
        "deployment_authorized",
    ):
        if manifest.get(field) is not False or summary.get(field) is not False:
            raise RuntimeError(f"subspace artifact improperly authorizes {field}")
    for raw, digest in manifest["input_sha256"].items():
        path = ROOT / raw
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"subspace input differs: {raw}")
    for name, digest in manifest["output_sha256"].items():
        path = OUT / name
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"subspace output differs: {name}")
    events = rows("event_subspace_influence.csv")
    programs = rows("program_subspace_sensitivity.csv")
    scenarios = rows("scenario_subspace_sensitivity.csv")
    if len(events) != 676 or len({row["event_id"] for row in events}) != 676:
        raise RuntimeError("subspace event universe differs")
    if len(programs) != 138:
        raise RuntimeError("subspace program universe differs")
    if len({(row["sensitivity_group_id"], row["mode"]) for row in programs}) != 138:
        raise RuntimeError("subspace program scenarios duplicate")
    if len(scenarios) != 10 or len({row["scenario"] for row in scenarios}) != 10:
        raise RuntimeError("subspace alternate-scenario universe differs")
    for records, section in (
        (events, summary["leave_one_event_out"]),
        (programs, summary["program_scenarios"]),
    ):
        for prefix in ("eight_factor", "nine_factor"):
            if not same(aggregate(records, prefix), section[f"{prefix}_maximum_principal_angle"]):
                raise RuntimeError(f"subspace summary differs: {prefix}")
    event_nine = aggregate(events, "nine_factor")
    if event_nine["count_above_5_degrees"] != 0 or event_nine["maximum"] >= 5.0:
        raise RuntimeError("recorded nine-factor event subspace is not below five degrees")
    return {
        "schema": "event-unit-factor-subspace-independent-validation-v1",
        "status": "pass_diagnostic_internally_consistent_not_release_authorized",
        "event_scenarios": len(events),
        "program_scenarios": len(programs),
        "alternate_scenarios": len(scenarios),
        "nine_factor_event_maximum_principal_angle_degrees": event_nine["maximum"],
        "nine_factor_event_count_above_five_degrees": event_nine["count_above_5_degrees"],
        "candidate_activation_authorized": False,
        "fairness_conclusion_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    content = (json.dumps(build(), ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if args.check:
        if not VALIDATION.is_file() or VALIDATION.read_bytes() != content:
            raise SystemExit("subspace stability validation does not reproduce")
        print("event_unit_subspace_validation_reproduces")
        return
    VALIDATION.write_bytes(content)
    print("validated event-unit subspace stability diagnostic")


if __name__ == "__main__":
    main()
