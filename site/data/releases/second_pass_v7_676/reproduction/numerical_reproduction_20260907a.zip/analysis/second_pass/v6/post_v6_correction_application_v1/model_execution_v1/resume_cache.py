"""Bound whole-unit checkpoints: strict tagged JSON, atomic writes, one writer.

No estimator, scenario selector, pickle, or executable deserialization lives here.
"""
from __future__ import annotations

import base64
import fcntl
import hashlib
import json
import math
import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd


def require(condition, message):
    if not condition:
        raise ValueError(message)


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'Duplicate checkpoint JSON key')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('Untagged nonfinite checkpoint value: ' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def safe_dtype(value):
    dtype = np.dtype(value)
    require(dtype.fields is None and dtype.kind in 'biufUSO', 'Unsupported checkpoint dtype')
    return dtype


def pack(value):
    """Explicit type whitelist; NaN, None and pandas NA never collapse together."""
    if value is pd.NA:
        return {'t': 'pd.NA'}
    if isinstance(value, pd.DataFrame):
        result = {'t': 'frame', 'index': pack(value.index), 'columns': pack(value.columns),
                  'dtypes': [str(x) for x in value.dtypes]}
        if len(value.dtypes) and all(x == value.dtypes.iloc[0] for x in value.dtypes) and \
                isinstance(value.dtypes.iloc[0], np.dtype):
            # BLAS/SVD can round differently after a C/F layout change despite equal values.
            result['matrix'] = pack(value.to_numpy())
        else:
            result['data'] = [pack(value.iloc[:, i].to_numpy()) for i in range(value.shape[1])]
        return result
    if isinstance(value, pd.Series):
        return {'t': 'series', 'index': pack(value.index), 'name': pack(value.name),
                'data': pack(value.to_numpy()), 'dtype': str(value.dtype)}
    if isinstance(value, pd.RangeIndex):
        return {'t': 'range', 'start': value.start, 'stop': value.stop, 'step': value.step,
                'name': pack(value.name)}
    if isinstance(value, pd.Index):
        require(not isinstance(value, pd.MultiIndex), 'MultiIndex not part of fit intermediates')
        safe_dtype(value.dtype)
        return {'t': 'index', 'values': pack(value.tolist()), 'dtype': str(value.dtype), 'name': pack(value.name)}
    if isinstance(value, np.ndarray):
        dtype = safe_dtype(value.dtype)
        order = 'F' if value.flags.f_contiguous and not value.flags.c_contiguous else 'C'
        result = {'t': 'array', 'dtype': dtype.str, 'shape': list(value.shape), 'order': order}
        if dtype.hasobject:
            result['items'] = [pack(x) for x in value.ravel(order=order)]
        else:
            result['bytes'] = base64.b64encode(value.tobytes(order=order)).decode('ascii')
        return result
    if isinstance(value, np.generic):
        return {'t': 'scalar', 'array': pack(np.asarray(value))}
    if isinstance(value, dict):
        return {'t': 'dict', 'items': [[pack(k), pack(v)] for k, v in value.items()]}
    if isinstance(value, (tuple, list)):
        return {'t': 'tuple' if isinstance(value, tuple) else 'list', 'items': [pack(v) for v in value]}
    if type(value) is float and not math.isfinite(value):
        return {'t': 'float', 'value': 'nan' if math.isnan(value) else ('+inf' if value > 0 else '-inf')}
    if value is None or type(value) in (bool, int, float, str):
        return value
    raise TypeError('Unsupported checkpoint type: ' + type(value).__name__)


def series(values, index, dtype, name=None):
    if dtype not in ('Int64', 'Float64', 'boolean', 'string'):
        safe_dtype(dtype)
    return pd.Series(values, index=index, dtype=dtype, name=name)


def unpack(value):
    if not isinstance(value, dict):
        require(value is None or type(value) in (bool, int, float, str), 'Untagged checkpoint structure')
        return value
    kind = value['t']
    if kind == 'pd.NA':
        return pd.NA
    if kind == 'float':
        require(value['value'] in ('nan', '+inf', '-inf'), 'Unknown nonfinite tag')
        return float(value['value'].replace('+', ''))
    if kind in ('tuple', 'list'):
        items = [unpack(v) for v in value['items']]
        return tuple(items) if kind == 'tuple' else items
    if kind == 'dict':
        items = [(unpack(k), unpack(v)) for k, v in value['items']]
        result = dict(items)
        require(len(result) == len(items), 'Duplicate decoded dictionary key')
        return result
    if kind == 'array':
        dtype, shape = safe_dtype(value['dtype']), value['shape']
        require(value['order'] in ('C', 'F'), 'Invalid array order')
        require(all(type(n) is int and n >= 0 for n in shape), 'Invalid array shape')
        size = math.prod(shape)
        if dtype.hasobject:
            require(len(value['items']) == size, 'Object-array length differs')
            array = np.empty(size, dtype=object)
            array[:] = [unpack(v) for v in value['items']]
        else:
            raw = base64.b64decode(value['bytes'], validate=True)
            require(len(raw) == size * dtype.itemsize, 'Array byte length differs')
            array = np.frombuffer(raw, dtype=dtype).copy()
        return array.reshape(shape, order=value['order'])
    if kind == 'scalar':
        array = unpack(value['array'])
        require(isinstance(array, np.ndarray) and array.shape == (), 'Invalid numpy scalar')
        return array[()]
    if kind == 'range':
        return pd.RangeIndex(value['start'], value['stop'], value['step'], name=unpack(value['name']))
    if kind == 'index':
        return pd.Index(unpack(value['values']), dtype=safe_dtype(value['dtype']), name=unpack(value['name']))
    if kind == 'series':
        return series(unpack(value['data']), unpack(value['index']), value['dtype'], unpack(value['name']))
    if kind == 'frame':
        index, columns = unpack(value['index']), unpack(value['columns'])
        if 'matrix' in value:
            matrix = unpack(value['matrix'])
            require(matrix.shape == (len(index), len(columns)) and
                    len(columns) == len(value['dtypes']) and
                    all(str(matrix.dtype) == dtype for dtype in value['dtypes']), 'Frame matrix dtype/shape differs')
            return pd.DataFrame(matrix, index=index, columns=columns, copy=False)
        require(len(columns) == len(value['data']) == len(value['dtypes']), 'Frame shape differs')
        parts = [series(unpack(v), index, dtype) for v, dtype in zip(value['data'], value['dtypes'])]
        frame = pd.concat(parts, axis=1) if parts else pd.DataFrame(index=index)
        frame.columns = columns
        return frame
    raise ValueError('Unknown checkpoint tag: ' + str(kind))


def atomic(path, raw):
    """Flush the file, replace in its own directory, then flush that directory."""
    require(not path.is_symlink(), 'Checkpoint target is a symlink')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.' + path.name + '.', dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        descriptor = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


class ResumeCache:
    """Run-state authority is immutable except completion; records are whole units."""
    def __init__(self, output, bindings, *, resume=False, validate=lambda: None):
        require(not output.is_symlink(), 'Output directory is a symlink')
        self.output = output.resolve()
        self.bindings = parse(json_bytes(bindings))
        self.binding_sha = sha(json_bytes(self.bindings))
        self.validate = validate
        self.lock = None
        self.counts = {'computed_this_session': {}, 'reused_this_session': {}}
        self.completed = {}
        self.state = {'schema': 'successor-resume-v1', 'status': 'incomplete',
                      'output_directory': str(self.output), 'bindings': self.bindings,
                      'bindings_sha256': self.binding_sha}
        self.validate()
        if self.output.exists():
            require(resume, 'Existing output requires explicit --resume')
            saved = parse((self.output / 'RUN_STATE.json').read_bytes())
            require(saved == self.state, 'Run-state bindings differ or run already completed')
            require(not (self.output / 'MANIFEST.json').exists(), 'Completed run is immutable')
        else:
            require(not resume, '--resume requires an existing exact bound run state')
            self.output.mkdir(parents=True)
        try:
            lock_path = self.output / 'RUN_LOCK'
            require(not lock_path.is_symlink(), 'Run lock is a symlink')
            self.lock = lock_path.open('a+b')
            fcntl.flock(self.lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            if resume:
                # Recheck after acquiring the lock; another writer may have just completed.
                require(parse((self.output / 'RUN_STATE.json').read_bytes()) == self.state and
                        not (self.output / 'MANIFEST.json').exists(), 'Run changed before resume lock')
                progress = self.output / 'PROGRESS.json'
                if progress.is_file():
                    try:
                        self.completed = parse(progress.read_bytes()).get('completed_units', {})
                    except (ValueError, KeyError):
                        pass  # Progress is informative, never reuse authority.
            else:
                atomic(self.output / 'RUN_STATE.json', json_bytes(self.state))
            self.items = self.output / 'resume_items'
            require(not self.items.is_symlink(), 'Cache directory is a symlink')
            self.items.mkdir(exist_ok=True)
            self.progress('running')
        except BaseException:
            if self.lock is not None:
                self.lock.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, kind, error, traceback):
        try:
            if kind is not None and self.state['status'] != 'complete':
                self.progress('interrupted_or_failed', error_type=kind.__name__)
        finally:
            self.lock.close()

    def progress(self, status, **extra):
        report = {
            'status': status, 'bindings_sha256': self.binding_sha,
            'cache_counts_not_scientific_fit_counts': self.counts,
            'completed_units': self.completed, **extra}
        atomic(self.output / 'PROGRESS.json', (json.dumps(report, indent=2, allow_nan=False) + '\n').encode())

    def unit(self, kind, identity, label, calculate):
        require(self.state['status'] != 'complete', 'Completed run is immutable')
        require(kind in ('fit', 'indicator_overlap'), 'Unsupported checkpoint unit')
        self.validate()
        key = sha(json_bytes({'kind': kind, 'identity': pack(identity)}))
        path = self.items / (key + '.json')
        require(not path.is_symlink(), 'Unit checkpoint is a symlink')
        expected = {'schema': 'successor-resume-unit-v1', 'bindings_sha256': self.binding_sha,
                    'kind': kind, 'identity': pack(identity)}
        saved = None
        if path.is_file():
            try:
                saved = parse(path.read_bytes())
            except (ValueError, UnicodeError):
                pass  # A truncated/incomplete record recomputes only this named unit.
        if saved is not None:
            require(all(saved.get(k) == v for k, v in expected.items()), 'Unit identity/bindings differ')
            require(saved.get('status') in ('started', 'complete'), 'Invalid unit completion state')
        if saved is not None and saved['status'] == 'complete':
            require(sha(json_bytes(saved['payload'])) == saved['payload_sha256'], 'Completed cache payload changed')
            result, action = unpack(saved['payload']), 'reused_this_session'
        else:
            atomic(path, json_bytes({**expected, 'status': 'started', 'label': label}))
            self.progress('running', current_unit={'kind': kind, 'label': label})
            result = calculate()
            self.validate()
            payload = pack(result)
            atomic(path, json_bytes({**expected, 'status': 'complete', 'label': label,
                                     'payload': payload, 'payload_sha256': sha(json_bytes(payload))}))
            action = 'computed_this_session'
        self.counts[action][kind] = self.counts[action].get(kind, 0) + 1
        self.completed[key] = {'kind': kind, 'label': label, 'record': path.name, 'status': 'complete'}
        self.progress('running', last_completed_unit=self.completed[key], last_action=action)
        return result

    def finish(self, result_bytes, manifest_bytes):
        require(self.state['status'] != 'complete', 'Completed run is immutable')
        self.validate()
        for name, body in (('RESULTS.json', result_bytes), ('MANIFEST.json', manifest_bytes)):
            path = self.output / name
            if path.exists():
                require(not path.is_symlink() and path.read_bytes() == body, 'Refusing differing final output: ' + name)
            else:
                atomic(path, body)
        self.state['status'] = 'complete'
        atomic(self.output / 'RUN_STATE.json', json_bytes(self.state))
        self.progress('complete')
