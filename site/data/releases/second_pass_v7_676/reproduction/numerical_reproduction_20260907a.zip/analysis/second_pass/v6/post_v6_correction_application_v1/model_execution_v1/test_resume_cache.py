"""One bounded synthetic-only test suite for durable whole-fit resume."""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
import warnings
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pandas as pd

import resume_cache as rc
import run_successor as runner
from inputs import Reader, concatenate
from numerics import helpers
from test_synthetic import fixture


def numerical_bytes(result):
    return json.dumps(result, sort_keys=True, allow_nan=False).encode()


class FakeNumerics:
    """Fast deterministic plumbing fixture, not substituted production mathematics."""
    def __init__(self, real, reference):
        self.calls = {'fits': 0, 'overlap': 0}

        def observed(values, weights):
            self.calls['fits'] += 1
            return np.linspace(2, .1, values.shape[1]), np.eye(values.shape[1])

        def loadings(matrix, k, correlation=None):
            values = np.random.default_rng(k).normal(size=(matrix.shape[1], k))
            return pd.DataFrame(values, index=matrix.columns,
                                columns=reference.columns if k == 8 else pd.RangeIndex(k))

        def named(matrix, ref, imputed):
            axes = loadings(matrix, 8)
            scores = pd.DataFrame(matrix.values @ axes.values, index=matrix.index, columns=axes.columns)
            scores.iloc[:, 0] = 0  # Explicit undefined Spearman/partial fixture, not a zero substitution.
            return {'loadings': axes, 'factor_scores': scores, 'alignment': [{'axis': 'fixture', 'value': np.nan}],
                    'labels': np.arange(len(matrix), dtype=np.int32) % 6,
                    'silhouette': np.nan, 'imputed': imputed}

        def overlap(raw):
            self.calls['overlap'] += 1
            return {'status': 'synthetic_overlap', 'matrix': runner.frame_key(raw),
                    'undefined': np.nan, 'unmeasured': None, 'typed_array': np.array([0, 1], dtype=np.int32)}

        self.h = SimpleNamespace(
            legacy=SimpleNamespace(observed_eigenvalues=observed,
                horn_thresholds=lambda n, p, **kw: np.ones(p), fit_scores=named,
                era_median_imputation=real.legacy.era_median_imputation,
                knn_unknown_imputation=real.legacy.knn_unknown_imputation,
                structural_zero_imputation=real.legacy.structural_zero_imputation),
            subspace=SimpleNamespace(fit_loadings=loadings), pipeline=real.pipeline,
            fairness=real.fairness, overlap=SimpleNamespace(compare=real.overlap.compare, run=overlap))


class ResumeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h = helpers()
        cls.columns, _ = cls.h.overlap.battery_columns()
        cls.reference = pd.DataFrame(np.random.default_rng(1701).normal(size=(60, 8)),
                                     index=cls.columns, columns=['F' + str(i) for i in range(8)])

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='successor-resume-synthetic-')
        self.root = Path(self.temporary.name)
        self.bindings = runner.run_bindings(Reader())

    def tearDown(self):
        self.temporary.cleanup()

    def test_tagged_exact_roundtrip_and_undefined_types(self):
        index = pd.Index(['event-A', 'event-B'], name='event_id')
        frame = pd.DataFrame({'ordinal': np.array([0, 4], dtype=np.int64),
                              'undefined': [np.nan, -0.0]}, index=index)
        value = {'frame': frame, 'range_frame': pd.DataFrame(np.eye(3)),
                 'array': np.array([np.nan, np.inf, -np.inf, -0.0], dtype='<f8'),
                 'labels': np.array([0, 4], dtype=np.int32), 'scalar': np.float32(1.5),
                 'nullable': pd.Series([pd.NA, 2], dtype='Int64'),
                 'different_missing_types': [None, np.nan, pd.NA],
                 'tuple_key': {(120, 60, None): np.ones(3)}, 'literal_tag': {'t': 'array'}}
        encoded = rc.json_bytes(rc.pack(value))
        result = rc.unpack(rc.parse(encoded))
        self.assertEqual(encoded, rc.json_bytes(rc.pack(result)))
        pd.testing.assert_frame_equal(frame, result['frame'], check_exact=True)
        self.assertIsNone(result['different_missing_types'][0])
        self.assertTrue(np.isnan(result['different_missing_types'][1]))
        self.assertIs(result['different_missing_types'][2], pd.NA)
        self.assertEqual(result['labels'].dtype, np.dtype('int32'))
        self.assertEqual(result['array'].tobytes(), value['array'].tobytes())
        for bad in ({'t': 'pickle'}, {'t': 'array', 'dtype': 'V8', 'shape': [1], 'bytes': ''}):
            with self.assertRaises(ValueError):
                rc.unpack(bad)
        for bad in (b'{"x":NaN}', b'{"x":1,"x":2}'):
            with self.assertRaises(ValueError):
                rc.parse(bad)

    def test_incomplete_item_only_recomputed_and_progress_is_durable(self):
        output = self.root / 'run'
        calls = []
        with self.assertRaises(KeyboardInterrupt):
            with rc.ResumeCache(output, self.bindings) as cache:
                cache.unit('fit', 'done', 'completed fit', lambda: calls.append('done') or {'x': np.nan})
                def interrupt():
                    calls.append('interrupted')
                    raise KeyboardInterrupt()
                cache.unit('fit', 'partial', 'interrupted fit', interrupt)
        progress = rc.parse((output / 'PROGRESS.json').read_bytes())
        self.assertEqual(len(progress['completed_units']), 1)
        self.assertEqual(progress['status'], 'interrupted_or_failed')
        with rc.ResumeCache(output, self.bindings, resume=True) as cache:
            reused = cache.unit('fit', 'done', 'completed fit', lambda: self.fail('Recomputed completed fit'))
            self.assertTrue(np.isnan(reused['x']))
            cache.unit('fit', 'partial', 'interrupted fit', lambda: calls.append('retry') or 4)
            self.assertEqual(cache.counts, {'computed_this_session': {'fit': 1}, 'reused_this_session': {'fit': 1}})
        self.assertEqual(calls, ['done', 'interrupted', 'retry'])
        self.assertEqual(len(rc.parse((output / 'PROGRESS.json').read_bytes())['completed_units']), 2)

    def test_truncated_record_recovers_but_complete_hash_corruption_rejects(self):
        output = self.root / 'run'
        with rc.ResumeCache(output, self.bindings) as cache:
            cache.unit('fit', 1, 'one', lambda: 1)
        path = next((output / 'resume_items').glob('*.json'))
        original = path.read_bytes()
        path.write_bytes(b'{"interrupted')
        with rc.ResumeCache(output, self.bindings, resume=True) as cache:
            self.assertEqual(cache.unit('fit', 1, 'one', lambda: 1), 1)
        self.assertEqual(path.read_bytes(), original)
        changed = rc.parse(original)
        changed['payload'] = 4
        path.write_bytes(rc.json_bytes(changed))
        with rc.ResumeCache(output, self.bindings, resume=True) as cache:
            with self.assertRaisesRegex(ValueError, 'payload changed'):
                cache.unit('fit', 1, 'one', lambda: self.fail('Corrupt complete payload silently recomputed'))

    def test_binding_changes_explicit_resume_and_writer_lock(self):
        output = self.root / 'run'
        with rc.ResumeCache(output, self.bindings) as cache:
            cache.unit('fit', 1, 'one', lambda: 1)
            with self.assertRaises(BlockingIOError):
                rc.ResumeCache(output, self.bindings, resume=True)
        with self.assertRaisesRegex(ValueError, 'explicit --resume'):
            rc.ResumeCache(output, self.bindings)
        for key in ('input_sha256', 'adapter_sha256', 'numerical_dependencies_sha256',
                    'dependency_manifest_sha256', 'runtime', 'threads', 'randomness'):
            changed = copy.deepcopy(self.bindings)
            changed[key] = 'different synthetic binding'
            with self.subTest(binding=key), self.assertRaisesRegex(ValueError, 'bindings differ'):
                rc.ResumeCache(output, changed, resume=True)
        with self.assertRaisesRegex(ValueError, 'existing exact bound run state'):
            rc.ResumeCache(self.root / 'absent', self.bindings, resume=True)
        empty = self.root / 'unbound'
        empty.mkdir()
        with self.assertRaises(FileNotFoundError):
            rc.ResumeCache(empty, self.bindings, resume=True)

    def test_atomic_replacement_and_immutable_completed_run(self):
        path = self.root / 'atomic.json'
        path.write_bytes(b'original')
        with patch.object(rc.os, 'replace', side_effect=KeyboardInterrupt), self.assertRaises(KeyboardInterrupt):
            rc.atomic(path, b'new')
        self.assertEqual(path.read_bytes(), b'original')
        self.assertEqual(list(self.root.glob('.atomic.json.*')), [])
        output = self.root / 'run'
        with rc.ResumeCache(output, self.bindings) as cache:
            cache.unit('indicator_overlap', 'baseline', 'baseline', lambda: {'x': None})
            # An interrupted final write may leave RESULTS alone; equal bytes are safe to finish.
            rc.atomic(output / 'RESULTS.json', b'{"synthetic":true}\n')
            with self.assertRaisesRegex(ValueError, 'differing final'):
                cache.finish(b'wrong\n', b'{}\n')
            cache.finish(b'{"synthetic":true}\n', b'{}\n')
            with self.assertRaisesRegex(ValueError, 'Completed run is immutable'):
                cache.unit('fit', 'late', 'late', lambda: self.fail('Computed after completion'))
            with self.assertRaisesRegex(ValueError, 'Completed run is immutable'):
                cache.finish(b'{"synthetic":true}\n', b'{}\n')
        before = {p.name: p.read_bytes() for p in output.iterdir() if p.is_file()}
        for resume in (False, True):
            with self.assertRaises(ValueError):
                rc.ResumeCache(output, self.bindings, resume=resume)
        self.assertEqual(before, {p.name: p.read_bytes() for p in output.iterdir() if p.is_file()})

    def test_guard_revalidated_before_reuse_and_before_commit(self):
        guard_calls = []
        valid = [True]
        def validate():
            guard_calls.append(True)
            if not valid[0]:
                raise ValueError('synthetic input changed')
        output = self.root / 'run'
        with rc.ResumeCache(output, self.bindings, validate=validate) as cache:
            cache.unit('fit', 1, 'one', lambda: 1)
            valid[0] = False
            with self.assertRaisesRegex(ValueError, 'input changed'):
                cache.unit('fit', 1, 'one', lambda: self.fail('Should validate before reuse'))
            valid[0] = True
            def change_during_compute():
                valid[0] = False
                return 2
            with self.assertRaisesRegex(ValueError, 'input changed'):
                cache.unit('fit', 2, 'two', change_during_compute)
        self.assertGreaterEqual(len(guard_calls), 6)
        states = [rc.parse(p.read_bytes())['status'] for p in (output / 'resume_items').glob('*.json')]
        self.assertCountEqual(states, ['complete', 'started'])

    def test_fresh_and_resumed_whole_suite_same_numerical_payload(self):
        base = fixture(self.columns, n=105)
        extra = fixture(self.columns, n=107).subset(['synthetic-0105', 'synthetic-0106'])
        successor = concatenate([base.subset(list(base.scores.index[1:])), extra])
        datasets = {'baseline': base, 'successor': successor}
        scope = {'retired_ids': [base.scores.index[0]], 'new_ids': list(extra.scores.index)}
        programs = {'instructions': [{'id': 'synthetic-omission', 'kind': 'omission',
            'authority_ids': ['synthetic'], 'drop_ids': [successor.scores.index[-1]],
            'expected_event_ids': list(successor.scores.index[:-1])}]}
        def suite(h, cache=None):
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                return runner.run_suite(datasets, scope, programs, self.reference, Reader(), h, cache)
        uncached = suite(FakeNumerics(self.h, self.reference).h)
        with rc.ResumeCache(self.root / 'fresh', self.bindings) as cache:
            fresh = suite(FakeNumerics(self.h, self.reference).h, cache)
            cache.finish(numerical_bytes(fresh), b'{}\n')
        class StopAfterBaselineOverlap(rc.ResumeCache):
            def unit(self, kind, identity, label, calculate):
                result = super().unit(kind, identity, label, calculate)
                if kind == 'indicator_overlap' and label == 'baseline':
                    raise KeyboardInterrupt()
                return result
        with self.assertRaises(KeyboardInterrupt):
            with StopAfterBaselineOverlap(self.root / 'resume', self.bindings) as cache:
                suite(FakeNumerics(self.h, self.reference).h, cache)
        resumed_h = FakeNumerics(self.h, self.reference)
        with rc.ResumeCache(self.root / 'resume', self.bindings, resume=True) as cache:
            resumed = suite(resumed_h.h, cache)
            self.assertEqual(resumed_h.calls, {'fits': 0, 'overlap': 1})
            self.assertEqual(cache.counts['computed_this_session'], {'indicator_overlap': 1})
            self.assertEqual(cache.counts['reused_this_session']['fit'], fresh['unique_preprocessed_matrix_cases'])
            cache.finish(numerical_bytes(resumed), b'{}\n')
        self.assertEqual(numerical_bytes(uncached), numerical_bytes(fresh))
        self.assertEqual(numerical_bytes(fresh), numerical_bytes(resumed))
        self.assertEqual(fresh['null_cache_entries'], resumed['null_cache_entries'])
        self.assertIn('F0', fresh['scenarios'][0]['comparisons']['baseline']['named_eight_diagnostic']['undefined_spearman_axes'])

    def test_actual_synthetic_fit_named_intermediates_and_nulls_reused_exactly(self):
        matrix = fixture(self.columns).scores
        matrix = matrix.fillna(matrix.median())
        def guard():
            self.assertEqual(runner.run_bindings(Reader()), self.bindings)
        with rc.ResumeCache(self.root / 'real-synthetic', self.bindings, validate=guard) as cache:
            first = runner.Engine(self.h, self.reference, cache).fit(matrix)
        direct = runner.Engine(self.h, self.reference).fit(matrix)
        self.assertEqual(direct['fits']['8']['status'], 'computed')
        self.assertEqual(rc.json_bytes(rc.pack(direct)), rc.json_bytes(rc.pack(first)))
        with rc.ResumeCache(self.root / 'real-synthetic', self.bindings, resume=True, validate=guard) as cache:
            engine = runner.Engine(self.h, self.reference, cache)
            with patch.object(engine, '_compute', side_effect=AssertionError('Completed fit recomputed')):
                reused = engine.fit(matrix)
            self.assertEqual(rc.json_bytes(rc.pack(first)), rc.json_bytes(rc.pack(reused)))
            self.assertEqual(len(engine.fits), 1)
            self.assertEqual(len(engine.nulls), 1)
            pd.testing.assert_frame_equal(first['_named_fit']['factor_scores'], reused['_named_fit']['factor_scores'], check_exact=True)
            self.assertEqual(numerical_bytes(engine.compare(first, reused)), numerical_bytes(engine.compare(first, first)))

    def test_execution_gate_still_precedes_cache(self):
        h = SimpleNamespace(overlap=SimpleNamespace(battery_columns=lambda: (self.columns, {})))
        contract = ({'historical_fit_authorized': False}, {}, {}, {'instructions': []}, self.reference, {}, Reader())
        argv = ['run_successor.py', '--acceptance', 'synthetic-only', '--acceptance-sha256', '0' * 64,
                '--execute', '--resume', '--output', str(runner.HERE / 'not-created-synthetic')]
        with patch.object(runner.sys, 'argv', argv), patch.object(runner, 'helpers', return_value=h), \
             patch.object(runner, 'load_contract', return_value=contract), \
             patch.object(runner, 'ResumeCache', side_effect=AssertionError('Cache used before execution gate')):
            with self.assertRaisesRegex(ValueError, 'permission to execute'):
                runner.main()


if __name__ == '__main__':
    unittest.main(verbosity=2)
