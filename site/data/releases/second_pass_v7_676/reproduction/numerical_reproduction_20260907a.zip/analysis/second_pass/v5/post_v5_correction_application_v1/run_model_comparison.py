#!/usr/bin/env python3
"""Run the bounded post-v5 statistical comparison.

This does not repeat the full v5 research program. It isolates the finite
correction cycle's roster and cell effects, reruns the load-bearing factor,
weight, missingness, imputation, and influence checks, and compares them with
the immutable v5 base.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.linalg import subspace_angles
from scipy.optimize import linear_sum_assignment
from scipy.stats import spearmanr
from sklearn.metrics import adjusted_rand_score


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
SECOND = ROOT / "analysis" / "second_pass"
V5 = SECOND / "releases" / "second_pass_v5_676"
CANDIDATE = HERE / "candidate" / "post_v5_corrected_successor_675"
PLAN = json.loads((HERE / "CORRECTION_PLAN.json").read_text(encoding="utf-8"))
LEGACY_PATH = SECOND / "v5" / "run_hellenistic_sensitivities.py"
V4_LOADINGS = SECOND / "releases" / "second_pass_v4_583" / "results" / "loadings_aligned.csv"
OUT = CANDIDATE / "results" / "post_v5_model_comparison_v1"
CORE = OUT / "core_scenario_metrics.csv"
FACTORS = OUT / "factor_metrics.csv"
WEIGHTING = OUT / "weighting_metrics.csv"
MISSINGNESS = OUT / "missingness_metrics.csv"
IMPUTATION = OUT / "imputation_metrics.csv"
INFLUENCE = OUT / "corrected_event_influence.csv"
SUBSPACE = OUT / "subspace_metrics.csv"
SUMMARY = OUT / "MODEL_COMPARISON_SUMMARY.json"
MANIFEST = OUT / "RESULTS_MANIFEST.json"
SEED = 28082026


def load_legacy():
    spec = importlib.util.spec_from_file_location("post_v5_legacy_helpers", LEGACY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load validated statistical helpers")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SEED = SEED
    module.N_HORN = 500
    return module


LEGACY = load_legacy()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render_csv(rows: list[dict[str, Any]]) -> bytes:
    if not rows:
        raise RuntimeError("cannot render an empty results table")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def safe_rho(left: pd.Series, right: pd.Series) -> float:
    value, _ = spearmanr(left, right)
    return float(value) if np.isfinite(value) else 0.0


def fit_subspace_loadings(
    matrix: pd.DataFrame,
    factors: int,
    *,
    correlation: np.ndarray | None = None,
) -> pd.DataFrame:
    """Fit a factor-loading basis without assigning historical axis names."""
    analyzer = FactorAnalyzer(
        n_factors=factors,
        rotation="oblimin",
        method="minres",
        is_corr_matrix=correlation is not None,
    )
    analyzer.fit(correlation if correlation is not None else matrix.values)
    return pd.DataFrame(
        analyzer.loadings_,
        index=matrix.columns,
        columns=[f"N{index + 1}" for index in range(factors)],
    )


def loading_congruence(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    numerator = left.T @ right
    denominator = np.sqrt(
        (left * left).sum(axis=0)[:, None]
        * (right * right).sum(axis=0)[None, :]
    )
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator),
        where=denominator != 0,
    )


def compare_subspace(reference: pd.DataFrame, candidate: pd.DataFrame) -> dict[str, float]:
    """Compare whole factor spaces and separately report best axis matching."""
    angles = np.degrees(subspace_angles(reference.values, candidate.values))
    congruence = loading_congruence(reference.values, candidate.values)
    left, right = linear_sum_assignment(-np.abs(congruence))
    aligned = [abs(float(congruence[lindex, rindex])) for lindex, rindex in zip(left, right)]
    return {
        "maximum_principal_angle_degrees": float(max(angles)),
        "mean_principal_angle_degrees": float(np.mean(angles)),
        "minimum_principal_angle_cosine": float(min(np.cos(np.radians(angles)))),
        "minimum_aligned_axis_tucker": float(min(aligned)),
        "mean_aligned_axis_tucker": float(np.mean(aligned)),
    }


def subspace_row(
    category: str,
    scenario: str,
    reference_name: str,
    reference8: pd.DataFrame,
    reference9: pd.DataFrame,
    matrix: pd.DataFrame,
    *,
    correlation: np.ndarray | None = None,
) -> dict[str, Any]:
    values: dict[str, Any] = {
        "category": category,
        "scenario": scenario,
        "reference": reference_name,
        "events": len(matrix),
    }
    for factors, reference in ((8, reference8), (9, reference9)):
        comparison = compare_subspace(
            reference,
            fit_subspace_loadings(matrix, factors, correlation=correlation),
        )
        for field, value in comparison.items():
            values[f"factor_{factors}_{field}"] = value
    values["factor_8_angle_above_5_degrees"] = (
        values["factor_8_maximum_principal_angle_degrees"] > 5.0
    )
    values["factor_9_angle_above_5_degrees"] = (
        values["factor_9_maximum_principal_angle_degrees"] > 5.0
    )
    return values


def canonicalize_base(dataset: dict[str, Any]) -> dict[str, Any]:
    mapping = {
        old: record["new_event_id"] for old, record in PLAN["id_changes"].items()
    }
    result: dict[str, Any] = {}
    for key in ("scores", "na_types", "corpus"):
        frame = dataset[key].copy()
        frame.index = [mapping.get(str(value), str(value)) for value in frame.index]
        if not frame.index.is_unique:
            raise RuntimeError(f"canonicalized v5 IDs are not unique: {key}")
        result[key] = frame
    return result


def reference(fit: dict[str, Any], factor_count: int) -> dict[str, Any]:
    return {
        "loadings": fit["loadings"],
        "factor_scores": fit["factor_scores"],
        "labels": pd.Series(fit["labels"], index=fit["factor_scores"].index),
        "parallel_analysis_factors": factor_count,
    }


def horn_count(scores: pd.DataFrame, cache: dict[int, np.ndarray]) -> tuple[int, list[float]]:
    imputed = scores.fillna(scores.median())
    eigenvalues, _ = LEGACY.observed_eigenvalues(imputed.values)
    thresholds = cache.get(len(scores))
    if thresholds is None:
        thresholds = LEGACY.horn_thresholds(
            len(scores), scores.shape[1], seed=SEED + len(scores)
        )
        cache[len(scores)] = thresholds
    margins = [float(eigenvalues[index] - thresholds[index]) for index in (7, 8, 9)]
    return int(np.sum(eigenvalues > thresholds)), margins


def compare(
    fit: dict[str, Any],
    scores: pd.DataFrame,
    base: dict[str, Any],
) -> tuple[dict[str, Any], list[float], list[float]]:
    shared = base["factor_scores"].index.intersection(scores.index)
    tucker = [
        abs(LEGACY.tucker(base["loadings"][factor], fit["loadings"][factor]))
        for factor in base["loadings"].columns
    ]
    rhos = [
        safe_rho(base["factor_scores"].loc[shared, factor], fit["factor_scores"].loc[shared, factor])
        for factor in base["factor_scores"].columns
    ]
    prior = base["labels"].loc[shared].astype(int).to_numpy()
    current = pd.Series(fit["labels"], index=scores.index).loc[shared].astype(int).to_numpy()
    aligned, _, _ = LEGACY.PIPELINE.align_cluster_labels(prior, current)
    changed = int(np.sum(prior != aligned))
    metrics = {
        "shared_events": len(shared),
        "minimum_loading_tucker_vs_v5": float(min(tucker)),
        "mean_loading_tucker_vs_v5": float(np.mean(tucker)),
        "minimum_shared_score_spearman_vs_v5": float(min(rhos)),
        "mean_shared_score_spearman_vs_v5": float(np.mean(rhos)),
        "aligned_k6_changed": changed,
        "aligned_k6_changed_share": float(changed / len(shared)),
        "adjusted_rand_vs_v5": float(adjusted_rand_score(prior, current)),
    }
    return metrics, tucker, rhos


def scenario_row(
    name: str,
    mode: str,
    scores: pd.DataFrame,
    named_loadings: pd.DataFrame,
    base_reference: dict[str, Any],
    cache: dict[int, np.ndarray],
    factor_rows: list[dict[str, Any]],
) -> tuple[dict[str, Any], dict[str, Any]]:
    fit = LEGACY.fit_scores(scores, named_loadings)
    factor_count, margins = horn_count(scores, cache)
    metrics, tucker, rhos = compare(fit, scores, base_reference)
    for index, factor in enumerate(named_loadings.columns):
        factor_rows.append({
            "scenario": name,
            "factor": factor,
            "loading_tucker_vs_v5": tucker[index],
            "shared_score_spearman_vs_v5": rhos[index],
        })
    material = bool(
        factor_count != base_reference["parallel_analysis_factors"]
        or metrics["minimum_loading_tucker_vs_v5"] < 0.85
        or metrics["minimum_shared_score_spearman_vs_v5"] < 0.90
        or metrics["aligned_k6_changed_share"] > 0.05
    )
    row = {
        "scenario": name,
        "mode": mode,
        "events": len(scores),
        "parallel_analysis_factors": factor_count,
        "factor_8_margin": margins[0],
        "factor_9_margin": margins[1],
        "factor_10_margin": margins[2],
        **metrics,
        "k6_silhouette": fit["silhouette"],
        "material_flag_vs_v5": material,
    }
    return row, fit


def weighted_row(
    name: str,
    scores: pd.DataFrame,
    weights: np.ndarray,
    named_loadings: pd.DataFrame,
    corrected_fit: dict[str, Any],
    base_reference: dict[str, Any],
    offset: int,
) -> dict[str, Any]:
    imputed = scores.fillna(scores.median())
    eigenvalues, correlation = LEGACY.observed_eigenvalues(imputed.values, weights)
    thresholds = LEGACY.horn_thresholds(
        len(scores), scores.shape[1], weights=weights, seed=SEED + 1000 + offset
    )
    raw = LEGACY.fit_correlation(correlation, scores.columns)
    aligned_v5 = LEGACY.align_loadings(base_reference["loadings"], raw)
    aligned_corrected = LEGACY.align_loadings(corrected_fit["loadings"], raw)
    v5_tucker = [
        abs(LEGACY.tucker(base_reference["loadings"][factor], aligned_v5[factor]))
        for factor in named_loadings.columns
    ]
    corrected_tucker = [
        abs(LEGACY.tucker(corrected_fit["loadings"][factor], aligned_corrected[factor]))
        for factor in named_loadings.columns
    ]
    factor_count = int(np.sum(eigenvalues > thresholds))
    return {
        "weighting": name,
        "sum_weights": float(weights.sum()),
        "effective_sample_size": float(weights.sum() ** 2 / np.sum(weights**2)),
        "parallel_analysis_factors": factor_count,
        "factor_8_margin": float(eigenvalues[7] - thresholds[7]),
        "factor_9_margin": float(eigenvalues[8] - thresholds[8]),
        "minimum_loading_tucker_vs_v5": float(min(v5_tucker)),
        "minimum_loading_tucker_vs_corrected_unweighted": float(min(corrected_tucker)),
        "material_flag_vs_corrected_unweighted": bool(
            factor_count != base_reference["parallel_analysis_factors"]
            or min(corrected_tucker) < 0.85
        ),
    }


def build() -> dict[str, Any]:
    named_loadings = pd.read_csv(V4_LOADINGS, index_col=0)
    v5 = canonicalize_base(LEGACY.load_dataset(V5))
    corrected = LEGACY.load_dataset(CANDIDATE)
    if len(v5["scores"]) != 676 or len(corrected["scores"]) != 675:
        raise RuntimeError("base/corrected counts differ")
    retired_id = next(iter(PLAN["retirements"]))
    patched_ids = sorted(PLAN["trait_intents"])

    cache: dict[int, np.ndarray] = {}
    base_count, _ = horn_count(v5["scores"], cache)
    base_fit = LEGACY.fit_scores(v5["scores"], named_loadings)
    base_reference = reference(base_fit, base_count)
    base_imputed = v5["scores"].fillna(v5["scores"].median())
    base_subspace8 = fit_subspace_loadings(base_imputed, 8)
    base_subspace9 = fit_subspace_loadings(base_imputed, 9)

    corrections_only = pd.concat([
        corrected["scores"],
        v5["scores"].loc[[retired_id]],
    ]).loc[v5["scores"].index]
    retirement_only = v5["scores"].drop(index=retired_id)
    corrected_without_touched = corrected["scores"].drop(index=patched_ids)
    scenarios = {
        "immutable_v5_676": ("published_base_recomputed", v5["scores"]),
        "corrected_successor_675": ("one_retirement_plus_117_cell_corrections", corrected["scores"]),
        "cell_corrections_only_676": ("retain_indo_aryan_to_isolate_cell_effect", corrections_only),
        "indo_aryan_retirement_only_675": ("retire_wrapper_without_cell_corrections", retirement_only),
        "corrected_without_nine_touched_666": ("leave_all_cell_corrected_events_out", corrected_without_touched),
    }
    factor_rows: list[dict[str, Any]] = []
    core_rows: list[dict[str, Any]] = []
    subspace_rows: list[dict[str, Any]] = []
    fits: dict[str, dict[str, Any]] = {}
    for name, (mode, scores) in scenarios.items():
        row, fit = scenario_row(
            name, mode, scores, named_loadings, base_reference, cache, factor_rows
        )
        core_rows.append(row)
        fits[name] = fit
        subspace_rows.append(subspace_row(
            "core_scenario",
            name,
            "immutable_v5_676",
            base_subspace8,
            base_subspace9,
            scores.fillna(scores.median()),
        ))

    corpus = corrected["corpus"]
    era_counts = corpus["era_bucket_v2"].value_counts()
    era_weights = corpus["era_bucket_v2"].map(lambda value: 1.0 / era_counts[value]).to_numpy(float)
    missing = ((corrected["na_types"] == "U") | (corrected["na_types"] == "NA")).sum(axis=1)
    documentation_weights = 1.0 / (1.0 + missing.to_numpy(float) / 60.0)
    weighting_scenarios = {
        "unweighted_equal_event": np.ones(len(corpus), dtype=float),
        "equal_total_weight_per_era": era_weights,
        "bounded_documentation_weight": documentation_weights,
    }
    weighting_rows: list[dict[str, Any]] = []
    corrected_imputed = corrected["scores"].fillna(corrected["scores"].median())
    for index, (name, weights) in enumerate(weighting_scenarios.items()):
        weighting_rows.append(weighted_row(
            name,
            corrected["scores"],
            weights,
            named_loadings,
            fits["corrected_successor_675"],
            base_reference,
            index,
        ))
        _, correlation = LEGACY.observed_eigenvalues(corrected_imputed.values, weights)
        subspace_rows.append(subspace_row(
            "weighting",
            name,
            "immutable_v5_676",
            base_subspace8,
            base_subspace9,
            corrected_imputed,
            correlation=correlation,
        ))

    missingness_rows: list[dict[str, Any]] = []
    for maximum in (0, 5, 10, 15, 20, 30, 40):
        subset = corrected["scores"].loc[missing <= maximum]
        row: dict[str, Any] = {
            "maximum_missing_cells_per_event": maximum,
            "events": len(subset),
            "patched_events_retained": int(subset.index.isin(patched_ids).sum()),
            "factor_model_run": False,
            "parallel_analysis_factors": "",
            "minimum_loading_tucker_vs_v5": "",
            "minimum_shared_score_spearman_vs_v5": "",
            "aligned_k6_changed_share": "",
            "material_flag_vs_v5": "",
        }
        if len(subset) >= 100:
            fit = LEGACY.fit_scores(subset, named_loadings)
            factor_count, _ = horn_count(subset, cache)
            metrics, _, _ = compare(fit, subset, base_reference)
            row.update({
                "factor_model_run": True,
                "parallel_analysis_factors": factor_count,
                "minimum_loading_tucker_vs_v5": metrics["minimum_loading_tucker_vs_v5"],
                "minimum_shared_score_spearman_vs_v5": metrics["minimum_shared_score_spearman_vs_v5"],
                "aligned_k6_changed_share": metrics["aligned_k6_changed_share"],
                "material_flag_vs_v5": bool(
                    factor_count != base_count
                    or metrics["minimum_loading_tucker_vs_v5"] < 0.85
                    or metrics["minimum_shared_score_spearman_vs_v5"] < 0.90
                    or metrics["aligned_k6_changed_share"] > 0.05
                ),
            })
            subspace_rows.append(subspace_row(
                "missingness_subset",
                f"maximum_{maximum}_missing_cells",
                "immutable_v5_676",
                base_subspace8,
                base_subspace9,
                subset.fillna(subset.median()),
            ))
        missingness_rows.append(row)

    global_median = corrected["scores"].fillna(corrected["scores"].median())
    imputation_matrices = {
        "global_median": global_median,
        "era_specific_median": LEGACY.era_median_imputation(corrected["scores"], corpus["era_bucket_v2"]),
        "unknown_knn_structural_median": LEGACY.knn_unknown_imputation(corrected["scores"], corrected["na_types"]),
        "unknown_median_structural_zero_bound": LEGACY.structural_zero_imputation(corrected["scores"], corrected["na_types"]),
    }
    imputation_rows: list[dict[str, Any]] = []
    corrected_fit = fits["corrected_successor_675"]
    for name, matrix in imputation_matrices.items():
        fit = LEGACY.fit_scores(corrected["scores"], named_loadings, imputed=matrix)
        eigenvalues, _ = LEGACY.observed_eigenvalues(matrix.values)
        thresholds = cache[len(corrected["scores"])]
        factor_count = int(np.sum(eigenvalues > thresholds))
        metrics, tucker, _ = compare(fit, corrected["scores"], base_reference)
        versus_corrected = [
            abs(LEGACY.tucker(corrected_fit["loadings"][factor], fit["loadings"][factor]))
            for factor in named_loadings.columns
        ]
        imputation_rows.append({
            "imputation": name,
            "parallel_analysis_factors": factor_count,
            "factor_8_margin": float(eigenvalues[7] - thresholds[7]),
            "factor_9_margin": float(eigenvalues[8] - thresholds[8]),
            "minimum_loading_tucker_vs_v5": float(min(tucker)),
            "minimum_loading_tucker_vs_corrected_global_median": float(min(versus_corrected)),
            "minimum_shared_score_spearman_vs_v5": metrics["minimum_shared_score_spearman_vs_v5"],
            "aligned_k6_changed_share_vs_v5": metrics["aligned_k6_changed_share"],
            "material_flag_vs_corrected_global_median": bool(
                factor_count != base_count or min(versus_corrected) < 0.85
            ),
        })
        subspace_rows.append(subspace_row(
            "imputation",
            name,
            "immutable_v5_676",
            base_subspace8,
            base_subspace9,
            matrix,
        ))

    corrected_reference = reference(corrected_fit, int(core_rows[1]["parallel_analysis_factors"]))
    corrected_subspace8 = fit_subspace_loadings(global_median, 8)
    corrected_subspace9 = fit_subspace_loadings(global_median, 9)
    influence_rows: list[dict[str, Any]] = []
    for event_id in patched_ids:
        subset = corrected["scores"].drop(index=event_id)
        fit = LEGACY.fit_scores(subset, corrected_fit["loadings"])
        metrics, _, _ = compare(fit, subset, corrected_reference)
        influence_rows.append({
            "event_id": event_id,
            **metrics,
            "material_flag_vs_corrected": bool(
                metrics["minimum_loading_tucker_vs_v5"] < 0.85
                or metrics["minimum_shared_score_spearman_vs_v5"] < 0.90
                or metrics["aligned_k6_changed_share"] > 0.05
            ),
        })
        subspace_rows.append(subspace_row(
            "corrected_event_influence",
            f"leave_out_{event_id}",
            "corrected_successor_675",
            corrected_subspace8,
            corrected_subspace9,
            subset.fillna(subset.median()),
        ))

    tables = {
        CORE: core_rows,
        FACTORS: factor_rows,
        WEIGHTING: weighting_rows,
        MISSINGNESS: missingness_rows,
        IMPUTATION: imputation_rows,
        INFLUENCE: influence_rows,
        SUBSPACE: subspace_rows,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    for path, rows in tables.items():
        path.write_bytes(render_csv(rows))

    corrected_row = next(row for row in core_rows if row["scenario"] == "corrected_successor_675")
    corrected_subspace_row = next(
        row for row in subspace_rows
        if row["category"] == "core_scenario" and row["scenario"] == "corrected_successor_675"
    )
    if (
        corrected_row["material_flag_vs_v5"]
        and not corrected_subspace_row["factor_9_angle_above_5_degrees"]
        and corrected_row["parallel_analysis_factors"] == base_count == 9
    ):
        corrected_interpretation = "stable_nine_factor_subspace_with_forced_eight_axis_rotation"
    elif corrected_subspace_row["factor_9_angle_above_5_degrees"]:
        corrected_interpretation = "nine_factor_subspace_change_requires_substantive_review"
    else:
        corrected_interpretation = "stable_without_forced_eight_axis_warning"
    summary = {
        "schema": "post-v5-bounded-model-comparison-summary-v1",
        "status": "reproducible_diagnostic_not_release_authorized",
        "immutable_base": "second_pass_v5_676",
        "corrected_candidate": CANDIDATE.name,
        "base_factor_count_recomputed": base_count,
        "corrected_factor_count": corrected_row["parallel_analysis_factors"],
        "corrected_vs_v5": corrected_row,
        "corrected_vs_v5_subspace": corrected_subspace_row,
        "corrected_interpretation": corrected_interpretation,
        "core_scenario_material_flags": {
            row["scenario"]: row["material_flag_vs_v5"] for row in core_rows
        },
        "weighting_material_flags": {
            row["weighting"]: row["material_flag_vs_corrected_unweighted"] for row in weighting_rows
        },
        "imputation_material_flags": {
            row["imputation"]: row["material_flag_vs_corrected_global_median"] for row in imputation_rows
        },
        "individually_material_corrected_events": [
            row["event_id"] for row in influence_rows if row["material_flag_vs_corrected"]
        ],
        "materiality_rules": {
            "factor_count_must_match_v5": True,
            "loading_tucker_below": 0.85,
            "shared_score_spearman_below": 0.90,
            "aligned_k6_changed_share_above": 0.05,
            "nine_factor_subspace_maximum_angle_above_degrees": 5.0,
        },
        "interpretation_guardrail": "Principal angles assess the factor space as a whole. A stable nine-factor subspace can coexist with unstable names in a forced eight-factor fit; that does not rescue any particular named axis. Statistical stability also does not decide historical inclusion.",
        "candidate_activation_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    SUMMARY.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    input_paths = [
        Path(__file__).resolve(),
        HERE / "CORRECTION_PLAN.json",
        CANDIDATE / "candidate_manifest.json",
        CANDIDATE / "data" / "corpus_v2.json",
        CANDIDATE / "data" / "scores_v2.csv",
        CANDIDATE / "data" / "na_types_v2.csv",
        V5 / "release_manifest.json",
        V5 / "data" / "corpus_v2.json",
        V5 / "data" / "scores_v2.csv",
        V5 / "data" / "na_types_v2.csv",
        V4_LOADINGS,
        LEGACY_PATH,
    ]
    outputs = [*tables, SUMMARY]
    manifest = {
        "schema": "post-v5-bounded-model-comparison-manifest-v1",
        "status": "reproducible_diagnostic_not_release_authorized",
        "randomness": {
            "horn_seed_base": SEED,
            "horn_draws": LEGACY.N_HORN,
            "kmeans_random_state": 0,
            "kmeans_n_init": 100,
        },
        "runtime": {
            "python": sys.version.split()[0],
            "python_executable": str(Path(sys.executable)),
            "platform": platform.platform(),
            "packages": {
                name: importlib.metadata.version(name)
                for name in ("numpy", "pandas", "scipy", "scikit-learn", "factor-analyzer")
            },
        },
        "input_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in input_paths},
        "output_sha256": {path.name: sha256(path) for path in outputs},
        "candidate_activation_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return summary


def output_paths() -> list[Path]:
    return [CORE, FACTORS, WEIGHTING, MISSINGNESS, IMPUTATION, INFLUENCE, SUBSPACE, SUMMARY, MANIFEST]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    before = {path: path.read_bytes() for path in output_paths() if path.exists()}
    summary = build()
    if args.check:
        missing = [str(path) for path in output_paths() if path not in before]
        changed = [str(path) for path, data in before.items() if path.read_bytes() != data]
        if missing or changed:
            raise SystemExit(f"model comparison does not reproduce; missing={missing}, changed={changed}")
        print("post_v5_model_comparison_reproduces")
        return
    print(json.dumps({
        "status": summary["status"],
        "base_factor_count": summary["base_factor_count_recomputed"],
        "corrected_factor_count": summary["corrected_factor_count"],
        "corrected_material_flag": summary["corrected_vs_v5"]["material_flag_vs_v5"],
        "corrected_interpretation": summary["corrected_interpretation"],
    }, indent=2))


if __name__ == "__main__":
    main()
