#!/usr/bin/env python3
"""Bounded implementation tests. Every score/metadata fixture is synthetic."""
from __future__ import annotations

import copy
import importlib.metadata
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from inputs import (Dataset, Reader, acceptance_gate, concatenate, load_dataset, validate_dataset,
                    validate_scope)
from numerics import HERE, SEED, DRAWS, check_dependencies, digest, functions, helpers
from run_successor import Engine, frame_key, program_dataset, run_suite, scenario_datasets


def fixture(columns, n=120):
    rng = np.random.default_rng(20260906)
    ids = [f'synthetic-{i:04d}' for i in range(n)]
    latent = rng.normal(size=(n, 9)) @ rng.normal(size=(9, 60)) / 3
    scores = pd.DataFrame(np.clip(np.rint(2 + latent + rng.normal(size=(n, 60)) * .7), 0, 4),
                          index=pd.Index(ids, name='event_id'), columns=columns)
    na = pd.DataFrame('', index=scores.index, columns=columns)
    positions = rng.random(size=(n, 60))
    na.values[positions < .025] = 'U'
    na.values[(positions >= .025) & (positions < .04)] = 'NA'
    scores = scores.mask(na != '')
    corpus, analysis = [], []
    for i, event_id in enumerate(ids):
        proxy, absent = i in (12, 13), i < 12
        year = None if absent else -400 + i
        corpus.append({'event_id': event_id, 'in_model': True, 'start': year, 'end': year,
                       'date_numeric_proxy_used': proxy, 'era_bucket_v2': 'ancient (-1000 to 499)',
                       'region': f'synthetic detailed region {i % 14}',
                       'confidence': 'Synthetic prose retained; not an enum or weight',
                       'family': 'synthetic editorial hold NOT a selection rule'})
        analysis.append({'event_id': event_id, 'normalized_macroregion': 'EUROPE' if i % 3 else 'WEST_ASIA',
                         'date_is_proxy': proxy, 'continuous_date_eligible': not (proxy or absent),
                         'observed_date_year': None if proxy or absent else year,
                         'duration_years': None, 'duration_eligible': False,
                         'duration_measurand': 'Synthetic unknown process duration; annual envelope not tempo',
                         'observation_horizons': {'operative': 'synthetic-only', 'aftermath': 'synthetic-only'},
                         'authority_refs': ['synthetic-authority']})
    return Dataset(scores, na, pd.DataFrame(corpus).set_index('event_id'),
                   pd.DataFrame(analysis).set_index('event_id'))


def run():
    checks = []

    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append(name)

    def rejects(name, callback):
        try:
            callback()
        except (ValueError, KeyError):
            checks.append(name)
        else:
            raise AssertionError('Accepted malformed control: ' + name)

    h = helpers()
    columns, groups = h.overlap.battery_columns()
    base = fixture(columns)
    validate_dataset(base, columns)
    base_before = frame_key(base.scores), base.na.copy(), base.corpus.copy(deep=True)
    with patch.object(Path, 'mkdir', side_effect=AssertionError('Unexpected legacy initializer write')):
        helpers()
    check('selected function loader does not invoke legacy mkdir/constructor entry points', True)
    acceptance = {'schema': 'successor-model-execution-inputs-v1',
                  'status': 'MAIN_ACCEPTED_COMPLETE_CANDIDATE', 'complete_candidate': True,
                  'open_packages': [], 'main_acceptance_ref': 'SYNTHETIC ONLY', 'release_cutoff': 'SYNTHETIC ONLY'}
    ready = {'complete_candidate': True, 'fit_authorized': True}
    acceptance_gate(acceptance, ready)
    for key, value in [('status', 'INCOMPLETE_DO_NOT_FIT_OR_PUBLISH'), ('complete_candidate', False),
                       ('open_packages', ['one_open_package'])]:
        bad = {**acceptance, key: value}
        rejects('reject acceptance ' + key, lambda bad=bad: acceptance_gate(bad, ready))
    rejects('reject hash-valid renamed incomplete663 manifest', lambda: acceptance_gate(
        acceptance, {'status': 'INCOMPLETE_DO_NOT_FIT_OR_PUBLISH', 'active_events': 663,
                     'complete_candidate': False, 'fit_authorized': False}))
    for name, edit in [
        ('raw -1 sentinel', lambda d: d.scores.iloc.__setitem__((0, 0), -1)),
        ('untyped missingness', lambda d: (d.scores.iloc.__setitem__((0, 0), np.nan), d.na.iloc.__setitem__((0, 0), ''))),
        ('unmapped macroregion', lambda d: d.analysis.loc.__setitem__((d.scores.index[0], 'normalized_macroregion'), 'new singleton')),
        ('proxy date eligibility', lambda d: (d.analysis.loc.__setitem__((d.scores.index[12], 'continuous_date_eligible'), True),
                                            d.analysis.loc.__setitem__((d.scores.index[12], 'observed_date_year'), -388))),
        ('null year replaced by zero', lambda d: d.analysis.loc.__setitem__((d.scores.index[0], 'observed_date_year'), 0)),
        ('unknown duration replaced by calendar envelope', lambda d: d.analysis.loc.__setitem__((d.scores.index[0], 'duration_years'), 1)),
    ]:
        bad = copy.deepcopy(base)
        edit(bad)
        rejects('reject ' + name, lambda bad=bad: validate_dataset(bad, columns))
    bad = base.subset(list(base.scores.index))
    bad.na = bad.na.iloc[::-1]
    rejects('reject reordered NA binding', lambda: validate_dataset(bad, columns))

    # Normal temporary fixture I/O is confined to this owned directory.
    with tempfile.TemporaryDirectory(prefix='synthetic-fixture-', dir=HERE) as temporary:
        directory = Path(temporary)
        reader = Reader()

        def bind(name, raw):
            path = directory / name
            path.write_bytes(raw)
            return {'path': str(path), 'sha256': digest(raw)}

        spec = {'event_ids': list(base.scores.index),
                'scores': bind('scores.csv', base.scores.to_csv(float_format='%.3f').encode()),
                'na_types': bind('na.csv', base.na.to_csv().encode()),
                'corpus': bind('corpus.json', base.corpus.reset_index().to_json(orient='records').encode()),
                'analysis_metadata': bind('analysis.json', base.analysis.reset_index().to_json(orient='records').encode())}
        loaded = load_dataset(reader, spec, columns)
        check('actual file joins and 4.000/4 numerical parity', loaded.scores.equals(base.scores))
        check('null dates, prose confidence, family holds and 120 factor rows preserved',
              loaded.corpus.equals(base.corpus) and len(loaded.scores) == 120)
        wrong = {**spec['scores'], 'sha256': '0' * 64}
        rejects('reject hash substitution', lambda: reader.read(wrong))
        rejects('reject absent explicit hash', lambda: reader.read({'path': spec['scores']['path']}))
        reader.unchanged()
        date_alt = copy.deepcopy(base.analysis)
        date_alt.loc[base.scores.index[14], 'continuous_date_eligible'] = False
        date_alt.loc[base.scores.index[14], 'observed_date_year'] = np.nan
        altref = bind('date-alternative.json', date_alt.reset_index().to_json(orient='records').encode())

        extra = fixture(columns, n=122).subset(['synthetic-0120', 'synthetic-0121'])
        extra.corpus.loc['synthetic-0120', ['start', 'end']] = np.nan
        extra.analysis.loc['synthetic-0120', 'continuous_date_eligible'] = False
        extra.analysis.loc['synthetic-0120', 'observed_date_year'] = np.nan
        successor = concatenate([base.subset(list(base.scores.index[1:])), extra])
        successor.full_corpus = pd.concat([base.corpus.copy(), extra.corpus.copy()])
        successor.full_corpus.loc[base.scores.index[0], 'in_model'] = False
        historical_parent = base.corpus.iloc[[0]].copy()
        historical_parent.index = pd.Index(['synthetic-already-inactive-parent'], name='event_id')
        historical_parent['in_model'] = False
        successor.full_corpus = pd.concat([successor.full_corpus, historical_parent])
        event_id, dimension = successor.scores.index[20], columns[3]
        successor.scores.loc[event_id, dimension] = 4 if base.scores.loc[event_id, dimension] != 4 else 3
        successor.na.loc[event_id, dimension] = ''
        # Inherited fractional baseline cells survive untouched; only accepted
        # recodes/new full definitions must use the integer instrument.
        fractional_event, fractional_dimension = successor.scores.index[25], columns[7]
        base.scores.loc[fractional_event, fractional_dimension] = 2.5
        base.na.loc[fractional_event, fractional_dimension] = ''
        successor.scores.loc[fractional_event, fractional_dimension] = 2.5
        successor.na.loc[fractional_event, fractional_dimension] = ''
        base_before = frame_key(base.scores), base.na.copy(), base.corpus.copy(deep=True)
        scope = {'retired_ids': [base.scores.index[0]], 'new_ids': list(extra.scores.index), 'held_ids': ['synthetic-held'],
                 'overlap_scope_complete': True, 'parent_child_rulings': [],
                 'reviewed_existing_cells': [{'event_id': event_id, 'dimension_id': dimension}],
                 'expected_actual_changed_cells': 1, 'expected_reviewed_confirmed_cells': 0}
        arithmetic = validate_scope(base, successor, scope)
        validate_dataset(base, columns)
        validate_dataset(successor, columns)
        check('inherited baseline and unchanged retained fractional observation accepted without rounding',
              successor.scores.loc[fractional_event, fractional_dimension] == 2.5)
        changed_fraction = copy.deepcopy(successor)
        changed_fraction.scores.loc[event_id, dimension] = 2.5
        rejects('reject fractional accepted changed cell', lambda: validate_scope(base, changed_fraction, scope))
        new_fraction = copy.deepcopy(successor)
        new_fraction.scores.loc[extra.scores.index[0], columns[0]] = 2.5
        new_fraction.na.loc[extra.scores.index[0], columns[0]] = ''
        rejects('reject fractional new full definition', lambda: validate_scope(base, new_fraction, scope))
        check('actual changed-cell scope and roster arithmetic', arithmetic['actual_changed_cells'] == 1)
        check('new rows use their own supplied profiles and null date, without parent inheritance',
              successor.scores.loc[extra.scores.index].equals(extra.scores) and
              pd.isna(successor.corpus.loc['synthetic-0120', 'start']))
        rejects('reject unassigned changed cell', lambda: validate_scope(base, successor,
                {**scope, 'reviewed_existing_cells': []}))
        rejects('reject held activation', lambda: validate_scope(base, successor,
                {**scope, 'held_ids': [event_id]}))
        rejects('reject unresolved active parent child overlap', lambda: validate_scope(base, successor,
                {**scope, 'parent_child_rulings': [{'parent_id': event_id,
                 'child_ids': [successor.scores.index[0]], 'ruling': 'parent_inactive', 'authority_refs': ['synthetic']}]}))
        inactive_scope = {**scope, 'parent_child_rulings': [{'parent_id': historical_parent.index[0],
                          'child_ids': [extra.scores.index[0]], 'ruling': 'parent_inactive',
                          'authority_refs': ['synthetic-inactive-parent-disposition']}]}
        validate_scope(base, successor, inactive_scope)
        check('already-inactive parent outside both active score rosters accepted from full corpus metadata',
              historical_parent.index[0] not in set(base.scores.index) | set(successor.scores.index))
        cases = scenario_datasets({'baseline': base, 'successor': successor}, scope)
        check('counterfactual retirement/correction isolation uses original archived row',
              cases['retained_corrections_only'].scores.loc[base.scores.index[0]].equals(base.scores.iloc[0])
              and len(cases['retirement_only'].scores) == 119 and len(cases['retained_corrections_only'].scores) == 120)
        # Use successor-sized exact metadata join for a date-only instruction.
        combined_alt = pd.concat([date_alt.loc[base.scores.index[1:]], extra.analysis])
        altref = bind('successor-date-alternative.json', combined_alt.reset_index().to_json(orient='records').encode())
        group_weights = {i: .5 if i in extra.scores.index else 1.0 for i in successor.scores.index}
        weightref = bind('group-weights.json', json.dumps(group_weights).encode())
        eligibilityref = bind('weight-eligibility.json', b'{"kind":"synthetic linked program, two explicit independent rows, total one"}')
        instructions = [
            {'id': 'synthetic-event-omission', 'kind': 'omission', 'authority_ids': ['synthetic'],
             'drop_ids': [successor.scores.index[-1]], 'expected_event_ids': list(successor.scores.index[:-1])},
            {'id': 'synthetic-date-only', 'kind': 'metadata_only', 'authority_ids': ['synthetic'],
             'analysis_metadata': altref, 'expected_event_ids': list(successor.scores.index)},
            {'id': 'synthetic-uncoded-phase', 'kind': 'unestimable', 'authority_ids': ['synthetic'],
             'reason': 'No independently coded phase; no pseudo-score generated'},
            {'id': 'synthetic-editorial-hold', 'kind': 'editorial_only', 'authority_ids': ['synthetic'],
             'reason': 'Editorial alternative is not a row filter or factor solution'},
            {'id': 'synthetic-program-weight', 'kind': 'weighting', 'authority_ids': ['synthetic'],
             'weight_kind': 'linked_program_total_one', 'weights': weightref, 'seed_offset': 10,
             'eligibility_measurand_ref': eligibilityref, 'reason': 'Explicit two-row synthetic program',
             'expected_event_ids': list(successor.scores.index)},
        ]
        rejects('reject fabricated program method', lambda: program_dataset(
            {'kind': 'median_phase_pseudo_scores'}, {'successor': successor}, reader, columns))
        altered = program_dataset(instructions[1], {'successor': successor}, reader, columns)
        check('date-only changes leave raw/NA frames exactly equal',
              altered.scores.equals(successor.scores) and altered.na.equals(successor.na))
        reference = h.subspace.fit_loadings(base.scores.fillna(base.scores.median()), 8)
        engine = Engine(h, reference)
        matrix = base.scores.fillna(base.scores.median())
        result = engine.fit(matrix)
        check('actual synthetic forced8/9 minres oblimin run',
              all(result['fits'][k]['status'] == 'computed' for k in ('8', '9')))
        direct_horn = h.legacy.horn_thresholds(len(matrix), 60, seed=SEED + len(matrix))
        check('500 Gaussian 95th thresholds exactly equal selected legacy implementation',
              np.array_equal(result['horn_thresholds'], direct_horn) and result['horn_draws'] == 500)
        check('eight loadings subspace parity with validated post-v5/event-unit method',
              h.overlap.compare(reference, result['fits']['8']['_loadings'])['maximum_principal_angle_degrees'] < 1e-6)
        weights = h.fairness.reciprocal_group_weights(base.analysis['normalized_macroregion'])
        totals = pd.Series(weights, index=base.scores.index).groupby(base.analysis['normalized_macroregion']).sum()
        check('normalized two-stratum weights sum one each, not fourteen raw strings', np.allclose(totals, 1))
        check('weighted correlation parity across validated implementations', np.array_equal(
            h.legacy.weighted_correlation(matrix.values, weights), h.subspace.weighted_correlation(matrix.values, weights)))
        for first, second, args in [('era_median_imputation', 'era_imputation', (base.scores, base.corpus['era_bucket_v2'])),
                                    ('knn_unknown_imputation', 'knn_imputation', (base.scores, base.na)),
                                    ('structural_zero_imputation', 'structural_zero_imputation', (base.scores, base.na))]:
            check('imputation parity ' + first, getattr(h.legacy, first)(*args).equals(getattr(h.subspace, second)(*args)))
        sparse = engine.fit(matrix.iloc[:20])
        check('sparse matrix reported inestimable without substitute fit', sparse['status'] == 'inestimable')
        constant = matrix.copy()
        constant.iloc[:, 0] = 0
        check('constant indicator disclosed without silent drop', engine.fit(constant)['status'] == 'inestimable')
        cache = {}
        h.overlap.horn_thresholds(120, 60, cache, draws=2)
        h.overlap.horn_thresholds(120, 48, cache, draws=2)
        check('null cache separates actual p60 from p48', len(cache) == 2)
        h.overlap.self_test()
        results = run_suite({'baseline': base, 'successor': successor}, scope,
                            {'instructions': instructions}, reference, reader, h)
        check('entire synthetic suite serialized as strict JSON', bool(json.dumps(results, allow_nan=False)))
        overlap = results['indicator_overlap']
        check('both rosters each run full60 plus five complete48 battery omissions', all(
            [x['indicators'] for x in overlap[name]['scenarios']] == [60, 48, 48, 48, 48, 48]
            for name in ('baseline', 'successor')))
        by_name = {r['scenario']: r for r in results['scenarios']}
        check('identical date-only numerical matrix reuses fit but discloses changed eligible subset',
              by_name['successor']['result']['matrix_sha256'] == by_name['synthetic-date-only/global_median']['result']['matrix_sha256']
              and len(by_name['successor']['date_diagnostics']['eligible_event_ids']) ==
              len(by_name['synthetic-date-only/global_median']['date_diagnostics']['eligible_event_ids']) + 1)
        check('null/proxy exclusions do not shrink full factor matrix',
              by_name['baseline']['result']['events'] == 120 and len(by_name['baseline']['date_diagnostics']['excluded_event_ids']) == 14)
        check('editorial hold and unavailable phase recorded without fitting/filtering',
              len(results['explicit_limits_and_editorial_only']) == 2)
        check('explicit bound program weights preserve full roster and original ordinal cells',
              by_name['synthetic-program-weight']['result']['events'] == len(successor.scores) and
              by_name['synthetic-program-weight']['result']['weights'][-2:] == [.5, .5])
        reader.unchanged()
    check('synthetic raw scores/NA/corpus remain untouched after all sensitivities',
          frame_key(base.scores) == base_before[0] and base.na.equals(base_before[1]) and base.corpus.equals(base_before[2]))
    check_dependencies()
    report = {'status': 'PASS_SYNTHETIC_ONLY', 'checks_passed': len(checks), 'checks': checks,
              'historical_score_corpus_or_analysis_metadata_payloads_loaded': 0, 'historical_fits': 0,
              'synthetic_full_suite_scenarios': len(results['scenarios']),
              'synthetic_unique_preprocessed_matrix_cases': results['unique_preprocessed_matrix_cases'],
              'synthetic_result_sha256': digest(json.dumps(results, sort_keys=True, allow_nan=False).encode()),
              'full_suite_horn_draws': DRAWS, 'full_suite_horn_percentile': 95, 'full_suite_seed_base': SEED,
              'cache_shape_probe_only_draws': 2, 'runtime': {'python': sys.version, 'executable': sys.executable,
                  'packages': {p: importlib.metadata.version(p) for p in ('numpy','pandas','scipy','scikit-learn','factor-analyzer')}},
              'input_code_sha256': {p.name: digest(p.read_bytes()) for p in sorted(HERE.glob('*.py'))},
              'dependencies_sha256': check_dependencies(), 'model_performed_not_human_or_external_review': True}
    (HERE / 'SYNTHETIC_TEST_RESULTS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'checks_passed': len(checks),
                      'synthetic_scenarios': len(results['scenarios']), 'historical_fits': 0}))


if __name__ == '__main__':
    run()
