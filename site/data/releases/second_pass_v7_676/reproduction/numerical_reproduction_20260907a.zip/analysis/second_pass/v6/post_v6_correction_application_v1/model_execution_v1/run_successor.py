#!/usr/bin/env python3
"""Parameterized successor diagnostics. Preparation/synthetic testing is not fit authority."""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr
from sklearn.metrics import adjusted_rand_score
from threadpoolctl import threadpool_info

from inputs import Dataset, concatenate, load_contract, require, unique_ids, validate_dataset
from numerics import HERE, SEED, DRAWS, check_dependencies, digest, helpers
from resume_cache import ResumeCache

MISSINGNESS_MAXIMA = (0, 5, 10, 15, 20, 30, 40, 50)  # Existing event-unit v2 grid.


def frame_key(matrix, weights=None):
    header = json.dumps([list(matrix.index), list(matrix.columns)], separators=(',', ':')).encode()
    values = np.asarray(matrix.values, dtype='<f8').copy()
    values[np.isnan(values)] = np.nan
    return digest(header + values.tobytes() +
                  (b'unweighted' if weights is None else np.asarray(weights, dtype='<f8').tobytes()))


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


class Engine:
    def __init__(self, h, reference, cache=None):
        self.h, self.reference = h, reference
        self.cache = cache
        self.nulls, self.fits = {}, {}

    def fit(self, matrix, *, weights=None, seed_offset=0, preprocessing='global_median', checkpoint_label='fit'):
        require(weights is None or (len(weights) == len(matrix) and np.isfinite(weights).all()
                                   and (weights > 0).all()), 'Invalid explicit weights')
        seed = SEED + len(matrix) if weights is None else SEED + 1000 + seed_offset
        key = (frame_key(matrix, weights), preprocessing, seed)
        if key in self.fits:
            return self.fits[key]

        def calculate():
            result = self._compute(matrix, weights, preprocessing, seed, key)
            # Restore the same scientific null-cache inventory on a resumed run.
            return {'result': result, 'nulls': list(self.nulls.items())}

        saved = (calculate() if self.cache is None else
                 self.cache.unit('fit', key, checkpoint_label, calculate))
        self.nulls.update(saved['nulls'])
        self.fits[key] = saved['result']
        return saved['result']

    def _compute(self, matrix, weights, preprocessing, seed, key):
        result = {'matrix_sha256': key[0], 'preprocessing': preprocessing, 'events': len(matrix),
                  'event_ids': list(matrix.index), 'indicators': len(matrix.columns),
                  'seed': seed, 'horn_draws': DRAWS, 'horn_percentile': 95, 'fits': {},
                  'warnings': [], 'status': 'computed_diagnostic'}
        empty = matrix.columns[matrix.isna().any()].tolist()
        constant = matrix.columns[matrix.nunique() < 2].tolist()
        if len(matrix) <= len(matrix.columns) or empty or constant:
            result.update(status='inestimable', all_missing_or_nonfilled_columns=empty,
                          constant_columns=constant, reason='Insufficient rows or nonvariable/incomplete matrix')
            return result
        try:
            eigenvalues, correlation = self.h.legacy.observed_eigenvalues(matrix.values, weights)
            null_key = (len(matrix), len(matrix.columns), seed, DRAWS,
                        None if weights is None else digest(np.asarray(weights, dtype='<f8').tobytes()))
            if null_key not in self.nulls:
                self.nulls[null_key] = self.h.legacy.horn_thresholds(
                    len(matrix), len(matrix.columns), weights=weights, seed=seed)
            thresholds = self.nulls[null_key]
            result.update(eigenvalues=eigenvalues.tolist(), horn_thresholds=thresholds.tolist(),
                          horn_margins=(eigenvalues - thresholds).tolist(),
                          retained_factors=int(np.sum(eigenvalues > thresholds)))
            if weights is not None:
                result.update(sum_weights=float(weights.sum()),
                              effective_sample_size=float(weights.sum() ** 2 / np.sum(weights ** 2)),
                              weights=weights.tolist())
        except Exception as exc:
            result.update(status='inestimable', error=type(exc).__name__ + ': ' + str(exc))
            return result
        for k in (8, 9):
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                try:
                    if k == 8 and weights is None:
                        fit = self.h.legacy.fit_scores(matrix, self.reference, imputed=matrix)
                        loadings = fit['loadings']
                        result['_named_fit'] = fit
                    else:
                        loadings = self.h.subspace.fit_loadings(
                            matrix, k, correlation=correlation if weights is not None else None)
                    require(np.isfinite(loadings.values).all(), 'Nonfinite loadings')
                    rank = int(np.linalg.matrix_rank(loadings.values))
                    result['fits'][str(k)] = {'status': 'computed' if rank == k else 'rank_loss',
                                              'rank': rank, 'loadings': loadings.values.tolist(),
                                              'dimension_ids': list(loadings.index),
                                              'axis_ids': list(loadings.columns), '_loadings': loadings}
                except Exception as exc:
                    result['fits'][str(k)] = {'status': 'fit_failed',
                                              'error': type(exc).__name__ + ': ' + str(exc)}
                result['fits'][str(k)]['warnings'] = [str(w.message) for w in caught]
        return result

    def compare(self, reference, candidate):
        comparisons = {}
        for k in ('8', '9'):
            left, right = reference['fits'].get(k, {}), candidate['fits'].get(k, {})
            if '_loadings' not in left or '_loadings' not in right:
                comparisons[k] = {'status': 'inestimable_comparison'}
            else:
                comparisons[k] = self.h.overlap.compare(left['_loadings'], right['_loadings'])
        if '_named_fit' in reference and '_named_fit' in candidate:
            left, right = reference['_named_fit'], candidate['_named_fit']
            shared = left['factor_scores'].index.intersection(right['factor_scores'].index)
            rho = {col: float(spearmanr(left['factor_scores'].loc[shared, col],
                                       right['factor_scores'].loc[shared, col]).statistic)
                   if len(shared) > 1 else np.nan for col in self.reference.columns}
            direct = self.h.pipeline.loading_congruence(left['loadings'].values, right['loadings'].values)
            diagnostic = {'shared_event_ids': list(shared), 'shared_score_spearman': clean(rho),
                          'undefined_spearman_axes': [k for k, v in rho.items() if not np.isfinite(v)],
                          'named_axis_abs_tucker': dict(zip(self.reference.columns, np.abs(np.diag(direct)).tolist())),
                          'k6_role': 'legacy_diagnostic_not_six_editorial_families_or_retention_target'}
            if len(shared):
                a = left['labels'][left['factor_scores'].index.get_indexer(shared)]
                b = right['labels'][right['factor_scores'].index.get_indexer(shared)]
                aligned, _, _ = self.h.pipeline.align_cluster_labels(a, b)
                diagnostic.update(aligned_k6_changed_share=float(np.mean(a != aligned)),
                                  adjusted_rand=float(adjusted_rand_score(a, b)))
            comparisons['named_eight_diagnostic'] = diagnostic
        return comparisons


def date_diagnostics(data, result, h):
    mask = data.analysis['continuous_date_eligible'] & ~data.analysis['date_is_proxy']
    dates = data.analysis['observed_date_year'].astype(float)
    mask &= np.isfinite(dates)
    ids = data.scores.index[mask]
    output = {'eligible_event_ids': list(ids), 'excluded_event_ids': list(data.scores.index[~mask]),
              'rule': 'explicit eligible, finite, nonproxy observed-date subset; full factor rows unchanged',
              'unknown_duration_ids': list(data.scores.index[data.analysis['duration_years'].isna()]),
              'status': 'inestimable_without_named_fit_or_date_variation', 'axes': {}}
    if '_named_fit' not in result or len(ids) < 3 or dates.loc[ids].nunique() < 2:
        return output
    missing = np.column_stack([(data.na.loc[ids] == kind).sum(axis=1) for kind in ('U', 'NA')])
    output['status'] = 'computed_on_disclosed_eligible_subset'
    for axis in result['_named_fit']['factor_scores']:
        y = result['_named_fit']['factor_scores'].loc[ids, axis].values
        x = dates.loc[ids].values
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            row = {'spearman': list(spearmanr(x, y)), 'partials': {}}
            for name, controls in [('unknown', missing[:, :1]), ('unknown_and_structural', missing)]:
                ranked_controls = np.column_stack([rankdata(controls[:, j]) for j in range(controls.shape[1])])
                design = np.column_stack([np.ones(len(ids)), ranked_controls])
                if len(ids) <= np.linalg.matrix_rank(design) + 1:
                    row['partials'][name] = {'status': 'inestimable_residual_degrees_of_freedom'}
                else:
                    value = h.pipeline.partial_spearman(x, y, controls)
                    row['partials'][name] = {'status': 'computed' if np.isfinite(value).all() else 'undefined',
                                              'rho_p': clean(value)}
            row['warnings'] = [str(w.message) for w in caught]
        output['axes'][axis] = clean(row)
    return output


def scenario_datasets(datasets, scope):
    base, successor = datasets['baseline'], datasets['successor']
    retained = list(base.scores.index[~base.scores.index.isin(scope['retired_ids'])])
    # Originals for retired rows are analytical counterfactuals, never active output.
    corrections = concatenate([successor.subset(retained), base.subset(scope['retired_ids'])])
    corrections = corrections.subset(list(base.scores.index))
    qualified = concatenate([base.subset(retained), successor.subset(scope['new_ids'])])
    return {'baseline': base, 'retirement_only': base.subset(retained),
            'retained_corrections_only': corrections, 'qualified_successors_without_retained_corrections': qualified,
            'successor': successor}


def program_dataset(instruction, datasets, reader, columns):
    data = datasets['successor']
    kind = instruction['kind']
    require(kind in {'omission', 'boundary', 'metadata_only', 'weighting', 'editorial_only', 'unestimable'},
            'Unsupported alternative: no invented phase profiles/weights/methods')
    if kind in {'editorial_only', 'unestimable'}:
        require(instruction['reason'], 'Explicit editorial/unestimable limit required')
        return None
    drop = unique_ids(instruction.get('drop_ids', []), 'program omitted IDs')
    require(drop <= set(data.scores.index), 'Program drop ID missing')
    require(kind == 'boundary' or not instruction.get('add'), 'Only boundary scenarios can add archived coded rows')
    require(kind not in {'metadata_only', 'weighting'} or not drop,
            'Date/weight-only alternative cannot remove score rows')
    parts = [data.subset(list(data.scores.index[~data.scores.index.isin(drop)]))]
    for addition in instruction.get('add', []):
        require(addition['dataset'] not in {'successor'}, 'Boundary additions need explicit alternative coded input')
        unique_ids(addition['event_ids'], 'archived/alternative IDs')
        parts.append(datasets[addition['dataset']].subset(addition['event_ids']))
    result = concatenate(parts)
    if 'corpus' in instruction:
        corpus = pd.DataFrame(reader.json(instruction['corpus'])).set_index('event_id')
        require(corpus.index.is_unique and set(corpus.index) == set(result.scores.index), 'Alternative corpus join differs')
        result.corpus = corpus.loc[result.scores.index]
    if 'analysis_metadata' in instruction:
        analysis = pd.DataFrame(reader.json(instruction['analysis_metadata'])).set_index('event_id')
        require(analysis.index.is_unique and set(analysis.index) == set(result.scores.index), 'Alternative horizon join differs')
        result.analysis = analysis.loc[result.scores.index]
    require(list(result.scores.index) == instruction['expected_event_ids'], 'Program exact roster/order differs')
    return validate_dataset(result, columns)


def program_weights(instruction, data, reader):
    require(instruction['weight_kind'] in {'linked_program_total_one', 'illustrative_upper_bound',
                                         'legacy_calendar_envelope_stress_NOT_observed_duration'},
            'Weight sensitivity must retain its predeclared diagnostic meaning')
    require(type(instruction['seed_offset']) is int and instruction['seed_offset'] >= 10,
            'Provide a fixed program null-seed offset >=10, separate from builtin weights')
    values = reader.json(instruction['weights'])
    require(isinstance(values, dict) and set(values) == set(data.scores.index), 'Weight roster differs')
    weights = np.asarray([values[i] for i in data.scores.index], dtype=float)
    require(np.isfinite(weights).all() and (weights > 0).all(), 'Weights must be finite and positive')
    require(instruction['reason'] and instruction['eligibility_measurand_ref'],
            'Bound weighting authority and explicit eligibility/measurand explanation required')
    reader.read(instruction['eligibility_measurand_ref'])
    return weights


def public_result(result):
    if isinstance(result, dict):
        return {k: public_result(v) for k, v in result.items() if not str(k).startswith('_')}
    if isinstance(result, list):
        return [public_result(v) for v in result]
    return clean(result)


def run_suite(datasets, scope, programs, reference, reader, h, cache=None):
    engine = Engine(h, reference, cache)
    cases = scenario_datasets(datasets, scope)
    columns = list(reference.index)
    records, core_fits = [], {}

    def add(name, category, data, *, matrix=None, weights=None, offset=0, method='global_median', authorities=None):
        matrix = data.scores.fillna(data.scores.median()) if matrix is None else matrix
        result = engine.fit(matrix, weights=weights, seed_offset=offset, preprocessing=method,
                            checkpoint_label=name)
        record = {'scenario': name, 'category': category, 'authority_ids': authorities or [],
                  'result': result, 'comparisons': {}}
        for refname in ('baseline', 'successor'):
            if refname in core_fits:
                record['comparisons'][refname] = engine.compare(core_fits[refname], result)
        if weights is None:
            record['date_diagnostics'] = date_diagnostics(data, result, h)
        records.append(record)
        return result

    for name in ('baseline', 'successor'):
        core_fits[name] = engine.fit(cases[name].scores.fillna(cases[name].scores.median()),
                                    checkpoint_label=name + '/core_fit')
    for name, data in cases.items():
        add(name, 'effect_separation', data)
    for name in ('baseline', 'successor'):
        data = cases[name]
        raw = data.scores
        for offset, (label, groups) in enumerate((('equal_era', data.corpus['era_bucket_v2']),
                                                 ('equal_normalized_macroregion', data.analysis['normalized_macroregion']),
                                                 ('raw_region_string_stress_not_normalized', data.corpus['region'])), start=1):
            require(groups.notna().all(), 'Explicit weighting category missing: ' + label)
            add(name + '/' + label, 'weighting', data,
                weights=h.fairness.reciprocal_group_weights(groups), offset=offset)
        missing = data.na.isin(['U', 'NA']).sum(axis=1)
        for maximum in MISSINGNESS_MAXIMA:
            subset = data.subset(list(raw.index[missing <= maximum]))
            label = name + '/maximum_missing_' + str(maximum)
            if len(subset.scores) < 100:  # Preserved old suite eligibility, not a new cutoff.
                records.append({'scenario': label, 'category': 'missingness_subset',
                                'result': {'status': 'not_fit_sparse_legacy_minimum_100',
                                           'event_ids': list(subset.scores.index), 'events': len(subset.scores)}})
            else:
                add(label, 'missingness_subset', subset)
                add(label + '/frozen', 'missingness_subset', subset,
                    matrix=subset.scores.fillna(raw.median()), method='full_roster_frozen_medians')
        treatments = {
            'era_specific_median': lambda: h.legacy.era_median_imputation(raw, data.corpus['era_bucket_v2']),
            'unknown_knn_structural_median': lambda: h.legacy.knn_unknown_imputation(raw, data.na),
            'structural_zero_upper_bound_NOT_RECODE': lambda: h.legacy.structural_zero_imputation(raw, data.na),
        }
        for label, treatment in treatments.items():
            try:
                add(name + '/' + label, 'imputation', data, matrix=treatment(), method=label)
            except (ValueError, np.linalg.LinAlgError) as exc:
                records.append({'scenario': name + '/' + label, 'category': 'imputation',
                                'result': {'status': 'inestimable_preprocessing', 'error': str(exc)}})
    successor = datasets['successor']
    limits = []
    for instruction in programs['instructions']:
        data = program_dataset(instruction, datasets, reader, columns)
        if data is None:
            limits.append(instruction)
            continue
        if instruction['kind'] == 'weighting':
            add(instruction['id'], instruction['weight_kind'], data,
                weights=program_weights(instruction, data, reader), offset=instruction['seed_offset'],
                authorities=instruction['authority_ids'])
            continue
        for method in ('global_median', 'successor_frozen_medians'):
            matrix = data.scores.fillna(data.scores.median() if method == 'global_median' else successor.scores.median())
            add(instruction['id'] + '/' + method, instruction['kind'], data, matrix=matrix,
                method=method, authorities=instruction['authority_ids'])
        if instruction['kind'] == 'metadata_only':
            # Identical scores reuse the unweighted fit, but era/region weights,
            # era-specific imputation and the eligible-date diagnostics still run.
            for offset, (field, groups) in enumerate((('era', data.corpus['era_bucket_v2']),
                                                     ('macroregion', data.analysis['normalized_macroregion'])), start=1):
                add(instruction['id'] + '/' + field, 'metadata_only_weighting', data,
                    weights=h.fairness.reciprocal_group_weights(groups), offset=offset,
                    authorities=instruction['authority_ids'])
            add(instruction['id'] + '/era_imputation', 'metadata_only_imputation', data,
                matrix=h.legacy.era_median_imputation(data.scores, data.corpus['era_bucket_v2']),
                method='era_specific_median', authorities=instruction['authority_ids'])
    overlap = {}
    for name in ('baseline', 'successor'):
        def calculate_overlap():
            return h.overlap.run(datasets[name].scores)
        overlap[name] = (calculate_overlap() if cache is None else cache.unit(
            'indicator_overlap', (name, frame_key(datasets[name].scores)), name, calculate_overlap))
    return public_result({'status': 'computed_diagnostics_not_release_authority', 'scenarios': records,
                          'indicator_overlap': overlap, 'explicit_limits_and_editorial_only': limits,
                          'unique_preprocessed_matrix_cases': len(engine.fits), 'null_cache_entries': len(engine.nulls),
                          'candidate_activation_authorized': False, 'release_authorized': False,
                          'publication_authorized': False, 'deployment_authorized': False})


def run_bindings(reader):
    """Execution environment and all already-accepted inputs; no new selection."""
    reader.unchanged()
    return {'input_sha256': dict(reader.bindings),
            'numerical_dependencies_sha256': check_dependencies(),
            'dependency_manifest_sha256': digest((HERE / 'dependencies.json').read_bytes()),
            'adapter_sha256': {p.name: digest(p.read_bytes()) for p in sorted(HERE.glob('*.py'))},
            'randomness': {'seed_base': SEED, 'horn_draws': DRAWS, 'horn_percentile': 95,
                           'unweighted_seed': 'base+n', 'weighted_seed': 'base+1000+declared_offset',
                           'kmeans_random_state': 0, 'kmeans_n_init': 100},
            'runtime': {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
                        'optimize': sys.flags.optimize,
                        'packages': {p: importlib.metadata.version(p) for p in
                                     ('numpy', 'pandas', 'scipy', 'scikit-learn', 'factor-analyzer', 'threadpoolctl')}},
            'threads': {'environment': {name: os.environ.get(name) for name in (
                'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS',
                'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'OMP_DYNAMIC', 'MKL_DYNAMIC', 'PYTHONHASHSEED')},
                        'loaded_threadpools': threadpool_info()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--acceptance', type=Path, required=True)
    parser.add_argument('--acceptance-sha256', required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check-inputs', action='store_true')
    mode.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--resume', action='store_true', help='Reuse only an exact bound incomplete output run')
    args = parser.parse_args()
    require(not args.resume or args.execute, '--resume requires --execute')
    h = helpers()
    columns, _ = h.overlap.battery_columns()
    acceptance, datasets, scope, programs, reference, arithmetic, reader = load_contract(
        args.acceptance, args.acceptance_sha256, columns)
    # Validate all explicit alternatives before fitting any scenario.
    for instruction in programs['instructions']:
        alternative = program_dataset(instruction, datasets, reader, columns)
        if instruction['kind'] == 'weighting':
            program_weights(instruction, alternative, reader)
    if args.check_inputs:
        reader.unchanged()
        print(json.dumps({'status': 'INPUTS_VALIDATED_NO_FITS', 'arithmetic': arithmetic,
                          'input_sha256': reader.bindings}, indent=2))
        return
    require(acceptance.get('historical_fit_authorized') is True,
            'Complete candidate acceptance is not itself permission to execute the fit cycle')
    require(args.output is not None and args.output.resolve().is_relative_to(HERE)
            and args.output.resolve() != HERE and not args.output.is_symlink(),
            'Use a directory inside model_execution_v1; never overwrite baselines/results')
    bindings = run_bindings(reader)

    def validate_resume_inputs():
        require(run_bindings(reader) == bindings, 'Run input/code/runtime/thread/seed binding changed')

    # The complete-candidate and explicit historical-execution gates above still precede any cache use.
    with ResumeCache(args.output, bindings, resume=args.resume, validate=validate_resume_inputs) as cache:
        results = run_suite(datasets, scope, programs, reference, reader, h, cache)
        validate_resume_inputs()
        result_bytes = (json.dumps(results, indent=2, allow_nan=False) + '\n').encode()
        manifest = {'schema': 'successor-model-run-manifest-v1', 'release_cutoff': acceptance['release_cutoff'],
                'main_acceptance_ref': acceptance['main_acceptance_ref'], 'arithmetic': arithmetic,
                'input_sha256': reader.bindings,
                'numerical_dependencies_sha256': bindings['numerical_dependencies_sha256'],
                'adapter_sha256': bindings['adapter_sha256'], 'randomness': bindings['randomness'],
                'runtime': bindings['runtime'], 'threads': bindings['threads'],
                'checkpointing': {'run_bindings_sha256': cache.binding_sha,
                                  'cache_counts_not_scientific_fit_counts': cache.counts},
                'output_sha256': {'RESULTS.json': digest(result_bytes)},
                'performed_by': 'model-authored software; not human or external review',
                'release_authorized': False, 'activation_authorized': False}
        cache.finish(result_bytes, (json.dumps(manifest, indent=2, allow_nan=False) + '\n').encode())
    print('Completed one diagnostic cycle; no corpus activation or release authorized.')


if __name__ == '__main__':
    main()
