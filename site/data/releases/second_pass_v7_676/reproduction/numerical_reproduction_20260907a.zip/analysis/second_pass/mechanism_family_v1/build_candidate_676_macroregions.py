#!/usr/bin/env python3
"""Build the source-neutral macroregion crosswalk for the frozen 676-event candidate.

Only geographic metadata in corpus_v2.json is used.  The script deliberately
does not load mechanism reviews, family labels, traits, scores, models, or
prior mechanism/family diagnostics.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import sys
import tempfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SCRIPT = Path(__file__).resolve()
CORPUS = (
    ROOT
    / "analysis/second_pass/event_unit_fairness_v1/candidate_models_v2"
    / "canonical_successor_676/data/corpus_v2.json"
)
PROTOCOL = ROOT / "analysis/second_pass/mechanism_family_v1/CANDIDATE_676_ANALYSIS_PROTOCOL.md"
OUT_DIR = ROOT / "analysis/second_pass/mechanism_family_v1/candidate_676_macroregion_v1"
CSV_PATH = OUT_DIR / "candidate_676_macroregions.csv"
SUMMARY_PATH = OUT_DIR / "MACROREGION_SUMMARY.json"


VOCABULARY = {
    "CENTRAL_ASIA": "Central Asian interior, including Xinjiang and the Mongolian steppe where the event geography is centered there.",
    "CENTRAL_AFRICA": "Central African mainland and adjacent Gulf of Guinea islands.",
    "EAST_ASIA": "China outside the Central Asian interior, Korea, Japan, and Taiwan.",
    "EAST_AFRICA": "Horn, Great Lakes, eastern mainland Africa, Madagascar, and adjacent western Indian Ocean islands.",
    "EUROPE": "European mainland and islands, including European Russia and Mediterranean Europe.",
    "LATIN_AMERICA_CARIBBEAN": "Mexico, Central and South America, and the Caribbean.",
    "MULTIREGIONAL": "The event's operative geography crosses two or more normalized macroregions.",
    "NORTH_AFRICA": "North Africa, Egypt, and the Canary Islands.",
    "NORTH_AMERICA": "Canada, Greenland, the United States, and nearby North Atlantic islands tied to North America.",
    "NORTH_ASIA": "Siberia, the Russian Far East, and the trans-Ural northern Asian interior.",
    "OCEANIA": "Australia, Aotearoa New Zealand, Melanesia, Micronesia, and Polynesia.",
    "SOUTH_ASIA": "The Indian subcontinent, Afghanistan, Maldives, and adjacent South Asian territories.",
    "SOUTHEAST_ASIA": "Mainland and maritime Southeast Asia.",
    "SOUTHERN_AFRICA": "Southern African mainland and St Helena.",
    "WEST_AFRICA": "West African mainland and nearby Atlantic archipelagos.",
    "WEST_ASIA": "Anatolia, the Caucasus, Levant, Mesopotamia, Iran, and the Arabian Peninsula.",
}


REGION_GROUPS = {
    "NORTH_AMERICA": {
        "Alaska", "Arctic North America", "Atlantic Canada", "British Columbia",
        "California", "Canadian Prairies", "Chesapeake Bay", "Eastern Canada",
        "Eastern North America", "Great Lakes and St. Lawrence", "Great Plains",
        "Greenland", "Mid-Atlantic North America", "New England", "North America",
        "Northeastern North America", "Northern Canada", "Red River and Saskatchewan",
        "St. Lawrence Valley", "Southeastern North America", "Southwestern North America",
    },
    "LATIN_AMERICA_CARIBBEAN": {
        "Amazonia", "Caribbean", "Caribbean (Puerto Rico)", "Central America",
        "Eastern Caribbean", "Latin America", "Latin America and the Caribbean",
        "Lucayan Archipelago", "South America",
    },
    "EUROPE": {
        "Aegina", "Central Europe", "Central Mediterranean", "Central and Northern Europe",
        "Eastern Europe", "Eastern and Southeastern Europe", "Europe", "Europe and Eurasia",
        "Europe and the Mediterranean", "Lysimacheia on the Thracian Chersonese",
        "Mediterranean Europe", "Northern Europe", "Northern Europe (Denmark and southern Scandinavia)",
        "Northwestern Europe", "Samos, eastern Aegean", "Scione and the land granted to Plataeans",
        "Southeastern Europe", "Southern Europe", "Southwestern Europe (Iberian Peninsula)",
        "Thebes, Boeotia", "Western Europe", "Western Mediterranean",
    },
    "NORTH_AFRICA": {"North Africa", "Cyrene, with exile branches toward Thibron and Egypt"},
    "WEST_AFRICA": {"West Africa", "West Africa (Ghana)"},
    "CENTRAL_AFRICA": {"Central Africa"},
    "EAST_AFRICA": {
        "Bahr el-Ghazal, Upper Nile, and Equatoria (South Sudan)", "East Africa",
        "East Africa (northern Tanzania)", "East Africa (southwestern Uganda)", "Eastern Africa",
        "Great Lakes Africa", "Horn of Africa", "Northeastern Africa",
        "Zanzibar, Pemba, and the East African interior",
    },
    "SOUTHERN_AFRICA": {
        "Cape region", "Eastern Cape", "South Africa", "South African interior",
        "Southeastern Africa", "Southern Africa", "Southern Africa (Zambezi Valley, Zambia/Zimbabwe)",
        "Upper Zambezi floodplain, western Zambia",
    },
    "WEST_ASIA": {
        "Anatolia", "Anatolia and the Armenian Highlands", "Arabian Peninsula",
        "Astakene Gulf, Bithynia", "Cappadocia, Cilicia, Armenian Mesopotamia, and Tigranokerta",
        "Middle East", "Troad, northwestern Asia Minor", "Western Asia",
    },
    "CENTRAL_ASIA": {"Central Asia", "East and Central Asia", "Inner Asia"},
    "NORTH_ASIA": {
        "Eastern Siberia", "Northeastern Siberia and Kamchatka", "South-central Siberia",
        "Western Siberia",
    },
    "SOUTH_ASIA": {
        "South Asia", "South Asia (Chittagong Hill Tracts, East Pakistan/Bangladesh)",
        "South Asia (Gujarat, Maharashtra, Madhya Pradesh, India)", "Central and South Asia",
    },
    "EAST_ASIA": {"East Asia", "Southwestern China"},
    "SOUTHEAST_ASIA": {
        "Mainland Southeast Asia", "Mainland Southeast Asia (Vietnam, Laos, Thailand, Cambodia, Myanmar, Malay Peninsula)",
        "Southeast Asia",
    },
    "OCEANIA": {
        "Aotearoa New Zealand", "Australia", "Eastern Australia", "Melanesia", "Micronesia",
        "North Island, Aotearoa New Zealand", "Pacific and Oceania",
        "Pacific and Oceania (Vanuatu / Remote Oceania)", "Queensland and northern Australia",
        "Rēkohu / Chatham Islands", "South Island, Aotearoa New Zealand", "Southeastern Australia",
        "Tasmania", "Western Australia",
    },
    "MULTIREGIONAL": {
        "Algeria and France", "Eastern Mediterranean / Western Asia", "Europe / Middle East",
        "Europe / Russia and Central Asia", "Iran and the global diaspora", "Iraq and Israel",
        "Lebanon and the Mediterranean", "Libya and Israel", "Mediterranean",
        "Mediterranean and Europe", "Middle East and Indian Ocean",
        "Middle East and North Africa / Western Asia", "Morocco, Europe, and Israel",
        "North Africa / Central Asia", "North Africa and Europe", "South and West Asia",
        "Southern China and northern mainland Southeast Asia", "Southern Europe / Western Asia",
        "Southern Europe and Western Asia", "Soviet Union (European Russia and Ukraine to the North, Urals, Siberia, and Kazakhstan)",
        "Syria and the eastern Mediterranean", "Tunisia, France, and Israel", "Turkey and Israel",
        "West and Central Africa", "Western Asia / North Africa", "Western Europe and Atlantic diaspora",
        "Yemen, Aden, and Israel", "Lower Nubia", "Lower and Upper Nubia",
    },
}


REGION_MAP: dict[str, str] = {}
for category, regions in REGION_GROUPS.items():
    for region in regions:
        if region in REGION_MAP:
            raise RuntimeError(f"duplicate region rule: {region}")
        REGION_MAP[region] = category


EVENT_GROUPS = {
    "NORTH_AFRICA": {
        "atlas-french-algeria", "atlas-italian-libya", "atlas-western-sahara", "atlas-banu-hilal",
        "mena-arab-conquest-egypt", "mena-arab-conquest-settlement-maghreb",
        "af-french-settlement-morocco", "af-french-settlement-tunisia", "af-nubian-aswan-dam-displacement",
        "atlas-canary-la-gomera-revolt-repression", "atlas-canary-gran-canaria-conquest-1478-1483",
        "atlas-canary-la-palma-conquest-1492-1493", "atlas-canary-lanzarote-fuerteventura-conquest-1402-1405",
        "atlas-canary-tenerife-conquest-1494-1496",
        "prospective-suez-era-jewish-expulsion-and-departure-from-egypt-1956-1957",
        "prospective-egyptian-jewish-wartime-detention-and-compelled-departure-1967-1971",
    },
    "WEST_AFRICA": {
        "atlas-liberia", "atlas-sokoto-caliphate", "af-sierra-leone-freetown-settler-colony",
        "af-cote-ivoire-migrant-land-expulsions", "af-transatlantic-slave-removal-senegambia-upper-guinea",
        "af-transatlantic-slave-removal-gold-coast-bights", "af-cabo-verde-colonial-population-formation",
    },
    "CENTRAL_AFRICA": {
        "af-bantu-farmer-settlement-congo-basin", "af-bioko-colonial-plantations",
        "af-transatlantic-slave-removal-west-central", "af-sao-tome-plantation-slavery",
    },
    "EAST_AFRICA": {
        "atlas-kenya-highlands", "atlas-maasai-expansion", "atlas-nandi-uasin-gishu", "atlas-oromo-expansion",
        "atlas-luo-migration", "af-bantu-farmer-settlement-great-lakes", "af-bantu-farmer-settlement-eastern-africa",
        "af-italian-settlement-eritrea", "af-italian-settlement-somalia", "af-ethiopian-southern-conquest-neftenya",
        "af-ethiopian-derg-resettlement-villagization", "af-tanzania-operation-vijiji", "af-uganda-asian-expulsion",
        "af-rwanda-tutsi-expulsions", "af-rwanda-genocide-exodus-return", "af-merina-imperial-expansion",
        "indian-ocean-mayotte-wuambushu-evictions",
    },
    "SOUTHERN_AFRICA": {
        "atlas-namibia", "atlas-southern-rhodesia", "atlas-ndebele-shona", "atlas-oorlam-namibia",
        "af-bantu-farmer-settlement-southern-africa", "af-portuguese-settlement-angola",
        "af-portuguese-settlement-mozambique", "af-british-estates-malawi", "af-eswatini-concession-partition",
        "prospective-southeastern-africa-atlantic-slave-removal",
        "prospective-english-and-east-india-company-enslaved-labor-colony-on-st-helena-1659-1839",
        "prospective-crown-and-royal-navy-liberated-african-depot-on-st-helena-1840-1868",
    },
    "EUROPE": {
        "ca-imperial-russian-colonization-crimea", "ca-crimean-tatar-deportation-resettlement",
        "ca-russian-occupation-crimea-demographic-transfer", "ca-russian-occupation-ukraine-forced-transfer",
        "ca-russo-ukrainian-war-displacement", "modern-moldova-soviet-deportations",
        "eu-gibraltar-conquest-population-replacement", "med-greek-western-emporia-massalia",
        "europe-norse-settlement-faroes",
    },
    "NORTH_AMERICA": {
        "prospective-saint-pierre-miquelon-british-deportation-1778",
        "prospective-saint-pierre-miquelon-british-deportation-1793-1815",
    },
    "LATIN_AMERICA_CARIBBEAN": {"south-atlantic-british-falklands-colonization"},
    "WEST_ASIA": {
        "atlas-northern-cyprus", "atlas-iraqi-kurdistan-kirkuk", "atlas-syrian-arab-belt",
        "mena-zionist-settlement-ottoman-mandate-palestine", "mena-nakba-palestinian-displacement",
        "mena-negev-bedouin-dispossession", "mena-turkey-kurdish-village-clearances", "mena-iraq-anfal",
        "mena-iraq-marsh-arab-displacement", "mena-isis-yazidi-minority-displacement",
        "ancient-neo-babylonian-deportations-judah", "late-antique-sasanian-antioch-weh-antioch",
        "late-antique-sasanian-hatra-depopulation", "late-antique-sasanian-shapur-antioch-captivity",
        "late-antique-sasanian-shapur-dura-europos-deportation", "prospective-israeli-settlements-golan-heights",
        "prospective-israeli-settlements-west-bank-east-jerusalem", "prospective-palestinian-occupation-and-war-flight-from-kuwait-1990-1991",
        "prospective-post-liberation-kuwaiti-expulsion-and-residency-pressure", "prospective-1967-palestinian-cross-border-war-exodus",
        "ca-soviet-chechen-ingush-deportation", "ca-soviet-meskhetian-turk-deportation",
        "ca-nagorno-karabakh-armenian-exodus-2023", "ca-abkhazia-ethnic-cleansing", "ca-chechen-wars-displacement",
        "ca-prigorodny-ingush-expulsion", "prospective-soviet-balkar-deportation-1944-1957",
        "prospective-soviet-karachay-deportation-1943-1957", "prospective-south-ossetia-conflict-displacement-1991-1992",
        "prospective-august-2008-south-ossetia-conflict-and-immediate-aftermath-displacement",
        "prospective-nk-sumgait-anti-armenian-pogrom-1988", "prospective-nk-kirovabad-anti-armenian-riots-1988",
        "prospective-nk-baku-anti-armenian-pogrom-1990", "prospective-nk-operation-ring-armenian-displacement-1991",
        "prospective-nk-azerbaijani-counteroffensive-armenian-displacement-1992", "prospective-nk-lachin-azerbaijani-displacement-1992",
        "prospective-nk-surrounding-districts-azerbaijani-displacement-1993", "prospective-nk-april-offensive-azerbaijani-displacement-1994",
        "prospective-circassian-uzunyayla-collective-settlement", "prospective-circassian-wadi-al-sir-settlement-1880",
    },
    "CENTRAL_ASIA": {
        "atlas-kazakh-steppe", "atlas-dzungaria", "asia-qing-colonization-xinjiang",
        "asia-prc-xinjiang-xpcc-settlement", "asia-xinjiang-mass-detention-labor-transfer",
        "medieval-mongol-samarkand-artisan-and-youth-removals", "medieval-mongol-urgench-destruction-and-artisan-removal",
        "ca-osh-uzbek-displacement",
    },
    "NORTH_ASIA": {"atlas-bashkir-lands", "atlas-russian-far-east"},
    "SOUTH_ASIA": {
        "atlas-andaman-islands", "atlas-chittagong-hill-tracts", "atlas-sri-lanka-irrigation",
        "mena-hazara-war-dispossession", "mena-pashtun-resettlement-northern-afghanistan",
        "modern-afghanistan-soviet-war-displacement", "modern-afghanistan-civil-war-taliban-displacement",
        "modern-afghanistan-post-2001-conflict-displacement", "asia-northwest-pakistan-counterinsurgency-displacement",
        "asia-pakistan-afghan-mass-forced-returns", "indian-ocean-maldives-gan-base-relocation",
    },
    "EAST_ASIA": set(),
    "SOUTHEAST_ASIA": {
        "atlas-nam-tien", "atlas-mindanao", "atlas-vietnam-central-highlands", "atlas-indonesian-transmigration",
        "prospective-indochina-cambodia-khmer-rouge-evacuation", "prospective-indochina-cambodia-preah-vihear-refoulement",
        "prospective-indochina-laos-hmong-1986-pushback", "prospective-christmas-island-phosphate-colonial-bound-labor",
        "prospective-cocos-keeling-estate-bound-labor",
    },
    "OCEANIA": {"atlas-west-papua"},
    "MULTIREGIONAL": {
        "atlas-circassia", "atlas-indo-aryan-migration", "atlas-tai-ahom-assam", "atlas-bamar-pagan",
        "asia-rohingya-expulsions", "af-mascarene-seychelles-forced-population-formation", "af-chagos-forced-removal",
        "prospective-southeastern-africa-indian-ocean-slave-removal", "af-lake-chad-slave-raiding-displacement",
        "med-phoenician-trading-enclaves", "med-carthaginian-western-islands-iberia",
        "med-roman-caesarian-augustan-veteran-colonies", "med-greek-black-sea-colonies",
        "mena-safavid-armenian-deportation-aras-new-julfa-1604-1605", "mena-safavid-georgian-deportations-1614-1616",
        "prospective-circassian-danube-serbian-border-settlement", "prospective-circassian-danube-dobruja-agricultural-settlement",
        "prospective-indochina-vietnam-boat-exodus", "prospective-indochina-vietnam-hoa-china-flight",
        "pacific-australia-south-sea-islander-deportation-1906-1908", "pacific-queensland-islander-labour-recruitment-1863-1904",
        "ca-soviet-korean-deportation", "ca-soviet-volga-german-deportation", "ca-soviet-kalmyk-deportation",
        "eu-greek-turkish-population-exchange", "eu-armenian-genocide-deportation", "eu-assyrian-sayfo",
        "eu-ottoman-greek-deportations-expulsion", "prospective-istanbul-pogrom-1955",
        "prospective-istanbul-expulsion-and-asset-measures-1964",
        "prospective-baltic-june-1941-tristate-deportation", "prospective-estonia-german-nationality-deportation-1945",
        "prospective-lithuania-german-nationality-deportation-1945", "prospective-lithuania-operation-vesna-1948",
        "prospective-baltic-operation-priboi-1949", "prospective-baltic-operation-sever-april-1951",
        "prospective-lithuania-operation-osen-1951",
    },
}


EVENT_MAP: dict[str, str] = {}
for category, event_ids in EVENT_GROUPS.items():
    for event_id in event_ids:
        if event_id in EVENT_MAP and EVENT_MAP[event_id] != category:
            raise RuntimeError(f"conflicting event rule: {event_id}: {EVENT_MAP[event_id]} vs {category}")
        EVENT_MAP[event_id] = category


AMBIGUOUS_REGIONS = {
    "Africa", "Africa and the Atlantic", "Africa and the Indian Ocean", "Atlantic Islands",
    "Black Sea", "Central Asia / East Asia", "East and Central Asia", "Eastern Europe and Soviet interior",
    "Egypt and the Mediterranean", "Europe / Middle East", "Europe / Russia and Central Asia",
    "Indian Ocean", "Mediterranean", "Mediterranean and Europe", "Melanesia and Queensland, Australia",
    "Middle East and North Africa", "Middle East and the Caucasus", "North Atlantic",
    "Russia and Central Asia", "Russia, the Caucasus, and Central Asia", "South Atlantic",
    "South and Southeast Asia", "Southeast Asia and the Pacific",
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def resolve_macroregion(row: dict) -> tuple[str, str, str]:
    event_id = row["event_id"]
    raw_region = (row.get("region") or "").strip()
    if event_id in EVENT_MAP:
        category = EVENT_MAP[event_id]
        method = "event_geography_disambiguation"
        if category == "MULTIREGIONAL":
            note = "The event's operative origin, destination, or campaign geography crosses normalized macroregions."
        else:
            note = f"The named event territory is centered in {category}; actor nationality was not used."
        return category, method, note
    if raw_region in AMBIGUOUS_REGIONS:
        raise ValueError(f"ambiguous region lacks event rule: {event_id} | {raw_region}")
    category = REGION_MAP.get(raw_region)
    if category is None:
        raise ValueError(f"unresolved region: {event_id} | {raw_region!r}")
    if category == "MULTIREGIONAL":
        return category, "raw_region_explicit_multiregional", "The raw event geography explicitly spans normalized macroregions."
    return category, "raw_region_exact", f"The raw event region maps directly to {category}."


def build_outputs() -> tuple[bytes, bytes]:
    corpus_bytes = CORPUS.read_bytes()
    rows = json.loads(corpus_bytes)
    selected = [row for row in rows if row.get("in_model") is True]
    if len(selected) != 676:
        raise ValueError(f"expected 676 in-model rows, found {len(selected)}")
    event_ids = [row.get("event_id") for row in selected]
    if any(not value for value in event_ids) or len(set(event_ids)) != 676:
        raise ValueError("event_id values must be nonblank and unique")

    output_rows = []
    methods = Counter()
    counts = Counter()
    for position, row in enumerate(selected, start=1):
        category, method, note = resolve_macroregion(row)
        if category not in VOCABULARY:
            raise ValueError(f"undeclared macroregion {category} for {row['event_id']}")
        output_rows.append(
            {
                "corpus_position": position,
                "event_id": row["event_id"],
                "event_name": row.get("name", ""),
                "raw_region": row.get("region", ""),
                "container_countries": " | ".join(row.get("container_countries") or []),
                "victim_countries": " | ".join(row.get("victim_countries") or []),
                "normalized_macroregion": category,
                "mapping_method": method,
                "mapping_note": note,
            }
        )
        methods[method] += 1
        counts[category] += 1

    if len(output_rows) != 676 or sum(counts.values()) != 676:
        raise ValueError("crosswalk row accounting failed")
    if any(not row["normalized_macroregion"] for row in output_rows):
        raise ValueError("unresolved macroregion row")

    fieldnames = list(output_rows[0])
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(output_rows)
    csv_bytes = buffer.getvalue().encode("utf-8")

    summary = {
        "artifact": "candidate_676_source_neutral_macroregion_crosswalk",
        "candidate_row_count": 676,
        "selection_rule": "corpus_v2.json rows where in_model is true, preserving corpus order",
        "unresolved_row_count": 0,
        "vocabulary_size": len(VOCABULARY),
        "vocabulary": VOCABULARY,
        "macroregion_counts": dict(sorted(counts.items())),
        "mapping_method_counts": dict(sorted(methods.items())),
        "hashes": {
            "builder_sha256": sha256_path(SCRIPT),
            "corpus_v2_sha256": sha256_bytes(corpus_bytes),
            "analysis_protocol_sha256": sha256_path(PROTOCOL),
            "candidate_676_macroregions_csv_sha256": sha256_bytes(csv_bytes),
        },
        "authority": {
            "release": False,
            "ui": False,
            "deployment": False,
            "candidate_activation": False,
        },
        "scope_note": "Geographic normalization only; no mechanism, family, trait, score, model, or prior diagnostic input was consulted.",
    }
    summary_bytes = (json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    return csv_bytes, summary_bytes


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="compare regenerated bytes without writing")
    args = parser.parse_args()
    csv_bytes, summary_bytes = build_outputs()
    expected = {CSV_PATH: csv_bytes, SUMMARY_PATH: summary_bytes}

    if args.check:
        failures = []
        for path, generated in expected.items():
            if not path.exists():
                failures.append(f"missing: {path}")
            elif path.read_bytes() != generated:
                failures.append(f"byte mismatch: {path}")
        if failures:
            print("\n".join(failures), file=sys.stderr)
            return 1
        print("candidate_676_macroregions_reproduce_byte_for_byte")
        return 0

    for path, data in expected.items():
        atomic_write(path, data)
    print(f"wrote {len(json.loads(CORPUS.read_text()))} corpus rows; selected 676")
    print(CSV_PATH)
    print(SUMMARY_PATH)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
