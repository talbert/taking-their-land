"""Reuse bound numerical functions, without running historical module initializers."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.optimize import linear_sum_assignment
from scipy.stats import pearsonr, rankdata, spearmanr
from sklearn.cluster import KMeans
from sklearn.impute import KNNImputer
from sklearn.metrics import silhouette_score

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / '.git').exists())
SECOND = ROOT / 'analysis/second_pass'
SEED, DRAWS = 28082026, 500


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def check_dependencies():
    bindings = json.loads((HERE / 'dependencies.json').read_text())
    for relative, expected in bindings.items():
        if digest((ROOT / relative).read_bytes()) != expected:
            raise ValueError('Bound implementation/input changed: ' + relative)
    return bindings


def functions(path, names, **extra):
    # Compile original FunctionDef nodes unchanged. Never execute old top-level
    # mkdir, editorial JSON loads, roster constructors, build(), or main().
    tree = ast.parse(path.read_text(), filename=str(path))
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    if {n.name for n in nodes} != set(names) or any(n.decorator_list for n in nodes):
        raise ValueError('Selected helper interface changed: ' + str(path))
    namespace = {**globals(), **extra}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)
    return SimpleNamespace(**{name: namespace[name] for name in names})


def helpers():
    check_dependencies()
    pipeline = functions(SECOND / '12_run_second_pass.py', (
        'loading_congruence', 'align_factors', 'align_cluster_labels', 'partial_spearman'))
    legacy = functions(SECOND / 'v5/run_hellenistic_sensitivities.py', (
        'weighted_correlation', 'observed_eigenvalues', 'horn_thresholds',
        'fit_scores', 'era_median_imputation', 'knn_unknown_imputation',
        'structural_zero_imputation'), PIPELINE=pipeline, N_HORN=DRAWS)
    subspace = functions(SECOND / 'event_unit_fairness_v1/analyze_event_unit_subspace_stability_v2.py',
                         ('fit_loadings', 'weighted_correlation', 'era_imputation',
                          'knn_imputation', 'structural_zero_imputation'))
    fairness = functions(SECOND / 'event_unit_fairness_v1/run_event_unit_fairness_models_v2.py',
                         ('reciprocal_group_weights',))
    path = HERE.parent / 'indicator_overlap.py'
    spec = importlib.util.spec_from_file_location('successor_indicator_overlap', path)
    overlap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(overlap)  # Inspected: constants/functions only, no writer.
    return SimpleNamespace(pipeline=pipeline, legacy=legacy, subspace=subspace,
                           fairness=fairness, overlap=overlap)
