#!/usr/bin/env python3
"""Run the preregistered suite on the scope-corrected v2 candidates.

The suite is diagnostic. It compares explicit rosters and plausible boundary,
grouping, weighting, missingness, and influence alternatives without using a
statistical result to decide historical inclusion.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import io
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import adjusted_rand_score


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
SECOND = ROOT / "analysis" / "second_pass"
V4 = SECOND / "releases" / "second_pass_v4_583"
CANDIDATES = HERE / "candidate_models_v2"
PARENT = CANDIDATES / "corrected_parent_reference_580"
SUCCESSOR = CANDIDATES / "canonical_successor_676"
PRIOR = SECOND / "v5" / "recode_application_v1" / "model_rerun_v1" / "candidates"
PRIOR_FULL = PRIOR / "corrected_full_equal_event_675"
PRIOR_SUCCESSOR = PRIOR / "corrected_successor_only_671"
LEGACY_PATH = SECOND / "v5" / "run_hellenistic_sensitivities.py"
GROUPS = CANDIDATES / "sensitivity_groups.csv"
MEMBERSHIP = CANDIDATES / "candidate_membership.csv"
DISPOSITIONS = CANDIDATES / "parent_replacement_dispositions.csv"
BOUNDARY = HERE / "final_event_unit_register_v1" / "event_unit_boundary_register.csv"
PACKETS = HERE / "prospective_target_score_v1" / "score_packets"
OUT = CANDIDATES / "model_results_v2"
SEED = 27082026

CORE = OUT / "core_scenario_metrics.csv"
FACTORS = OUT / "factor_metrics.csv"
PROGRAMS = OUT / "program_sensitivity_metrics.csv"
WEIGHTING = OUT / "weighting_metrics.csv"
DOCUMENTATION = OUT / "documentation_strata.csv"
SOURCE_STRATA = OUT / "source_resolution_strata.csv"
IMPUTATION = OUT / "imputation_metrics.csv"
INFLUENCE = OUT / "event_influence.csv"
COVERAGE = OUT / "metadata_stratum_coverage.csv"
SUMMARY = OUT / "MODEL_RESULTS_SUMMARY.json"
MANIFEST = OUT / "RESULTS_MANIFEST.json"


def load_legacy():
    spec = importlib.util.spec_from_file_location("event_unit_legacy_helpers", LEGACY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load validated statistical helpers")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SEED = SEED
    module.N_HORN = 500
    return module


LEGACY = load_legacy()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def render_csv(rows: list[dict[str, Any]]) -> bytes:
    if not rows:
        raise RuntimeError("cannot render an empty table")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def safe_rho(left: pd.Series, right: pd.Series) -> float:
    value, _ = spearmanr(left, right)
    return float(value) if np.isfinite(value) else 0.0


def group_register() -> dict[str, dict[str, list[str]]]:
    result: dict[str, dict[str, list[str]]] = {}
    for row in read_csv(GROUPS):
        result[row["sensitivity_group_id"]] = {
            "parents": [part.strip() for part in row["parent_event_ids"].split("|") if part.strip()],
            "targets": [part.strip() for part in row["target_event_ids"].split("|") if part.strip()],
        }
    if len(result) != 69:
        raise RuntimeError("sensitivity-group count differs")
    if len([target for group in result.values() for target in group["targets"]]) != 157:
        raise RuntimeError("sensitivity-group target coverage differs")
    return result


def complete_parent_dataset(
    parent: dict[str, Any], prior_full: dict[str, Any]
) -> dict[str, Any]:
    rows = read_csv(DISPOSITIONS)
    inactive = [row["parent_event_id"] for row in rows if row["active_in_v4"] == "false"]
    if len(inactive) != 9 or not set(inactive) <= set(prior_full["scores"].index):
        raise RuntimeError("complete-parent profile source differs")
    scores = pd.concat([parent["scores"], prior_full["scores"].loc[inactive]])
    na_types = pd.concat([parent["na_types"], prior_full["na_types"].loc[inactive]])
    corpus = pd.concat([parent["corpus"], prior_full["corpus"].loc[inactive]])
    if len(scores) != 589 or len(set(scores.index)) != 589:
        raise RuntimeError("complete parent alternative is not 589 unique events")
    return {"scores": scores, "na_types": na_types, "corpus": corpus}


def collapse_target_groups(
    scores: pd.DataFrame, groups: dict[str, dict[str, list[str]]]
) -> pd.DataFrame:
    targets = [target for group in groups.values() for target in group["targets"]]
    base = scores.drop(index=targets)
    pseudo = pd.DataFrame(
        [scores.loc[group["targets"]].median(axis=0, skipna=True) for group in groups.values()],
        index=[f"__event_unit_group_median_{name}" for name in groups],
        columns=scores.columns,
    )
    result = pd.concat([base, pseudo])
    if len(result) != 588:
        raise RuntimeError("grouped-program median scenario is not 588 rows")
    return result


def comparison_metrics(
    fit: dict[str, Any], scores: pd.DataFrame, reference: dict[str, Any]
) -> dict[str, Any]:
    shared = reference["factor_scores"].index.intersection(scores.index)
    positions = scores.index.get_indexer(shared)
    labels = fit["labels"][positions]
    prior = reference["labels"].loc[shared].astype(int).to_numpy()
    aligned, _, _ = LEGACY.PIPELINE.align_cluster_labels(prior, labels)
    tucker = [
        abs(LEGACY.tucker(reference["loadings"][factor], fit["loadings"][factor]))
        for factor in reference["loadings"].columns
    ]
    rhos = [
        safe_rho(
            reference["factor_scores"].loc[shared, factor],
            fit["factor_scores"].loc[shared, factor],
        )
        for factor in reference["factor_scores"].columns
    ]
    changed = int(np.sum(prior != aligned))
    return {
        "shared_events": len(shared),
        "minimum_loading_tucker": float(min(tucker)),
        "mean_loading_tucker": float(np.mean(tucker)),
        "minimum_shared_score_spearman": float(min(rhos)),
        "mean_shared_score_spearman": float(np.mean(rhos)),
        "aligned_k6_changed": changed,
        "aligned_k6_changed_share": float(changed / len(shared)),
        "adjusted_rand": float(adjusted_rand_score(prior, labels)),
        "factor_tucker": tucker,
        "factor_spearman": rhos,
    }


def fit_scenario(
    scores: pd.DataFrame,
    named_loadings: pd.DataFrame,
    horn_cache: dict[int, np.ndarray],
) -> dict[str, Any]:
    fit = LEGACY.fit_scores(scores, named_loadings)
    eigenvalues, _ = LEGACY.observed_eigenvalues(fit["imputed"].values)
    thresholds = horn_cache.get(len(scores))
    if thresholds is None:
        thresholds = LEGACY.horn_thresholds(
            len(scores), scores.shape[1], seed=SEED + len(scores)
        )
        horn_cache[len(scores)] = thresholds
    fit["parallel_analysis_factors"] = int(np.sum(eigenvalues > thresholds))
    fit["factor_8_margin"] = float(eigenvalues[7] - thresholds[7])
    fit["factor_9_margin"] = float(eigenvalues[8] - thresholds[8])
    fit["factor_10_margin"] = float(eigenvalues[9] - thresholds[9])
    return fit


def metric_row(
    name: str,
    mode: str,
    scores: pd.DataFrame,
    fit: dict[str, Any],
    v4_reference: dict[str, Any],
    parent_reference: dict[str, Any],
    canonical_reference: dict[str, Any],
    factor_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    versus_v4 = comparison_metrics(fit, scores, v4_reference)
    versus_parent = comparison_metrics(fit, scores, parent_reference)
    versus_canonical = comparison_metrics(fit, scores, canonical_reference)
    for index, factor in enumerate(v4_reference["loadings"].columns):
        factor_rows.append(
            {
                "scenario": name,
                "mode": mode,
                "factor": factor,
                "loading_tucker_vs_v4": versus_v4["factor_tucker"][index],
                "shared_score_spearman_vs_v4": versus_v4["factor_spearman"][index],
                "loading_tucker_vs_corrected_parent": versus_parent["factor_tucker"][index],
                "shared_score_spearman_vs_corrected_parent": versus_parent["factor_spearman"][index],
                "loading_tucker_vs_canonical_successor": versus_canonical["factor_tucker"][index],
                "shared_score_spearman_vs_canonical_successor": versus_canonical["factor_spearman"][index],
            }
        )
    factor_count = fit["parallel_analysis_factors"]
    material_v4 = bool(
        factor_count != v4_reference["parallel_analysis_factors"]
        or versus_v4["minimum_loading_tucker"] < 0.85
        or versus_v4["minimum_shared_score_spearman"] < 0.90
        or versus_v4["aligned_k6_changed_share"] > 0.05
    )
    material_parent = bool(
        factor_count != parent_reference["parallel_analysis_factors"]
        or versus_parent["minimum_loading_tucker"] < 0.85
        or versus_parent["minimum_shared_score_spearman"] < 0.90
        or versus_parent["aligned_k6_changed_share"] > 0.05
    )
    material_canonical = bool(
        factor_count != canonical_reference["parallel_analysis_factors"]
        or versus_canonical["minimum_loading_tucker"] < 0.85
        or versus_canonical["minimum_shared_score_spearman"] < 0.90
        or versus_canonical["aligned_k6_changed_share"] > 0.05
    )
    return {
        "scenario": name,
        "mode": mode,
        "rows_in_model_or_sensitivity": len(scores),
        "pseudo_rows": int(sum(str(value).startswith("__") for value in scores.index)),
        "parallel_analysis_factors": factor_count,
        "factor_8_margin": fit["factor_8_margin"],
        "factor_9_margin": fit["factor_9_margin"],
        "factor_10_margin": fit["factor_10_margin"],
        "shared_v4_events": versus_v4["shared_events"],
        "minimum_loading_tucker_vs_v4": versus_v4["minimum_loading_tucker"],
        "minimum_shared_score_spearman_vs_v4": versus_v4["minimum_shared_score_spearman"],
        "aligned_k6_changed_share_vs_v4": versus_v4["aligned_k6_changed_share"],
        "adjusted_rand_vs_v4": versus_v4["adjusted_rand"],
        "shared_corrected_parent_events": versus_parent["shared_events"],
        "minimum_loading_tucker_vs_corrected_parent": versus_parent["minimum_loading_tucker"],
        "minimum_shared_score_spearman_vs_corrected_parent": versus_parent["minimum_shared_score_spearman"],
        "aligned_k6_changed_share_vs_corrected_parent": versus_parent["aligned_k6_changed_share"],
        "adjusted_rand_vs_corrected_parent": versus_parent["adjusted_rand"],
        "shared_canonical_successor_events": versus_canonical["shared_events"],
        "minimum_loading_tucker_vs_canonical_successor": versus_canonical["minimum_loading_tucker"],
        "minimum_shared_score_spearman_vs_canonical_successor": versus_canonical["minimum_shared_score_spearman"],
        "aligned_k6_changed_share_vs_canonical_successor": versus_canonical["aligned_k6_changed_share"],
        "adjusted_rand_vs_canonical_successor": versus_canonical["adjusted_rand"],
        "k6_silhouette": fit["silhouette"],
        "material_flag_vs_v4": material_v4,
        "material_flag_vs_corrected_parent": material_parent,
        "material_flag_vs_canonical_successor": material_canonical,
    }


def weighted_row(
    name: str,
    scores: pd.DataFrame,
    weights: np.ndarray,
    canonical_fit: dict[str, Any],
    v4_reference: dict[str, Any],
    parent_reference: dict[str, Any],
    seed_offset: int,
) -> dict[str, Any]:
    imputed = scores.fillna(scores.median())
    eigenvalues, correlation = LEGACY.observed_eigenvalues(imputed.values, weights)
    thresholds = LEGACY.horn_thresholds(
        len(scores), scores.shape[1], weights=weights, seed=SEED + 10000 + seed_offset
    )
    raw = LEGACY.fit_correlation(correlation, scores.columns)
    versus_v4 = LEGACY.align_loadings(v4_reference["loadings"], raw)
    versus_parent = LEGACY.align_loadings(parent_reference["loadings"], raw)
    versus_canonical = LEGACY.align_loadings(canonical_fit["loadings"], raw)

    def congruences(reference: pd.DataFrame, aligned: pd.DataFrame) -> list[float]:
        return [
            abs(LEGACY.tucker(reference[factor], aligned[factor]))
            for factor in reference.columns
        ]

    v4_values = congruences(v4_reference["loadings"], versus_v4)
    parent_values = congruences(parent_reference["loadings"], versus_parent)
    canonical_values = congruences(canonical_fit["loadings"], versus_canonical)
    factor_count = int(np.sum(eigenvalues > thresholds))
    return {
        "weighting": name,
        "sum_weights": float(weights.sum()),
        "effective_sample_size": float(weights.sum() ** 2 / np.sum(weights**2)),
        "minimum_weight": float(weights.min()),
        "maximum_weight": float(weights.max()),
        "parallel_analysis_factors": factor_count,
        "factor_8_margin": float(eigenvalues[7] - thresholds[7]),
        "factor_9_margin": float(eigenvalues[8] - thresholds[8]),
        "factor_10_margin": float(eigenvalues[9] - thresholds[9]),
        "minimum_loading_tucker_vs_v4": float(min(v4_values)),
        "minimum_loading_tucker_vs_corrected_parent": float(min(parent_values)),
        "minimum_loading_tucker_vs_canonical_unweighted": float(min(canonical_values)),
        "material_factor_or_loading_flag_vs_corrected_parent": bool(
            factor_count != parent_reference["parallel_analysis_factors"]
            or min(parent_values) < 0.85
        ),
        "material_factor_or_loading_flag_vs_canonical_unweighted": bool(
            factor_count != canonical_fit["parallel_analysis_factors"]
            or min(canonical_values) < 0.85
        ),
    }


def reciprocal_group_weights(values: pd.Series) -> np.ndarray:
    counts = values.value_counts(dropna=False)
    return values.map(lambda value: 1.0 / counts[value]).to_numpy(dtype=float)


def metadata_records(
    successor: dict[str, Any], target_ids: set[str]
) -> tuple[dict[str, dict[str, str]], list[dict[str, Any]]]:
    records: dict[str, dict[str, str]] = {
        event_id: {
            "source_resolution": "UNRESOLVED_METADATA",
            "geographic_scale": "UNRESOLVED_METADATA",
            "population_scale": "UNRESOLVED_METADATA",
            "land_outcome": "UNNORMALIZED",
            "causal_sequence": "UNNORMALIZED",
        }
        for event_id in successor["scores"].index
    }
    boundary_by_id = {row["event_id"]: row for row in read_csv(BOUNDARY)}
    for event_id in set(records) - target_ids:
        row = boundary_by_id.get(event_id)
        if not row:
            continue
        selected: dict[str, Any] = {}
        for field in (
            "selected_event_unit_record_json",
            "calibration_reviewer_a_record_json",
            "calibration_reviewer_b_record_json",
        ):
            raw = row.get(field, "").strip()
            if raw:
                try:
                    selected = json.loads(raw)
                    break
                except json.JSONDecodeError:
                    pass
        for field in ("source_resolution_stratum", "geographic_scale", "population_scale"):
            value = str(selected.get(field, "")).strip()
            if value:
                records[event_id][field.replace("_stratum", "")] = value
    for path in sorted(PACKETS.glob("prospective_score_packet_*.json")):
        for event in json.loads(path.read_text(encoding="utf-8"))["events"]:
            event_id = event["metadata"]["event_id"]
            if event_id not in records:
                continue
            dossier = event["source_dossier"]
            records[event_id].update(
                {
                    "source_resolution": dossier["source_gate_disposition"],
                    "geographic_scale": "NARRATIVE_TERRITORY_NOT_NORMALIZED",
                    "population_scale": "NARRATIVE_POPULATION_NOT_NORMALIZED",
                    "land_outcome": "TRAIT_CODED_NOT_NORMALIZED_TO_PUBLIC_OUTCOME",
                    "causal_sequence": "NARRATIVE_NOT_NORMALIZED",
                }
            )
    coverage_rows: list[dict[str, Any]] = []
    for field in (
        "source_resolution",
        "geographic_scale",
        "population_scale",
        "land_outcome",
        "causal_sequence",
    ):
        values = [record[field] for record in records.values()]
        unresolved = sum("UNRESOLVED" in value or "UNNORMALIZED" in value for value in values)
        coverage_rows.append(
            {
                "stratum": field,
                "active_events": len(values),
                "resolved_or_narrative_events": len(values) - unresolved,
                "unresolved_or_unnormalized_events": unresolved,
                "distinct_values": len(set(values)),
                "model_weighting_run": field == "source_resolution",
                "publication_ready": False,
                "note": (
                    "Normalized metadata is incomplete; this coverage record prevents "
                    "narrative wording from masquerading as a categorical stratum."
                ),
            }
        )
    coverage_rows.extend(
        [
            {
                "stratum": "region_raw",
                "active_events": len(successor["corpus"]),
                "resolved_or_narrative_events": int(successor["corpus"]["region"].notna().sum()),
                "unresolved_or_unnormalized_events": 0,
                "distinct_values": int(successor["corpus"]["region"].nunique()),
                "model_weighting_run": True,
                "publication_ready": False,
                "note": "Raw region strings are used only as an intentionally harsh diagnostic pending a normalized macroregion crosswalk.",
            },
            {
                "stratum": "mechanism_raw",
                "active_events": len(successor["corpus"]),
                "resolved_or_narrative_events": int(successor["corpus"]["mechanism"].notna().sum()),
                "unresolved_or_unnormalized_events": 0,
                "distinct_values": int(successor["corpus"]["mechanism"].nunique()),
                "model_weighting_run": True,
                "publication_ready": False,
                "note": "Raw mechanism strings are used only as an intentionally harsh diagnostic pending the mechanism-normalization decision.",
            },
            {
                "stratum": "atlas_status",
                "active_events": len(successor["corpus"]),
                "resolved_or_narrative_events": len(successor["corpus"]),
                "unresolved_or_unnormalized_events": 0,
                "distinct_values": int(successor["corpus"]["on_atlas"].nunique()),
                "model_weighting_run": True,
                "publication_ready": True,
                "note": "Boolean current-atlas status is fully observed and is not evidence for inclusion.",
            },
        ]
    )
    return records, coverage_rows


def build() -> dict[str, Any]:
    datasets = {
        "published_v4_583": LEGACY.load_dataset(V4),
        "corrected_parent_reference_580": LEGACY.load_dataset(PARENT),
        "canonical_successor_676": LEGACY.load_dataset(SUCCESSOR),
        "prior_corrected_hellenistic_675": LEGACY.load_dataset(PRIOR_FULL),
        "prior_hellenistic_successor_671": LEGACY.load_dataset(PRIOR_SUCCESSOR),
    }
    if {name: len(data["scores"]) for name, data in datasets.items()} != {
        "published_v4_583": 583,
        "corrected_parent_reference_580": 580,
        "canonical_successor_676": 676,
        "prior_corrected_hellenistic_675": 675,
        "prior_hellenistic_successor_671": 671,
    }:
        raise RuntimeError("candidate dataset counts differ")
    groups = group_register()
    parent = datasets["corrected_parent_reference_580"]
    successor = datasets["canonical_successor_676"]
    complete_parent = complete_parent_dataset(parent, datasets["prior_corrected_hellenistic_675"])
    target_ids = {
        row["event_id"]
        for row in read_csv(MEMBERSHIP)
        if row["candidate_id"] == "canonical_successor_676"
        and row["membership_origin"] == "prospective_successor"
    }
    if len(target_ids) != 157:
        raise RuntimeError("canonical target membership differs")
    proxy_ids = set(
        successor["corpus"].index[
            successor["corpus"].get("date_numeric_proxy_used", False).fillna(False).astype(bool)
        ]
    )
    if len(proxy_ids) != 39 or not proxy_ids <= target_ids:
        raise RuntimeError("date-proxy universe differs")

    named_loadings = pd.read_csv(V4 / "results" / "loadings_aligned.csv", index_col=0)
    published_reference: dict[str, Any] = {
        "loadings": named_loadings,
        "factor_scores": pd.read_csv(V4 / "results" / "factor_scores_aligned.csv", index_col=0),
        "labels": pd.read_csv(V4 / "results" / "clean_k6_assignments.csv", index_col=0)["cluster"].astype(int),
        "parallel_analysis_factors": 8,
    }
    horn_cache: dict[int, np.ndarray] = {}
    parent_fit = fit_scenario(parent["scores"], named_loadings, horn_cache)
    parent_reference = {
        "loadings": parent_fit["loadings"],
        "factor_scores": parent_fit["factor_scores"],
        "labels": pd.Series(parent_fit["labels"], index=parent["scores"].index),
        "parallel_analysis_factors": parent_fit["parallel_analysis_factors"],
    }
    grouped = collapse_target_groups(successor["scores"], groups)
    one_median = successor["scores"].drop(index=sorted(target_ids))
    one_median.loc["__all_157_successors_one_median"] = successor["scores"].loc[sorted(target_ids)].median(axis=0, skipna=True)
    core_scores: dict[str, tuple[str, pd.DataFrame]] = {
        "published_v4_583": ("published_reference", datasets["published_v4_583"]["scores"]),
        "corrected_parent_reference_580": ("scope_corrected_profiles", parent["scores"]),
        "complete_parent_alternative_589": ("all_70_reviewed_parents_no_successors", complete_parent["scores"]),
        "canonical_successor_676": ("exclude_3_retire_61_active_parents_add_157_successors", successor["scores"]),
        "grouped_program_medians_588": ("69_linked_program_medians", grouped),
        "all_successors_one_median_520": ("harsh_source_density_lower_bound", one_median),
        "canonical_without_date_proxies_637": ("drop_39_sort_proxy_events", successor["scores"].drop(index=sorted(proxy_ids))),
        "prior_corrected_hellenistic_675": ("separate_prior_research_branch", datasets["prior_corrected_hellenistic_675"]["scores"]),
        "prior_hellenistic_successor_671": ("separate_prior_successor_branch", datasets["prior_hellenistic_successor_671"]["scores"]),
    }
    factor_rows: list[dict[str, Any]] = []
    core_rows: list[dict[str, Any]] = []
    core_fits: dict[str, dict[str, Any]] = {}
    canonical_fit = fit_scenario(successor["scores"], named_loadings, horn_cache)
    canonical_reference = {
        "loadings": canonical_fit["loadings"],
        "factor_scores": canonical_fit["factor_scores"],
        "labels": pd.Series(canonical_fit["labels"], index=successor["scores"].index),
        "parallel_analysis_factors": canonical_fit["parallel_analysis_factors"],
    }
    for name, (mode, scores) in core_scores.items():
        if name == "corrected_parent_reference_580":
            fit = parent_fit
        elif name == "canonical_successor_676":
            fit = canonical_fit
        else:
            fit = fit_scenario(scores, named_loadings, horn_cache)
        core_fits[name] = fit
        core_rows.append(
            metric_row(
                name, mode, scores, fit, published_reference, parent_reference,
                canonical_reference, factor_rows,
            )
        )

    program_rows: list[dict[str, Any]] = []
    for group_id, members in groups.items():
        targets = members["targets"]
        parents = members["parents"]
        swap = pd.concat([
            successor["scores"].drop(index=targets),
            complete_parent["scores"].loc[parents],
        ])
        leave = successor["scores"].drop(index=targets)
        for action, scores in (("swap_successors_to_parents", swap), ("leave_program_out", leave)):
            fit = fit_scenario(scores, named_loadings, horn_cache)
            row = metric_row(
                f"{action}__{group_id}", action, scores, fit,
                published_reference, parent_reference, canonical_reference, factor_rows,
            )
            row.update(
                {
                    "sensitivity_group_id": group_id,
                    "parent_count": len(parents),
                    "target_count": len(targets),
                    "parent_event_ids": " | ".join(parents),
                    "target_event_ids": " | ".join(targets),
                }
            )
            program_rows.append(row)

    corpus = successor["corpus"]
    era_weights = reciprocal_group_weights(corpus["era_bucket_v2"].fillna("UNRESOLVED"))
    region_weights = reciprocal_group_weights(corpus["region"].fillna("UNRESOLVED"))
    mechanism_weights = reciprocal_group_weights(corpus["mechanism"].fillna("UNRESOLVED"))
    atlas_weights = reciprocal_group_weights(corpus["on_atlas"].astype(str))
    program_weights = np.ones(len(corpus), dtype=float)
    for members in groups.values():
        for event_id in members["targets"]:
            program_weights[corpus.index.get_loc(event_id)] = 1.0 / len(members["targets"])
    duration_weights = np.ones(len(corpus), dtype=float)
    observed_duration_values: list[float] = []
    observed_positions: list[int] = []
    for position, (event_id, row) in enumerate(corpus.iterrows()):
        if event_id in proxy_ids:
            continue
        start = row.get("operative_date_start", row.get("start"))
        end = row.get("operative_date_end", row.get("end"))
        if pd.isna(start) or pd.isna(end):
            continue
        observed_duration_values.append(abs(float(end) - float(start)) + 1.0)
        observed_positions.append(position)
    transformed = np.clip(1.0 + np.log1p(np.asarray(observed_duration_values)), 1.0, 5.0)
    transformed = transformed / transformed.mean()
    for position, value in zip(observed_positions, transformed):
        duration_weights[position] = value
    weighting_scenarios = {
        "unweighted_equal_event": np.ones(len(corpus), dtype=float),
        "equal_total_weight_per_era": era_weights,
        "equal_total_weight_per_raw_region_string": region_weights,
        "equal_total_weight_per_raw_mechanism_string": mechanism_weights,
        "equal_total_weight_per_atlas_status": atlas_weights,
        "linked_successor_program_total_weight_one": program_weights,
        "bounded_log_duration_observed_bounds_only_proxy_neutral": duration_weights,
    }
    weighting_rows = [
        weighted_row(
            name,
            successor["scores"],
            weights,
            canonical_fit,
            published_reference,
            parent_reference,
            index,
        )
        for index, (name, weights) in enumerate(weighting_scenarios.items())
    ]

    documentation_rows: list[dict[str, Any]] = []
    for label, dataset in (
        ("corrected_parent_reference_580", parent),
        ("canonical_successor_676", successor),
    ):
        missing = ((dataset["na_types"] == "U") | (dataset["na_types"] == "NA")).sum(axis=1)
        for maximum in (0, 5, 10, 15, 20, 30, 40, 50):
            subset = dataset["scores"].loc[missing <= maximum]
            row: dict[str, Any] = {
                "dataset": label,
                "maximum_missing_cells_per_event": maximum,
                "n_events": len(subset),
                "prospective_successors_retained": int(subset.index.isin(target_ids).sum()),
                "factor_model_run": False,
                "parallel_analysis_factors": "",
                "minimum_loading_tucker_vs_corrected_parent": "",
                "minimum_shared_score_spearman_vs_corrected_parent": "",
                "aligned_k6_changed_share_vs_corrected_parent": "",
                "material_flag_vs_corrected_parent": "",
                "minimum_loading_tucker_vs_canonical_successor": "",
                "minimum_shared_score_spearman_vs_canonical_successor": "",
                "aligned_k6_changed_share_vs_canonical_successor": "",
                "material_flag_vs_canonical_successor": "",
            }
            if len(subset) >= 100:
                fit = fit_scenario(subset, named_loadings, horn_cache)
                comparison = comparison_metrics(fit, subset, parent_reference)
                canonical_comparison = comparison_metrics(fit, subset, canonical_reference)
                row.update(
                    {
                        "factor_model_run": True,
                        "parallel_analysis_factors": fit["parallel_analysis_factors"],
                        "minimum_loading_tucker_vs_corrected_parent": comparison["minimum_loading_tucker"],
                        "minimum_shared_score_spearman_vs_corrected_parent": comparison["minimum_shared_score_spearman"],
                        "aligned_k6_changed_share_vs_corrected_parent": comparison["aligned_k6_changed_share"],
                        "material_flag_vs_corrected_parent": bool(
                            fit["parallel_analysis_factors"] != parent_reference["parallel_analysis_factors"]
                            or comparison["minimum_loading_tucker"] < 0.85
                            or comparison["minimum_shared_score_spearman"] < 0.90
                            or comparison["aligned_k6_changed_share"] > 0.05
                        ),
                        "minimum_loading_tucker_vs_canonical_successor": canonical_comparison["minimum_loading_tucker"],
                        "minimum_shared_score_spearman_vs_canonical_successor": canonical_comparison["minimum_shared_score_spearman"],
                        "aligned_k6_changed_share_vs_canonical_successor": canonical_comparison["aligned_k6_changed_share"],
                        "material_flag_vs_canonical_successor": bool(
                            fit["parallel_analysis_factors"] != canonical_reference["parallel_analysis_factors"]
                            or canonical_comparison["minimum_loading_tucker"] < 0.85
                            or canonical_comparison["minimum_shared_score_spearman"] < 0.90
                            or canonical_comparison["aligned_k6_changed_share"] > 0.05
                        ),
                    }
                )
            documentation_rows.append(row)

    metadata, coverage_rows = metadata_records(successor, target_ids)
    source_rows: list[dict[str, Any]] = []
    source_values = pd.Series(
        {event_id: metadata[event_id]["source_resolution"] for event_id in successor["scores"].index}
    )
    successor_missing = ((successor["na_types"] == "U") | (successor["na_types"] == "NA")).sum(axis=1)
    for stratum, ids in source_values.groupby(source_values).groups.items():
        ids = successor["scores"].index.intersection(ids)
        source_rows.append(
            {
                "source_resolution_stratum": stratum,
                "n_events": len(ids),
                "prospective_successors": int(ids.isin(target_ids).sum()),
                "mean_missing_cells": float(successor_missing.loc[ids].mean()),
                "median_missing_cells": float(successor_missing.loc[ids].median()),
                "factor_model_run": False,
                "reason": "Descriptive stratum; inconsistent inherited and prospective vocabularies are not treated as one ordinal scale.",
            }
        )

    canonical_imputed = successor["scores"].fillna(successor["scores"].median())
    imputation_matrices = {
        "global_median": canonical_imputed,
        "era_specific_median": LEGACY.era_median_imputation(successor["scores"], corpus["era_bucket_v2"]),
        "unknown_knn_structural_median": LEGACY.knn_unknown_imputation(successor["scores"], successor["na_types"]),
        "unknown_median_structural_zero_bound": LEGACY.structural_zero_imputation(successor["scores"], successor["na_types"]),
    }
    canonical_thresholds = horn_cache[len(successor["scores"])]
    imputation_rows: list[dict[str, Any]] = []
    for name, matrix in imputation_matrices.items():
        fit = LEGACY.fit_scores(successor["scores"], named_loadings, imputed=matrix)
        eigenvalues, _ = LEGACY.observed_eigenvalues(matrix.values)
        versus_canonical = [
            abs(LEGACY.tucker(canonical_fit["loadings"][factor], fit["loadings"][factor]))
            for factor in named_loadings.columns
        ]
        comparison = comparison_metrics(fit, successor["scores"], parent_reference)
        canonical_comparison = comparison_metrics(fit, successor["scores"], canonical_reference)
        factor_count = int(np.sum(eigenvalues > canonical_thresholds))
        imputation_rows.append(
            {
                "imputation": name,
                "parallel_analysis_factors": factor_count,
                "factor_8_margin": float(eigenvalues[7] - canonical_thresholds[7]),
                "factor_9_margin": float(eigenvalues[8] - canonical_thresholds[8]),
                "minimum_loading_tucker_vs_canonical_global_median": float(min(versus_canonical)),
                "minimum_loading_tucker_vs_corrected_parent": comparison["minimum_loading_tucker"],
                "minimum_shared_score_spearman_vs_corrected_parent": comparison["minimum_shared_score_spearman"],
                "aligned_k6_changed_share_vs_corrected_parent": comparison["aligned_k6_changed_share"],
                "material_flag_vs_corrected_parent": bool(
                    factor_count != parent_reference["parallel_analysis_factors"]
                    or comparison["minimum_loading_tucker"] < 0.85
                    or comparison["minimum_shared_score_spearman"] < 0.90
                    or comparison["aligned_k6_changed_share"] > 0.05
                ),
                "minimum_shared_score_spearman_vs_canonical_global_median": canonical_comparison["minimum_shared_score_spearman"],
                "aligned_k6_changed_share_vs_canonical_global_median": canonical_comparison["aligned_k6_changed_share"],
                "material_flag_vs_canonical_global_median": bool(
                    factor_count != canonical_reference["parallel_analysis_factors"]
                    or min(versus_canonical) < 0.85
                    or canonical_comparison["minimum_shared_score_spearman"] < 0.90
                    or canonical_comparison["aligned_k6_changed_share"] > 0.05
                ),
            }
        )

    canonical_labels = pd.Series(canonical_fit["labels"], index=successor["scores"].index)
    influence_rows: list[dict[str, Any]] = []

    def influence_metrics(subset: pd.DataFrame, fit: dict[str, Any]) -> dict[str, Any]:
        tucker = [
            abs(LEGACY.tucker(canonical_fit["loadings"][factor], fit["loadings"][factor]))
            for factor in canonical_fit["loadings"].columns
        ]
        rhos = [
            safe_rho(
                canonical_fit["factor_scores"].loc[subset.index, factor],
                fit["factor_scores"][factor],
            )
            for factor in canonical_fit["factor_scores"].columns
        ]
        prior_labels = canonical_labels.loc[subset.index].astype(int).to_numpy()
        aligned, _, _ = LEGACY.PIPELINE.align_cluster_labels(prior_labels, fit["labels"])
        changed_share = float(np.mean(prior_labels != aligned))
        return {
            "minimum_loading_tucker": float(min(tucker)),
            "minimum_shared_score_spearman": float(min(rhos)),
            "aligned_k6_changed_share": changed_share,
            "adjusted_rand": float(adjusted_rand_score(prior_labels, fit["labels"])),
            "silhouette_delta": float(fit["silhouette"] - canonical_fit["silhouette"]),
            "material_flag": bool(min(tucker) < 0.85 or min(rhos) < 0.90 or changed_share > 0.05),
        }

    full_medians = successor["scores"].median()
    for event_id in successor["scores"].index:
        subset = successor["scores"].drop(index=event_id)
        recomputed_fit = LEGACY.fit_scores(subset, canonical_fit["loadings"])
        frozen_fit = LEGACY.fit_scores(
            subset,
            canonical_fit["loadings"],
            imputed=canonical_imputed.drop(index=event_id),
        )
        recomputed = influence_metrics(subset, recomputed_fit)
        frozen = influence_metrics(subset, frozen_fit)
        subset_medians = subset.median()
        median_changes = int(
            np.sum(~np.isclose(subset_medians.to_numpy(), full_medians.to_numpy(), equal_nan=True))
        )
        influence_rows.append(
            {
                "event_id": event_id,
                "membership_origin": "prospective_successor" if event_id in target_ids else "v4_retained",
                "median_imputation_dimensions_changed_when_removed": median_changes,
                "recomputed_median_minimum_loading_tucker": recomputed["minimum_loading_tucker"],
                "recomputed_median_minimum_shared_score_spearman": recomputed["minimum_shared_score_spearman"],
                "recomputed_median_aligned_k6_changed_share": recomputed["aligned_k6_changed_share"],
                "recomputed_median_adjusted_rand": recomputed["adjusted_rand"],
                "recomputed_median_silhouette_delta": recomputed["silhouette_delta"],
                "recomputed_median_material_flag": recomputed["material_flag"],
                "frozen_median_minimum_loading_tucker": frozen["minimum_loading_tucker"],
                "frozen_median_minimum_shared_score_spearman": frozen["minimum_shared_score_spearman"],
                "frozen_median_aligned_k6_changed_share": frozen["aligned_k6_changed_share"],
                "frozen_median_adjusted_rand": frozen["adjusted_rand"],
                "frozen_median_silhouette_delta": frozen["silhouette_delta"],
                "frozen_median_material_flag": frozen["material_flag"],
            }
        )
    influence_rows.sort(
        key=lambda row: (
            not row["recomputed_median_material_flag"],
            not row["frozen_median_material_flag"],
            row["recomputed_median_minimum_loading_tucker"],
            row["event_id"],
        )
    )

    outputs = {
        CORE: render_csv(core_rows),
        FACTORS: render_csv(factor_rows),
        PROGRAMS: render_csv(program_rows),
        WEIGHTING: render_csv(weighting_rows),
        DOCUMENTATION: render_csv(documentation_rows),
        SOURCE_STRATA: render_csv(source_rows),
        IMPUTATION: render_csv(imputation_rows),
        INFLUENCE: render_csv(influence_rows),
        COVERAGE: render_csv(coverage_rows),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    for path, content in outputs.items():
        path.write_bytes(content)

    core_by_name = {row["scenario"]: row for row in core_rows}
    swap_rows = [row for row in program_rows if row["mode"] == "swap_successors_to_parents"]
    leave_rows = [row for row in program_rows if row["mode"] == "leave_program_out"]
    summary = {
        "schema": "event-unit-fairness-model-results-v1",
        "status": "diagnostic_complete_not_release_authorized",
        "baseline_release": "second_pass_v4_583",
        "candidate_counts": {
            "corrected_parent_reference": 580,
            "complete_parent_alternative": 589,
            "canonical_successor": 676,
            "grouped_program_medians": 588,
        },
        "boundary_arithmetic": {
            "current_active": 580,
            "source_release_active": 583,
            "source_resolved_scope_exclusions": 3,
            "active_parents_retired": 61,
            "successors_added": 157,
            "canonical_active": 676,
            "already_inactive_parent_references": 9,
            "connected_sensitivity_groups": 69,
        },
        "core_factor_counts": {
            row["scenario"]: row["parallel_analysis_factors"] for row in core_rows
        },
        "core_material_flags_vs_corrected_parent": {
            row["scenario"]: row["material_flag_vs_corrected_parent"] for row in core_rows
        },
        "core_material_flags_vs_canonical_successor": {
            row["scenario"]: row["material_flag_vs_canonical_successor"] for row in core_rows
        },
        "canonical_vs_corrected_parent": {
            field: core_by_name["canonical_successor_676"][field]
            for field in (
                "parallel_analysis_factors",
                "minimum_loading_tucker_vs_corrected_parent",
                "minimum_shared_score_spearman_vs_corrected_parent",
                "aligned_k6_changed_share_vs_corrected_parent",
                "adjusted_rand_vs_corrected_parent",
                "k6_silhouette",
                "material_flag_vs_corrected_parent",
            )
        },
        "program_sensitivity": {
            "swap_scenarios": len(swap_rows),
            "leave_program_out_scenarios": len(leave_rows),
            "swap_material_flags_vs_corrected_parent": sum(bool(row["material_flag_vs_corrected_parent"]) for row in swap_rows),
            "leave_program_out_material_flags_vs_corrected_parent": sum(bool(row["material_flag_vs_corrected_parent"]) for row in leave_rows),
            "swap_material_flags_vs_canonical_successor": sum(bool(row["material_flag_vs_canonical_successor"]) for row in swap_rows),
            "leave_program_out_material_flags_vs_canonical_successor": sum(bool(row["material_flag_vs_canonical_successor"]) for row in leave_rows),
        },
        "weighting_material_flags_vs_corrected_parent": {
            row["weighting"]: row["material_factor_or_loading_flag_vs_corrected_parent"]
            for row in weighting_rows
        },
        "weighting_material_flags_vs_canonical_unweighted": {
            row["weighting"]: row["material_factor_or_loading_flag_vs_canonical_unweighted"]
            for row in weighting_rows
        },
        "documentation_scenarios_run": sum(bool(row["factor_model_run"]) for row in documentation_rows),
        "imputation_material_flags_vs_corrected_parent": {
            row["imputation"]: row["material_flag_vs_corrected_parent"] for row in imputation_rows
        },
        "imputation_material_flags_vs_canonical_global_median": {
            row["imputation"]: row["material_flag_vs_canonical_global_median"] for row in imputation_rows
        },
        "leave_one_event_out": {
            "events_tested": len(influence_rows),
            "recomputed_median_material_flags": sum(
                bool(row["recomputed_median_material_flag"]) for row in influence_rows
            ),
            "frozen_median_material_flags": sum(
                bool(row["frozen_median_material_flag"]) for row in influence_rows
            ),
            "events_changing_at_least_one_imputation_median": sum(
                int(row["median_imputation_dimensions_changed_when_removed"]) > 0
                for row in influence_rows
            ),
            "interpretation": (
                "Recomputed-median influence includes preprocessing discontinuity; "
                "frozen-median influence isolates row leverage under the canonical imputation map."
            ),
        },
        "date_proxy_handling": {
            "proxy_event_count": len(proxy_ids),
            "rule": "Proxies are excluded from observed-duration calculations and receive neutral weight one; a separate scenario drops all 39.",
        },
        "raw_vocabulary_warnings": {
            "region_distinct_strings": int(corpus["region"].nunique()),
            "mechanism_distinct_strings": int(corpus["mechanism"].nunique()),
            "mechanism_singleton_strings": int((corpus["mechanism"].value_counts() == 1).sum()),
            "interpretation": "Raw-region and raw-mechanism weights are stress tests, not publishable normalized-stratum estimates.",
        },
        "deferred_but_recorded": {
            "normalized_mechanism_vs_primary_family_analysis": True,
            "successor_primary_family_editorial_review": True,
            "normalized_geographic_scale_population_scale_land_outcome_causal_sequence_strata": True,
            "reason": "The score models can run without inventing categorical metadata; the listed editorial/normalization tasks remain explicit publication gates.",
        },
        "materiality_rules": {
            "factor_count_differs_from_reference": True,
            "minimum_loading_tucker_below": 0.85,
            "minimum_shared_score_spearman_below": 0.90,
            "aligned_cluster_change_share_above": 0.05,
            "interpretation": "A flag requires explanation and never retroactively decides historical inclusion.",
        },
        "procedural_boundary_fairness_conclusion_authorized": False,
        "measurement_robustness_conclusion_authorized": False,
        "coverage_completeness_claim_authorized": False,
        "candidate_activation_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    SUMMARY.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    input_paths = [
        Path(__file__).resolve(),
        LEGACY_PATH,
        GROUPS,
        MEMBERSHIP,
        DISPOSITIONS,
        BOUNDARY,
        V4 / "results" / "loadings_aligned.csv",
        V4 / "results" / "factor_scores_aligned.csv",
        V4 / "results" / "clean_k6_assignments.csv",
        *[
            root / "data" / filename
            for root in (V4, PARENT, SUCCESSOR, PRIOR_FULL, PRIOR_SUCCESSOR)
            for filename in ("corpus_v2.json", "scores_v2.csv", "na_types_v2.csv")
        ],
        *sorted(PACKETS.glob("prospective_score_packet_*.json")),
    ]
    output_paths = [*outputs, SUMMARY]
    manifest = {
        "schema": "event-unit-fairness-model-results-manifest-v1",
        "status": "reproducible_diagnostic_not_active",
        "randomness": {
            "horn_seed_base": SEED,
            "horn_draws": LEGACY.N_HORN,
            "kmeans_random_state": 0,
            "kmeans_n_init": 100,
        },
        "input_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in input_paths},
        "output_sha256": {path.name: sha256(path) for path in output_paths},
        "candidate_activation_authorized": False,
        "fairness_conclusion_authorized": False,
        "release_authorized": False,
        "atlas_change_authorized": False,
        "deployment_authorized": False,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def output_paths() -> list[Path]:
    return [
        CORE,
        FACTORS,
        PROGRAMS,
        WEIGHTING,
        DOCUMENTATION,
        SOURCE_STRATA,
        IMPUTATION,
        INFLUENCE,
        COVERAGE,
        SUMMARY,
        MANIFEST,
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    before = {path: path.read_bytes() for path in output_paths() if path.exists()}
    summary = build()
    if args.check:
        missing = [path for path in output_paths() if path not in before]
        changed = [path for path, content in before.items() if path.read_bytes() != content]
        if missing or changed:
            raise SystemExit(f"event-unit model rerun differs: missing={missing}; changed={changed}")
        print("event_unit_fairness_models_reproduce")
        return
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
