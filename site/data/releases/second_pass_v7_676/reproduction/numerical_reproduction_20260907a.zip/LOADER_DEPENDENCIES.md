# Direct executable-loader closure

This is implementation inspection, not an additional scientific audit. Bound
files remain unchanged. The export includes all hash-bound files even when they
are hash-only provenance; it does not recursively include their historical inputs.

| Loader | Executable dependencies / behavior |
| --- | --- |
| portable_preflight.py | Standard-library manifest/path/hash checks first; then only numerics, inputs and run_successor from the exported model_execution_v1 directory. Generated `.git` file supplies the nearest ancestor root. |
| numerics.py | NumPy, pandas, factor_analyzer, SciPy, scikit-learn; dependencies.json and all16 bound paths are hash-checked. ROOT and SECOND are based on the isolated marker. |
| inputs.py | NumPy/pandas plus numerics. Reader resolves the accepted project-relative paths; load_contract consumes acceptance, three datasets, scope, final coding authorities, program authorities and frozen reference loadings. Program preflight consumes the remaining bound date/weight files, yielding exactly63 unique inputs. |
| run_successor.py | inputs, numerics, resume_cache, NumPy/pandas, SciPy, scikit-learn and threadpoolctl. Import defines functions/classes only; main() is guarded. Its six-adapter glob is hash inventory, not a private-tree copy. No ordinary Engine or ResumeCache instance is created by the fingerprint launcher. |
| resume_cache.py | Standard library (including POSIX fcntl), NumPy/pandas. Import only defines code; no cache/lock/path is opened until its writer is explicitly instantiated. Thus native Windows is not established as supported. |
| indicator_overlap.py | Loaded by numerics.helpers through importlib; inspected top level consists of imports/constants/functions and a guarded CLI. Reads the unchanged instrument through battery_columns. Its numerical run/fit/null functions are disabled during matrix-only checks. |

## Selected legacy functions, not legacy module initializers

numerics.functions parses these original sources and compiles only the named,
undecorated FunctionDef nodes. The main module bodies, directory creation,
historical row constructors, editorial JSON reads and CLI entry points do not run.
The selected function bodies and their supplied global namespaces were inspected:

- 12_run_second_pass.py: loading_congruence, align_factors,
  align_cluster_labels, partial_spearman.
- v5/run_hellenistic_sensitivities.py: weighted_correlation,
  observed_eigenvalues, horn_thresholds, fit_scores, era_median_imputation,
  knn_unknown_imputation, structural_zero_imputation.
- event_unit_fairness_v1/analyze_event_unit_subspace_stability_v2.py:
  fit_loadings, weighted_correlation, era_imputation, knn_imputation,
  structural_zero_imputation.
- event_unit_fairness_v1/run_event_unit_fairness_models_v2.py:
  reciprocal_group_weights.

These function bodies use arguments and the supplied numerical namespace; they
do not open additional historical files. Only imputation/group-weight helpers
are called by the fingerprint check. Factor/null/cluster operations are guarded
against execution. Other bound historical executables, validators, preparation
scripts and both bound synthetic tests are included solely for hash closure;
their top-level code/CLI is not imported or executed by the launcher.

## Portability boundary

Copied historical manifest/metadata fields retain absolute host paths and nested
private evidence locators as original provenance. Those strings are not executable
loader dependencies and are not rewritten or recursively shipped. The isolated
test forbids fallback reads from the original project (apart from the explicitly
used numerical Python environment, if that environment itself resides there).
The standard library and installed numerical packages remain external software
dependencies, not copied research inputs. The original six package versions and
one-thread settings are checked. The source map and isolated preflight, not an
invented complete historical archive, define this export's closure.
