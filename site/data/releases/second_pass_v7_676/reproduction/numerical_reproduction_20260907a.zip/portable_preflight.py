#!/usr/bin/env python3
"""Export-root launcher: input preflight or all matrix fingerprints; never fit.

No third-party or project imports occur until the exported allowlist, marker and
hashes pass. Bound files are not edited. Output is JSON on stdout only.
"""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys

BASE = 'analysis/second_pass/v6/post_v6_correction_application_v1'
EXECUTION = BASE + '/model_execution_v1'
MANIFEST = EXECUTION + '/run_20260907a/MANIFEST.json'
MARKER = b'Portable numerical export root marker; NOT Git history or a usable Git repository.\n'

def require(ok, why):
    if not ok: raise ValueError(why)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(obj): return (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode()
def ids_sha(ids): return sha(json.dumps(ids,separators=(',',':')).encode())

def compact(row):
    fit=row['result']
    item={'scenario':row['scenario'],'category':row['category'],
          'authority_ids_sha256':ids_sha(row.get('authority_ids',[])),
          **{k:fit[k] for k in ('matrix_sha256','preprocessing','seed','events','indicators')},
          'event_ids_sha256':ids_sha(fit['event_ids'])}
    if 'date_diagnostics' in row:
        item['date_rosters_sha256']={k:ids_sha(row['date_diagnostics'][k]) for k in
                                   ('eligible_event_ids','excluded_event_ids','unknown_duration_ids')}
    return item

def safe_path(name):
    p=Path(name)
    require(isinstance(name,str) and name and '\\' not in name and not p.is_absolute()
            and all(x not in ('..','.') for x in p.parts) and str(p)==name,'Unsafe project-relative path')
    return p

def validate_export(root):
    require((root/'.git').is_file() and not (root/'.git').is_symlink() and
            (root/'.git').read_bytes()==MARKER,'Use a freshly extracted export root with its synthetic marker')
    manifest=json.loads((root/'EXPORT_MANIFEST.json').read_bytes())
    for name,expected in manifest['members_sha256'].items():
        p=root/safe_path(name)
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root), 'Missing/unsafe export member: '+name)
        require(sha(p.read_bytes())==expected,'Export member hash mismatch: '+name)
    source_map=json.loads((root/'SOURCE_MAP.json').read_bytes())
    for row in source_map['sources']:
        p=root/safe_path(row['path'])
        require(sha(p.read_bytes())==row['sha256'],'Source hash mismatch: '+row['path'])
    return source_map,manifest

def readonly_guard(root, forbidden):
    """Block project fallbacks, network, file mutation, subprocess and legacy writes."""
    runtime=Path(sys.prefix).resolve()
    require(runtime!=forbidden,'Do not treat the original project itself as a runtime prefix')
    blocked={'os.mkdir','os.remove','os.rmdir','os.rename','os.symlink','os.link',
             'os.chmod','os.chown','os.truncate','os.utime','subprocess.Popen','os.system'}
    def audit(event,args):
        if event in blocked or event.startswith('socket.'):
            raise RuntimeError('Preflight forbids side effect: '+event)
        if event=='open':
            name,mode,flags=args
            if (isinstance(mode,str) and any(x in mode for x in 'wax+')) or \
               (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):
                raise RuntimeError('Preflight forbids file writes')
            if isinstance(name,(str,bytes)):
                path=Path(os.fsdecode(name)).absolute()
                # The isolated root can be inside the original project during tests;
                # only exported descendants of that root may be read there.
                if forbidden and path.is_relative_to(forbidden) and not path.is_relative_to(root) and not path.is_relative_to(runtime):
                    raise RuntimeError('Forbidden original-project fallback: '+str(path))
    sys.addaudithook(audit)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight-only',action='store_true')
    parser.add_argument('--forbid-root',type=Path,help='Test-only original project root: forbid fallback reads')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    source_map,export_manifest=validate_export(root)
    sys.dont_write_bytecode=True
    # CPython3.9 may query uname through a subprocess/devnull. Warm that
    # read-only platform metadata cache before installing the strict guard.
    # No historical/project module is imported and no file is created here.
    platform.platform()
    readonly_guard(root,args.forbid_root.resolve() if args.forbid_root else None)
    sys.path.insert(0,str(root/EXECUTION))
    import numerics
    import inputs
    import run_successor as runner
    require(numerics.ROOT==inputs.ROOT==root,'Bound loader selected the wrong root')
    original=json.loads((root/MANIFEST).read_bytes())
    for package,version in original['runtime']['packages'].items():
        require(importlib.metadata.version(package)==version,'Install the supplied pinned runtime: '+package)
    # Helpers compile only the preselected original FunctionDef nodes. They never
    # import historical modules with corpus reads or output-directory initializers.
    h=numerics.helpers()
    columns,_=h.overlap.battery_columns()
    path=root/BASE/'complete_candidate_v1/complete/ACCEPTANCE.json'
    loaded=inputs.load_contract(path,source_map['acceptance_sha256'],columns)
    acceptance,datasets,scope,programs,reference,arithmetic,reader=loaded
    for instruction in programs['instructions']:
        alternative=runner.program_dataset(instruction,datasets,reader,columns)
        if instruction['kind']=='weighting':runner.program_weights(instruction,alternative,reader)
    actual={str(Path(p).relative_to(root)):v for p,v in reader.bindings.items()}
    expected={row['path']:row['sha256'] for row in source_map['sources'] if 'run_input' in row['roles']}
    require(actual==expected and len(actual)==63,'Exact consumed63 input closure differs')
    # Exercise the original run binding/glob path: exactly the six adapters are
    # shipped, but no tests or historical executables are imported as entry points.
    bindings=runner.run_bindings(reader)
    for key in ('adapter_sha256','numerical_dependencies_sha256','randomness'):
        require(bindings[key]==original[key],'Portable code/null policy differs: '+key)
    require(bindings['threads']['environment']==original['threads']['environment'],
            'Use the documented one-thread environment and PYTHONHASHSEED=0')
    report={'status':'PORTABLE_PREFLIGHT_PASS','owner':'implementation owner, not independent verifier',
            'source_members':len(source_map['sources']),'input_bindings':len(actual),
            'program_instructions':len(programs['instructions']),'arithmetic':arithmetic,
            'factor_fits':0,'Horn_simulations':0,'cluster_fits':0,
            'root_selected_correctly':True,'original_project_fallback_forbidden':bool(args.forbid_root),
            'fallback_guard_exception':'Installed numerical Python prefix only; no research inputs from original project',
            'network_and_file_writes_forbidden':True,'runtime_packages':bindings['runtime']['packages'],
            'original_results_sha256':original['output_sha256']['RESULTS.json']}
    if not args.preflight_only:
        def forbidden(*a,**kw): raise RuntimeError('Estimator/simulation forbidden by fingerprint launcher')
        # Direct estimator/simulation guards backstop the no-fit engine below.
        numerics.FactorAnalyzer.fit=forbidden
        numerics.KMeans.fit=forbidden
        numerics.KMeans.fit_predict=forbidden
        h.legacy.observed_eigenvalues=forbidden
        h.legacy.horn_thresholds=forbidden
        h.legacy.fit_scores=forbidden
        h.subspace.fit_loadings=forbidden
        h.overlap.fit=forbidden
        h.overlap.horn_thresholds=forbidden
        h.overlap.run=lambda scores:{'status':'not_fitted_in_portable_fingerprint_check'}
        class FingerprintEngine:
            def __init__(self,h,reference,cache=None):self.fits,self.nulls={},{}
            def fit(self,matrix,*,weights=None,seed_offset=0,preprocessing='global_median',checkpoint_label='fit'):
                seed=numerics.SEED+len(matrix) if weights is None else numerics.SEED+1000+seed_offset
                key=(runner.frame_key(matrix,weights),preprocessing,seed)
                if key not in self.fits:
                    self.fits[key]={'matrix_sha256':key[0],'preprocessing':preprocessing,'seed':seed,
                                   'events':len(matrix),'event_ids':list(matrix.index),
                                   'indicators':len(matrix.columns),'fits':{},'status':'fingerprint_only_not_fit'}
                return self.fits[key]
            def compare(self,reference,candidate):return {}
        # In-memory adapter only; bound source files and historical methods stay
        # byte-identical. The real run_suite selects/weights/imputes every matrix.
        runner.Engine=FingerprintEngine
        result=runner.run_suite(datasets,scope,programs,reference,reader,h)
        fingerprints=[compact(r) for r in result['scenarios']]
        expected_fp=json.loads((root/'EXPECTED_FINGERPRINTS.json').read_bytes())
        require(fingerprints==expected_fp['scenarios'],'At least one of565 matrix/roster/authority/date fingerprints differs')
        require(result['unique_preprocessed_matrix_cases']==expected_fp['unique_matrix_cases']==536,
                'Unique matrix case count differs')
        require(result['explicit_limits_and_editorial_only']==expected_fp['explicit_limits_and_editorial_only'],
                'Explicit unestimable/editorial limits differ')
        report.update(status='PORTABLE_565_FINGERPRINTS_PASS',scenario_records=len(fingerprints),
                      unique_matrix_cases=536,fingerprints_sha256=sha(encode(fingerprints)),
                      closed_verification_receipt_sha256=expected_fp['closed_verification_receipt_sha256'],
                      KNN_imputation='Executed as prescribed preprocessing, not a factor/cluster fit',
                      indicator_overlap_fits='Not run; bound code is included')
    reader.unchanged()
    validate_export(root)
    print(json.dumps(report,indent=2,allow_nan=False))

if __name__=='__main__':main()
