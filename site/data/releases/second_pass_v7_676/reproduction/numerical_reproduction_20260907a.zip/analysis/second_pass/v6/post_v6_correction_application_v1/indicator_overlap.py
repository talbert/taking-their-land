#!/usr/bin/env python3
"""Prespecified five-battery omission sensitivity; no CLI fit or output writer.

The completed successor driver calls run(scores). No event selection, score
editing, family assignment or publication happens here. Numerical methods match
the existing run_model_comparison.py and run_hellenistic_sensitivities.py; the
new comparison restricts reference loadings to exactly the retained indicators.
SciPy's principal-angle definition: https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.subspace_angles.html
Run --self-test for synthetic contract checks only.
"""
import argparse
import hashlib
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.linalg import subspace_angles
from scipy.optimize import linear_sum_assignment

HERE = Path(__file__).resolve().parent
INSTRUMENT = HERE / 'CODING_INSTRUMENT.json'
INSTRUMENT_SHA = '64c6b25776366eef770f9cd1191b4b9d87ad139a36e295dd83596909dfc14c0d'
SEED = 28082026
DRAWS = 500
BATTERIES = ('settler-colonial-studies', 'political-economy-land-labor',
             'historical-demography', 'genocide-forced-migration', 'state-sovereignty-ideology')


def battery_columns():
    raw = INSTRUMENT.read_bytes()
    if hashlib.sha256(raw).hexdigest() != INSTRUMENT_SHA:
        raise ValueError('Unreconciled instrument drift')
    dims = json.loads(raw)['codebook']['dimensions']
    groups = {name: [d['id'] for d in dims if d['discipline'] == name] for name in BATTERIES}
    if len(dims) != 60 or any(len(ids) != 12 for ids in groups.values()):
        raise ValueError('Expected five unchanged twelve-indicator batteries')
    return [d['id'] for d in dims], groups


def horn_thresholds(n, p, cache, *, draws=DRAWS):
    seed = SEED + n
    key = (n, p, seed, draws)
    if key not in cache:
        rng = np.random.default_rng(seed)
        sims = np.empty((draws, p))
        for i in range(draws):
            corr = np.corrcoef(rng.normal(size=(n, p)), rowvar=False)
            sims[i] = np.sort(np.linalg.eigvalsh(corr))[::-1]
        cache[key] = np.percentile(sims, 95, axis=0)
    return cache[key]


def fit(matrix, factors):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        model = FactorAnalyzer(n_factors=factors, rotation='oblimin', method='minres')
        model.fit(matrix.values)
    return pd.DataFrame(model.loadings_, index=matrix.columns), [str(w.message) for w in caught]


def compare(reference, candidate):
    if not reference.index.equals(candidate.index) or reference.shape != candidate.shape:
        raise ValueError('Reference and candidate need identical ordered indicators and factor count')
    a, b = reference.to_numpy(), candidate.to_numpy()
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Nonfinite loading matrix')
    ranks = {'reference_rank': int(np.linalg.matrix_rank(a)), 'candidate_rank': int(np.linalg.matrix_rank(b))}
    if min(ranks.values()) != a.shape[1]:
        return {'status': 'rank_loss_not_a_stability_result', **ranks}
    angles = np.degrees(subspace_angles(a, b))
    congruence = (a.T @ b) / np.sqrt(np.outer((a * a).sum(0), (b * b).sum(0)))
    rows, cols = linear_sum_assignment(-np.abs(congruence))
    aligned = np.abs(congruence[rows, cols])
    return {'status': 'compared', **ranks,
            'principal_angles_degrees': angles.tolist(),
            'maximum_principal_angle_degrees': float(max(angles)),
            'minimum_aligned_axis_tucker': float(min(aligned)),
            'mean_aligned_axis_tucker': float(np.mean(aligned))}


def run(scores):
    columns, groups = battery_columns()
    if list(scores.columns) != columns or not scores.index.is_unique:
        raise ValueError('Expected exact sixty-column order and unique event IDs')
    if len(scores) <= 60:
        raise ValueError('Full reference needs more observations than columns')
    observed = scores.to_numpy(dtype=float)
    if np.isinf(observed).any() or np.any((observed[np.isfinite(observed)] < 0) | (observed[np.isfinite(observed)] > 4)):
        raise ValueError('Input must use 0–4 observations and actual missing values, not -1/-2')
    # U/NA remain in the authoritative raw data. This is the existing ordinary
    # global-median analytical treatment, frozen before omitting any columns.
    matrix = scores.fillna(scores.median())
    empty = matrix.columns[matrix.isna().any()].tolist()
    constant = matrix.columns[matrix.nunique() < 2].tolist()
    if empty or constant:
        return {'status': 'inestimable_reference', 'all_missing_columns': empty,
                'constant_columns': constant, 'scenarios': []}
    references, reference_warnings = {}, {}
    for k in (8, 9):
        try:
            references[k], reference_warnings[k] = fit(matrix, k)
        except Exception as exc:
            reference_warnings[k] = ['FIT_ERROR: ' + type(exc).__name__ + ': ' + str(exc)]
    cache, results = {}, []
    for omitted in (None,) + BATTERIES:
        keep = [c for c in columns if omitted is None or c not in groups[omitted]]
        subset = matrix.loc[:, keep]
        eigenvalues = np.sort(np.linalg.eigvalsh(np.corrcoef(subset.values, rowvar=False)))[::-1]
        thresholds = horn_thresholds(len(subset), len(keep), cache)
        margins = eigenvalues - thresholds
        result = {'omitted_battery': omitted, 'events': len(subset), 'indicators': len(keep),
                  'kept_dimension_ids': keep, 'horn_factors': int(np.sum(margins > 0)),
                  'horn_margins': margins.tolist(), 'fits': {}}
        for k in (8, 9):
            if k not in references:
                result['fits'][str(k)] = {'status': 'reference_fit_failed', 'warnings': reference_warnings[k]}
                continue
            try:
                if omitted is None:
                    candidate, notes = references[k], reference_warnings[k]
                else:
                    candidate, notes = fit(subset, k)
                result['fits'][str(k)] = {
                    **compare(references[k].loc[keep], candidate),
                    'reference_warnings': reference_warnings[k], 'candidate_warnings': notes,
                }
            except Exception as exc:
                result['fits'][str(k)] = {'status': 'scenario_fit_failed', 'error': type(exc).__name__ + ': ' + str(exc)}
        results.append(result)
    return {'status': 'computed_diagnostic_not_a_fairness_verdict',
            'instrument_sha256': INSTRUMENT_SHA, 'seed_base': SEED,
            'horn_draws': DRAWS, 'horn_percentile': 95,
            'imputation': 'full_dataset_global_medians_frozen_within_omission_comparison',
            'event_weights': 'unchanged_equal_event', 'scenarios': results}


def self_test():
    columns, groups = battery_columns()
    assert len(set(c for ids in groups.values() for c in ids)) == 60
    for ids in groups.values():
        assert len([c for c in columns if c not in ids]) == 48
    rng = np.random.default_rng(7301)
    a = pd.DataFrame(rng.normal(size=(48, 8)), index=columns[12:])
    assert compare(a, a)['maximum_principal_angle_degrees'] < 1e-5
    rotated = a @ rng.normal(size=(8, 8))
    assert compare(a, rotated)['maximum_principal_angle_degrees'] < 1e-5
    try:
        compare(a, a.iloc[::-1])
    except ValueError:
        pass
    else:
        raise AssertionError('Mismatched indicator order accepted')
    lowrank = a.copy()
    lowrank[7] = lowrank[6]
    assert compare(a, lowrank)['status'] == 'rank_loss_not_a_stability_result'
    cache = {}
    horn_thresholds(80, 60, cache, draws=2)
    horn_thresholds(80, 48, cache, draws=2)
    assert len(cache) == 2
    horn_thresholds(80, 48, cache, draws=2)
    assert len(cache) == 2
    print('PASS: battery membership, 48-column restriction, self/rotation identity, order rejection, rank-loss disclosure and dimension-aware null cache; synthetic tests only')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true', required=True)
    parser.parse_args()
    self_test()
