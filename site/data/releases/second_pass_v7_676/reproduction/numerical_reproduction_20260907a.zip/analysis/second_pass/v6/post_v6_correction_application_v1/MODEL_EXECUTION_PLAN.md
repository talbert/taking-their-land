# Successor fit: execution boundary

Prepared 2026-09-05 before corrected scores exist. This is an implementation
plan, not a result or an additional research/audit gate.

## Inputs and one fit cycle

Keep `second_pass_v6_675` byte-stable. The roster-only checkpoint is explicitly
ineligible for fitting. Build the successor only from the closed retirement
decisions, accepted metadata patches, qualified new units, and source-bound
adjudicated raw cells. Keep every held candidate inactive, preserve both kinds
of missingness, and report actual changes rather than treating all reviewed
cells as changed. The independent changed-burden check also verifies unchanged
rows and that each active parent/child relationship has a non-overlap ruling.

The validated post-v5 comparison implementation and event-unit fairness
implementations supply the existing numerical methods. Adapt their input paths,
roster assertions, touched-ID sets and output labels to this successor; do not
run their hard-coded v5/675 scenarios and rename the results. Bind the code,
software versions, seeds and input hashes. Repeated scenarios with identical
matrices and preprocessing may share one computed result with all authority
references retained.

## Required comparisons

1. Recompute frozen v6 as the comparison baseline. Separate retirement,
   retained-row correction, and qualified-successor effects before reporting
   their combined result. Archived parent scores in a counterfactual are
   historical analytical inputs, not reinstated evidence or copied child scores.
2. Run parallel analysis with the established simulation settings; report the
   retention margins and compare both eight- and nine-dimensional subspaces.
   Preserve axis congruence separately from whole-space rotation. The current
   eight public traits and six editorial families are not a required factor count.
3. Repeat the established equal-era, equal-region, missingness-subset and
   imputation checks. Include frozen versus recomputed medians. Any illustrative
   structural-NA zero bound is a sensitivity only, never a recode. Report sparse
   subset failures rather than quietly substituting a different model.
4. Recalculate the accepted event/program omission and boundary comparisons on
   corrected inputs. The exact authorities are `batch_wide_actions` in the
   source-locked cutoff inventory and the event-specific instructions, including
   Assyrian calibration, the Roman parent/child controls, B47–49 alternatives,
   and B50's Egypt and Kitakami bounds. Deduplicate repeated instructions, not
   distinct historical units. A date-only alternative need not rerun an identical
   unweighted matrix: check its actual effect on era/dating analyses and record
   numerical identity when it changes neither rows, cells nor weights.
5. Keep source-supported family alternatives as editorial comparisons. Changing
   an editorial label without changing input scores does not constitute a new
   factor solution. Do not invent numerical phase/region pseudo-scores merely
   because a requested alternative lacks independent coding; state that limit.
   Illustrative upper-bound weighting remains outside the historical corpus.

Previously published angles, correlations and label-change rates describe their
old inputs. None is a result of this unbuilt successor. A small model effect does
not authenticate a historical boundary; a large one calls for disclosed
interpretation, not choosing the boundary that makes the model look stable.

## Indicator-overlap check

The bounded search of the saved factor/sensitivity implementations found
event/program omission, weighting, missingness and imputation tests, but no
implemented indicator- or disciplinary-battery omission test. The original
codebook builder deliberately preserves cross-disciplinary overlap. Equal
event/era weights do not answer that variable-side question.

The compact addition is specified here **before any corrected-data fit**:

- Use five leave-one-disciplinary-battery-out scenarios. The unchanged codebook
  has twelve indicators in each of settler-colonial studies, political economy,
  historical demography, genocide/forced migration, and state/sovereignty. Omit
  each complete named battery once; do not select correlated pairs after seeing
  results or rename a battery to improve the result.
- Run this on frozen v6 and the completed corrected successor, separately, with
  identical rows and the full dataset's ordinary global-median imputation held
  fixed within each comparison. Only the twelve columns change. Source codes,
  structural N/A and unknown remain preserved in the underlying inputs. This
  adds no row weights, pseudo-events or alternative missingness rule.
- Compare the full sixty-indicator solution with each forty-eight-indicator
  refit at both forced eight and forced nine factors, using existing minres /
  oblimin settings. Restrict the reference loading matrix to the **same forty-
  eight named rows** before computing principal angles and separately matched
  Tucker congruence. Record rank loss, fit warnings and inestimable scenarios;
  do not compare unlike-dimensional matrices or turn a rank loss into stability.
- Recompute Horn thresholds for the actual column count: five hundred Gaussian
  draws, the existing 95th percentile and seed convention. A cache must include
  sample size, column count, seed and draw count. The old sixty-column threshold
  cannot be reused for forty-eight columns just because the number of events is
  unchanged. Equivalent forty-eight-column null distributions may share a cache.
- Report continuous subspace/axis changes, all eigenvalue-minus-threshold
  margins, and retained-factor counts. No new universal pass/fail cutoff is
  declared for removing one fifth of the instrument. A factor-count decline may
  reflect omitted information; it is not itself failed historical measurement.

This tests dependence on a disciplinary battery, **not proof that remaining
indicators are independent or that any similar pair is redundant**. Stability
cannot authenticate an event boundary; instability cannot choose which discipline
to discard. No item removal, recoding, family reassignment or revised public trait
count follows automatically. This is one compact variable-side sensitivity,
not an open-ended measurement-invariance program. Implementation lives in
`indicator_overlap.py`; its self-tests use synthetic matrices, not historical
results. The existing row/era/region and imputation checks remain separate.

## Closure

One independent verification of the changed burden and reproducibility,
followed by main adjudication, is the closing assurance step. Report unresolved
limitations and the exact release cutoff. Update the monograph's event-unit
fairness and measurement sections with actual results, including historical
tempo, source resolution, observation endpoints and indicator overlap; leave
no provisional scaffold labelled as a completed fairness finding. Synchronize
the public data/trait release labels when the successor is promoted. Batch 51
ordinary authoring follows that correction cycle.
