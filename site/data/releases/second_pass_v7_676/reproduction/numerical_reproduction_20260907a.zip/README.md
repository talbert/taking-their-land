# Portable numerical reproduction inputs — run20260907a

This is a mechanical reproduction export for the completed numerical run, not
a new historical/scientific review, publication authorization or public deposit.
Its implementation owner is the model that assembled it, not an independent
verifier of this artifact. The previously closed independent verification is
unchanged. Original project attribution: Craig Talbert, *Taking their land*,2026.

## Contents and limits

SOURCE_MAP.json is the explicit source allowlist: the run's63 input bindings,
16 numerical dependency bindings, six adapter bindings (deduplicated), the
direct dependency manifest, run manifest and existing license notices. Exact
consumed bytes and project-relative paths are preserved. No bound code was
edited. EXPORT_MANIFEST.json hashes every other ZIP member.

No PDFs, captures, private/tmp files, secrets, raw coder journals, queues, caches,
Git configuration/history or runtime binaries are shipped. Consumed adjudicated
final coding outputs are included as research provenance. Do not recursively
fetch paths found inside their metadata. Those paths can locate private,
unshipped evidence; they do not mean the historical research has been reproduced.

The full139MB RESULTS.json is not duplicated here. EXPECTED_FINGERPRINTS.json
contains compact matrix/roster/date/authority expectations for all565 scenario
records, bound to the exact completed RESULTS and the closed verification's
receipt. It is not a substitute for numerical results/loadings. The original
run manifest retains its original absolute paths as provenance; the launcher
uses exported project-relative paths and checks actual consumed hash closure.

## Mixed licenses — quotations are excepted

Read LICENSE.md, THIRD_PARTY_NOTICES.md and LICENSES/. Original software is MIT;
original structured research fields are CC BY4.0; original narrative/editorial
prose is CC BY-SA4.0. Mixed JSON/CSV/Markdown files can contain these components
and third-party quotations. Those quotations/translations retain their original
rights and are **not automatically CC-licensed**. Citation metadata is not a
license for its referenced work. This private export makes no additional rights
grant or assertion that every embedded quotation is redistributable. No archive
DOI, public deposit or blanket all-content license is claimed.

## Isolated setup

Extract into a new, empty directory, not an existing checkout. Restrict that
directory to the owner (0700); members and the ZIP are0600. The `.git` member is
a short, generated plain-text **root marker**, not a Git repository. Its sole
purpose is satisfying the unchanged numerics loader's ancestor-root detection.
Do not replace a real `.git` file/directory. Nothing from the project's Git
database or configuration was copied.

Install the six exact versions in requirements-reproduction.txt into a separate
environment of your choice. Runtime binaries are not included. The original
run used CPython3.9.6 on macOS arm64; the archive records those runtime details.
The six direct packages are pinned, but all transitive wheels, BLAS libraries,
operating-system libraries and their build chains are not vendored/fully locked.
Exact fit-bit portability to a different environment is not promised.

From the extracted root, with that Python environment:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 BLIS_NUM_THREADS=1 PYTHONHASHSEED=0 python -B portable_preflight.py
```

Leave OMP_DYNAMIC and MKL_DYNAMIC unset, as in the original run. Add
`--preflight-only` for hash closure, accepted input loading and all255 program
preflights without matrix reconstruction. The default additionally exercises
the unchanged runner's scenario selection/weighting/imputation wiring for all
565 matrix fingerprints (536 unique cases). It uses an in-memory fingerprint
engine, blocks factor estimators/Horn simulations/clustering, and never creates
results or cache files. Prescribed KNN imputation is preprocessing, not a factor
or cluster fit. Network calls and file writes are blocked; reports go to stdout.
The standard library's read-only platform probe is initialized before that
guard (CPython3.9 may call uname through a subprocess). No project/historical
module is imported and no file is created by that initialization.

The root launcher must live at the extracted root. Its imports are limited to
the audited loader chain described in LOADER_DEPENDENCIES.md. Never execute old
historical scripts or tests merely because their hash-bound bytes are included.

## Later numerical execution is a separate action

The original run_successor.py, helpers and inputs are present unchanged. This
export's default launcher deliberately does **not** execute their fits. A later,
explicitly authorized reproduction could invoke that original runner against
the exported ACCEPTANCE.json and a fresh output directory, after confirming the
recorded runtime. Such a run would have new root/runtime manifest fields and
cannot reuse the original private cache. No such numerical rerun was performed
to assemble/test this export. Numerical reproduction does not activate corpus
rows, validate historical qualifications, choose editorial families or promote
a public release.

Original RESULTS SHA256:
`91cd3d38aaf3bae80a4d7972c935d020bd48c56e4e78d0cada34104ecd5008f9`

Original run MANIFEST SHA256:
`e04666c721603cc5111d0421331be9855254c314364000dbc2fed37037d35100`
