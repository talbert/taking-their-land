#!/usr/bin/env python3
"""Build a clean, versioned corpus and matrix for the statistical second pass.

The completed first-pass artifacts remain untouched. This script repairs dates,
reconciles duplicate coding submissions, makes two missing-cell decisions
explicit, and optionally folds in reviewed older-era additions from the
versioned addition files declared below.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


BASE = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
OUT = HERE / "data"
ADDITION_FILES = [
    HERE / "ancient_additions.json",
    HERE / "achaemenid_additions.json",
    HERE / "achaemenid_sidon_addition.json",
    HERE / "sasanian_shapur_additions.json",
    HERE / "new_kingdom_egypt_additions.json",
    HERE / "mongol_additions.json",
    HERE / "mongol_followup_additions.json",
    HERE / "neo_assyrian_additions.json",
    HERE / "early_neo_assyrian_additions.json",
]
SUPERSESSION_FILE = HERE / "neo_assyrian_supersessions.json"

STRUCTURAL_ADJUDICATIONS = {
    ("af-transatlantic-slave-removal-senegambia-upper-guinea",
     "pel_production_regime_conversion"): -2,
    ("af-transatlantic-slave-removal-senegambia-upper-guinea",
     "pel_unfree_incomer_share"): -2,
    ("europe-norse-settlement-faroes",
     "ssi_displaced_polity_stateness"): -1,
}

MISSING_CELL_REPAIRS = {
    ("atlas-sapmi", "ssi_displaced_status_trajectory"): {
        "value": -1,
        "reason": "The four-state, four-century wrapper has no single defensible generation-after-peak status trajectory."
    },
    ("med-carthage-north-african-settlement", "ssi_displaced_status_trajectory"): {
        "value": 2,
        "reason": "Libyan/Amazigh communities remained differentiated tributary subjects under Punic rule rather than ordinary Carthaginian citizens."
    },
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_journal(path: Path) -> dict[str, list[dict]]:
    submissions: dict[str, list[dict]] = defaultdict(list)
    with path.open() as f:
        for line in f:
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("type") != "result" or not isinstance(rec.get("result"), dict):
                continue
            for event in rec["result"].get("events", []):
                if isinstance(event, dict) and event.get("event_id") and isinstance(event.get("scores"), dict):
                    submissions[event["event_id"]].append(event)
    return submissions


def set_encoded_value(scores: pd.DataFrame, na: pd.DataFrame,
                      event_id: str, dim: str, value: float) -> None:
    if value == -1:
        scores.loc[event_id, dim] = np.nan
        na.loc[event_id, dim] = "U"
    elif value == -2:
        scores.loc[event_id, dim] = np.nan
        na.loc[event_id, dim] = "NA"
    else:
        scores.loc[event_id, dim] = float(value)
        na.loc[event_id, dim] = ""


def era_bucket(start: int) -> str:
    if start < -1000:
        return "deep history (before 1000 BCE)"
    if start < 500:
        return "ancient (-1000 to 499)"
    if start < 1500:
        return "medieval (500-1499)"
    if start < 1800:
        return "early modern (1500-1799)"
    if start < 1900:
        return "nineteenth century"
    if start < 1945:
        return "1900-1944"
    if start < 1990:
        return "1945-1989"
    return "1990-present"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--journal", type=Path,
        help=("Full-coding workflow journal containing both duplicate submissions. "
              "Use this only to recreate the repaired baseline from raw inputs."))
    ap.add_argument(
        "--frozen-baseline", type=Path,
        default=HERE / "baseline_407" / "data",
        help=("Directory containing the frozen repaired 407-event corpus, scores, "
              "NA types, reconciliation, and quality record. Used by default so "
              "later expansion runs do not depend on an ephemeral workflow log."))
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    corpus_path = BASE / "corpus" / "events_corpus_extended.json"
    scores_path = BASE / "matrix" / "scores_matrix.csv"
    na_path = BASE / "matrix" / "na_types.csv"
    codebook_path = BASE / "codebook" / "codebook.json"
    dates_path = HERE / "date_corrections.json"

    codebook = json.loads(codebook_path.read_text())
    dims = [d["id"] for d in codebook["dimensions"]]
    dates = json.loads(dates_path.read_text())
    frozen_inputs: dict[str, Path] = {}

    if args.journal:
        corpus = json.loads(corpus_path.read_text())
        model_rows = [r for r in corpus if r.get("in_model")]
        model_ids = [r["event_id"] for r in model_rows]

        blank_date_ids = {
            r["event_id"] for r in model_rows
            if r.get("start") in (None, "") or r.get("end") in (None, "")
        }
        if blank_date_ids != set(dates):
            raise ValueError(
                f"Date correction coverage mismatch: missing={sorted(blank_date_ids-set(dates))}; "
                f"extra={sorted(set(dates)-blank_date_ids)}")

        for row in corpus:
            if row["event_id"] in dates:
                row["start"], row["end"] = dates[row["event_id"]]
                row["date_repair"] = "second-pass explicit numeric bounds from existing date_label"
            if row.get("in_model"):
                row["start"] = int(row["start"])
                row["end"] = int(row["end"])
                row["era_bucket_v2"] = era_bucket(row["start"])

        scores = (pd.read_csv(scores_path, index_col="event_id")
                  .apply(pd.to_numeric, errors="coerce")
                  .astype(float))
        na = pd.read_csv(na_path, index_col="event_id", keep_default_na=False, dtype=str)
        scores = scores.loc[model_ids, dims]
        na = na.loc[model_ids, dims]

        submissions = load_journal(args.journal)
        duplicate_groups = {
            eid: recs for eid, recs in submissions.items()
            if len(recs) > 1 and eid in model_ids
        }
        if set(duplicate_groups) != {
            "af-transatlantic-slave-removal-senegambia-upper-guinea",
            "am-argentina-chaco-conquest-reducciones",
            "am-mexico-yaqui-war-deportation",
            "atlas-mennonite-chaco",
            "atlas-new-caledonia",
            "atlas-tai-ahom-assam",
            "canada-northern-state-settlement",
            "eu-ottoman-greek-deportations-expulsion",
            "eu-postwar-expulsion-ethnic-germans",
            "europe-norse-settlement-faroes",
            "modern-sri-lanka-civil-war-displacement",
            "russia-west-siberian-conquest-settlement",
            "ussr-dekulakization-special-settlements",
        }:
            raise ValueError(f"Unexpected duplicate set: {sorted(duplicate_groups)}")

        reconciliation = []
        for eid, recs in sorted(duplicate_groups.items()):
            if len(recs) != 2:
                raise ValueError(f"Expected exactly two submissions for {eid}, found {len(recs)}")
            a, b = recs
            for dim in dims:
                va, vb = a["scores"].get(dim), b["scores"].get(dim)
                if va == vb:
                    continue
                key = (eid, dim)
                if key in STRUCTURAL_ADJUDICATIONS:
                    value = STRUCTURAL_ADJUDICATIONS[key]
                    method = "manual_structural_adjudication"
                elif va is not None and vb is not None and va >= 0 and vb >= 0:
                    value = (va + vb) / 2
                    method = "mean_of_two_numeric_submissions"
                else:
                    raise ValueError(
                        f"Unresolved structural disagreement {eid}/{dim}: {va} vs {vb}")
                set_encoded_value(scores, na, eid, dim, value)
                reconciliation.append({
                    "event_id": eid, "dimension": dim, "first": va, "second": vb,
                    "consensus": value, "method": method,
                    "absolute_difference": "" if va < 0 or vb < 0 else abs(va-vb),
                })

        repairs = []
        for (eid, dim), decision in MISSING_CELL_REPAIRS.items():
            if not pd.isna(scores.loc[eid, dim]) or na.loc[eid, dim] != "":
                raise ValueError(f"Expected a true blank at {eid}/{dim}")
            set_encoded_value(scores, na, eid, dim, decision["value"])
            repairs.append({"event_id": eid, "dimension": dim, **decision})
        duplicate_event_count = len(duplicate_groups)
        baseline_mode = "raw_inputs_plus_full_coding_journal"
    else:
        frozen = args.frozen_baseline
        frozen_inputs = {
            "corpus": frozen / "corpus_v2.json",
            "scores": frozen / "scores_v2.csv",
            "na_types": frozen / "na_types_v2.csv",
            "reconciliation": frozen / "duplicate_reconciliation.csv",
            "quality": frozen / "data_quality.json",
            "manifest": frozen / "corpus_manifest.json",
        }
        missing = [str(path) for path in frozen_inputs.values() if not path.exists()]
        if missing:
            raise FileNotFoundError(f"Frozen baseline is incomplete: {missing}")
        corpus = json.loads(frozen_inputs["corpus"].read_text())
        scores = (pd.read_csv(frozen_inputs["scores"], index_col="event_id")
                  .apply(pd.to_numeric, errors="coerce")
                  .astype(float))
        na = pd.read_csv(
            frozen_inputs["na_types"], index_col="event_id",
            keep_default_na=False, dtype=str)
        reconciliation = pd.read_csv(
            frozen_inputs["reconciliation"], keep_default_na=False).to_dict("records")
        frozen_quality = json.loads(frozen_inputs["quality"].read_text())
        model_ids = [r["event_id"] for r in corpus if r.get("in_model")]
        if len(model_ids) != 407 or len(scores) != 407 or len(na) != 407:
            raise ValueError("Frozen repaired baseline must contain exactly 407 model events")
        if model_ids != list(scores.index) or model_ids != list(na.index):
            raise ValueError("Frozen baseline corpus, score, and NA row order do not match")
        scores = scores.loc[model_ids, dims]
        na = na.loc[model_ids, dims]
        repairs = frozen_quality["missing_cells_repaired"]
        duplicate_event_count = int(frozen_quality["duplicate_events_reconciled"])
        baseline_mode = "frozen_repaired_407"

    true_blank = scores.isna() & (na == "")
    if true_blank.any().any():
        bad = [(eid, dim) for eid, row in true_blank.iterrows() for dim, v in row.items() if v]
        raise ValueError(f"Unclassified matrix blanks remain: {bad[:20]}")

    # Optional, explicitly provisional older-era additions. They are kept in
    # separate authored files so the clean 407 baseline can always be recovered.
    # A supersession is fail-closed: every named child must be present and
    # active before the legacy parent can leave an expanded model.
    active_addition_ids = set()
    for additions_path in ADDITION_FILES:
        if not additions_path.exists():
            continue
        active_addition_ids.update(
            item["event"]["event_id"]
            for item in json.loads(additions_path.read_text())
            if item.get("status") == "include_in_second_pass"
        )

    supersession_record = json.loads(SUPERSESSION_FILE.read_text())
    retired_parent_ids = []
    replacement_event_ids = []
    for supersession in supersession_record.get("supersessions", []):
        parent = supersession["parent_event_id"]
        replacements = supersession["replacement_event_ids"]
        missing_replacements = set(replacements) - active_addition_ids
        if missing_replacements:
            raise ValueError(
                f"Supersession for {parent} is incomplete; missing active replacements: "
                f"{sorted(missing_replacements)}"
            )
        if parent not in scores.index or parent not in na.index:
            raise ValueError(f"Supersession parent is not active in the baseline: {parent}")
        parent_rows = [row for row in corpus if row["event_id"] == parent]
        if len(parent_rows) != 1 or not parent_rows[0].get("in_model"):
            raise ValueError(f"Supersession parent corpus row is absent or inactive: {parent}")

        parent_rows[0]["in_model"] = False
        parent_rows[0]["superseded_in_second_pass_by"] = replacements
        parent_rows[0]["supersession_reason"] = supersession["reason"]
        parent_rows[0]["supersession_manifest"] = SUPERSESSION_FILE.name
        scores.drop(index=parent, inplace=True)
        na.drop(index=parent, inplace=True)
        retired_parent_ids.append(parent)
        replacement_event_ids.extend(replacements)

    additions_used = []
    seen_corpus_ids = {r["event_id"] for r in corpus}
    for additions_path in ADDITION_FILES:
        if not additions_path.exists():
            continue
        additions = json.loads(additions_path.read_text())
        for add in additions:
            if add.get("status") != "include_in_second_pass":
                continue
            event = add["event"]
            eid = event["event_id"]
            if eid in seen_corpus_ids:
                raise ValueError(f"Ancient addition duplicates existing id: {eid}")
            raw = add["scores"]
            if set(raw) != set(dims):
                raise ValueError(f"Ancient addition {eid} has wrong score keys")
            row_scores, row_na = {}, {}
            for dim in dims:
                val = raw[dim]
                if isinstance(val, bool) or not isinstance(val, int) or val < -2 or val > 4:
                    raise ValueError(
                        f"Ancient addition {eid}/{dim} must be an integer in -2..4; found {val!r}")
                row_scores[dim] = np.nan if val < 0 else float(val)
                row_na[dim] = "U" if val == -1 else "NA" if val == -2 else ""
            event = dict(event)
            event.update({
                "in_model": True, "on_atlas": False,
                "origin": "second_pass_ancient_crosswalk",
                "era_bucket_v2": era_bucket(int(event["start"])),
            })
            corpus.append(event)
            seen_corpus_ids.add(eid)
            scores.loc[eid] = pd.Series(row_scores)
            na.loc[eid] = pd.Series(row_na)
            additions_used.append(eid)

    active_ids_after = set(scores.index)
    for supersession in supersession_record.get("supersessions", []):
        parent = supersession["parent_event_id"]
        replacements = set(supersession["replacement_event_ids"])
        if parent in active_ids_after:
            raise ValueError(f"Superseded parent remains active: {parent}")
        missing = replacements - active_ids_after
        if missing:
            raise ValueError(
                f"Supersession children failed to enter the active model: {sorted(missing)}"
            )

    true_blank = scores.isna() & (na == "")
    if true_blank.any().any():
        bad = [(eid, dim) for eid, row in true_blank.iterrows() for dim, v in row.items() if v]
        raise ValueError(f"Unclassified matrix blanks remain after additions: {bad[:20]}")

    out_corpus = OUT / "corpus_v2.json"
    out_scores = OUT / "scores_v2.csv"
    out_na = OUT / "na_types_v2.csv"
    out_recon = OUT / "duplicate_reconciliation.csv"
    out_quality = OUT / "data_quality.json"
    out_manifest = OUT / "corpus_manifest.json"

    out_corpus.write_text(json.dumps(corpus, indent=1, ensure_ascii=False) + "\n")
    scores.to_csv(out_scores, float_format="%.3f")
    na.to_csv(out_na, quoting=csv.QUOTE_MINIMAL)
    pd.DataFrame(reconciliation).to_csv(out_recon, index=False)

    quality = {
        "model_events": int(len(scores)),
        "dimensions": len(dims),
        "gapscan_date_repairs": len(dates),
        "baseline_mode": baseline_mode,
        "duplicate_events_reconciled": duplicate_event_count,
        "duplicate_cells_reconciled": len(reconciliation),
        "numeric_duplicate_cells_averaged": sum(r["method"].startswith("mean") for r in reconciliation),
        "structural_duplicate_cells_adjudicated": sum(r["method"].startswith("manual") for r in reconciliation),
        "missing_cells_repaired": repairs,
        "remaining_true_blanks": int(true_blank.sum().sum()),
        "half_step_scores": int(np.isclose((scores.fillna(0) * 2) % 2, 1).sum().sum()),
        "older_era_additions_used": additions_used,
        "superseded_parent_event_ids": retired_parent_ids,
        "replacement_event_ids": replacement_event_ids,
        "gross_additions": len(additions_used),
        "net_change_from_repaired_baseline": int(len(scores) - 407),
    }
    out_quality.write_text(json.dumps(quality, indent=1, ensure_ascii=False) + "\n")

    manifest = {
        "version": "second-pass-v2",
        "created": "2026-08-20",
        "inputs": {
            str(corpus_path.relative_to(BASE)): sha256(corpus_path),
            str(scores_path.relative_to(BASE)): sha256(scores_path),
            str(na_path.relative_to(BASE)): sha256(na_path),
            str(codebook_path.relative_to(BASE)): sha256(codebook_path),
            str(dates_path.relative_to(BASE)): sha256(dates_path),
            str(SUPERSESSION_FILE.relative_to(BASE)): sha256(SUPERSESSION_FILE),
            **({"full_coding_journal": sha256(args.journal)} if args.journal else {
                str(path.relative_to(BASE)): sha256(path)
                for path in frozen_inputs.values()
            }),
            **{
                str(path.relative_to(BASE)): sha256(path)
                for path in ADDITION_FILES if path.exists()
            },
        },
        "outputs": {
            out_corpus.name: sha256(out_corpus),
            out_scores.name: sha256(out_scores),
            out_na.name: sha256(out_na),
            out_recon.name: sha256(out_recon),
        },
        "quality": quality,
    }
    out_manifest.write_text(json.dumps(manifest, indent=1, ensure_ascii=False) + "\n")
    print(json.dumps(quality, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
