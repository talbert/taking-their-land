"""Explicit accepted-file/ID joins; no corpus constructor or historical selection."""
from __future__ import annotations

import io
import json
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from numerics import ROOT, digest

ERAS = {'deep history (before 1000 BCE)', 'ancient (-1000 to 499)',
        'medieval (500-1499)', 'early modern (1500-1799)', 'nineteenth century',
        '1900-1944', '1945-1989', '1990-present'}
MACROREGIONS = {'CENTRAL_ASIA', 'CENTRAL_AFRICA', 'EAST_ASIA', 'EAST_AFRICA',
                'EUROPE', 'LATIN_AMERICA_CARIBBEAN', 'MULTIREGIONAL', 'NORTH_AFRICA',
                'NORTH_AMERICA', 'NORTH_ASIA', 'OCEANIA', 'SOUTH_ASIA',
                'SOUTHEAST_ASIA', 'SOUTHERN_AFRICA', 'WEST_AFRICA', 'WEST_ASIA'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_ids(ids, label):
    require(isinstance(ids, list) and all(isinstance(x, str) and x for x in ids)
            and len(ids) == len(set(ids)), 'Invalid/duplicate IDs: ' + label)
    return set(ids)


class Reader:
    def __init__(self):
        self.bindings = {}

    def read(self, ref):
        require(set(ref) == {'path', 'sha256'} and isinstance(ref['path'], str)
                and re.fullmatch('[0-9a-f]{64}', ref['sha256']) is not None,
                'Every file needs an explicit path and SHA-256')
        path = (ROOT / ref['path']).resolve(strict=True)
        raw = path.read_bytes()
        require(digest(raw) == ref['sha256'], 'Input hash mismatch: ' + str(path))
        require(str(path) not in self.bindings or self.bindings[str(path)] == ref['sha256'],
                'Conflicting binding: ' + str(path))
        self.bindings[str(path)] = ref['sha256']
        return raw

    def json(self, ref):
        return json.loads(self.read(ref))

    def unchanged(self):
        for path, expected in self.bindings.items():
            require(digest(Path(path).read_bytes()) == expected, 'Input changed during run: ' + path)


@dataclass
class Dataset:
    scores: pd.DataFrame
    na: pd.DataFrame
    corpus: pd.DataFrame
    analysis: pd.DataFrame
    full_corpus: pd.DataFrame | None = None

    def subset(self, ids):
        return Dataset(*(frame.loc[ids].copy() for frame in
                         (self.scores, self.na, self.corpus, self.analysis)),
                       full_corpus=self.full_corpus if self.full_corpus is not None else self.corpus)


def validate_dataset(data, columns):
    scores, na, corpus, analysis = data.scores, data.na, data.corpus, data.analysis
    require(scores.index.is_unique and scores.columns.is_unique and list(scores.columns) == columns,
            'Scores require unique IDs and original ordered 60 dimensions')
    for name, frame in [('NA', na), ('corpus', corpus), ('analysis metadata', analysis)]:
        require(frame.index.equals(scores.index), 'Missing/extra/reordered IDs in ' + name)
    require(na.columns.equals(scores.columns), 'NA column order differs')
    values = scores.to_numpy(float)
    observed = values[np.isfinite(values)]
    require(not np.isinf(values).any() and ((observed >= 0) & (observed <= 4)).all(),
            'Raw observations must be finite in [0,4] or typed blanks; inherited fractions remain unchanged')
    require(np.isin(na.values, ['', 'U', 'NA']).all() and
            np.array_equal(scores.isna().values, na.isin(['U', 'NA']).values),
            'Unknown/structural missingness does not match raw blanks')
    require(corpus['era_bucket_v2'].isin(ERAS).all(), 'Supply valid eras; do not infer from dates')
    require(analysis['normalized_macroregion'].isin(MACROREGIONS).all(),
            'Complete accepted 16-vocabulary macroregion join required')
    for event_id, row in analysis.iterrows():
        for field in ('date_is_proxy', 'continuous_date_eligible', 'duration_eligible'):
            require(type(row[field]) is bool, f'{event_id}: explicit boolean {field} required')
        require(isinstance(row['observation_horizons'], dict) and row['observation_horizons']
                and isinstance(row['authority_refs'], list) and row['authority_refs'],
                f'{event_id}: explicit horizon/authority record required')
        source = corpus.loc[event_id]
        for field in ('start', 'end'):
            value = source[field]
            require(pd.isna(value) or (not isinstance(value, (bool, str)) and np.isfinite(value)),
                    f'{event_id}: nullable numeric {field} required')
        if 'date_numeric_proxy_used' in source and not pd.isna(source['date_numeric_proxy_used']):
            require(source['date_numeric_proxy_used'] == row['date_is_proxy'],
                    f'{event_id}: proxy flag join differs')
        year = row['observed_date_year']
        if row['continuous_date_eligible']:
            require(not row['date_is_proxy'] and not pd.isna(source['start'])
                    and not pd.isna(year) and np.isfinite(year),
                    f'{event_id}: absent/proxy date cannot enter observed-date diagnostics')
        else:
            require(pd.isna(year), f'{event_id}: excluded date must remain null, not a fallback year')
        duration = row['duration_years']
        require(isinstance(row['duration_measurand'], str) and row['duration_measurand'],
                f'{event_id}: duration measurand/unknown reason required')
        if row['duration_eligible']:
            require(not pd.isna(duration) and np.isfinite(duration) and duration >= 0,
                    f'{event_id}: eligible duration requires an explicit measured value')
        else:
            require(pd.isna(duration), f'{event_id}: unknown duration must stay null')
    return data


def load_dataset(reader, spec, columns, *, archive=False):
    expected = spec['event_ids']
    unique_ids(expected, 'dataset roster')
    frames = [pd.read_csv(io.BytesIO(reader.read(spec[key])), index_col='event_id',
                          keep_default_na=False, dtype=str) for key in ('scores', 'na_types')]
    require(list(frames[0].index) == expected and list(frames[1].index) == expected,
            'Declared score/NA roster order differs')
    scores = frames[0].replace('', np.nan).astype(float)
    corpus = pd.DataFrame(reader.json(spec['corpus'])).set_index('event_id')
    require(corpus.index.is_unique and set(expected) <= set(corpus.index), 'Corpus IDs differ')
    require(corpus['in_model'].map(lambda x: type(x) is bool).all(), 'Nonboolean activity flag')
    if not archive:
        require(set(corpus.index[corpus['in_model']]) == set(expected), 'Active corpus/score roster differs')
    analysis = pd.DataFrame(reader.json(spec['analysis_metadata'])).set_index('event_id')
    require(analysis.index.is_unique and set(analysis.index) == set(expected),
            'Complete baseline/successor macroregion/horizon join required; no defaults')
    return validate_dataset(Dataset(scores, frames[1], corpus.loc[expected], analysis.loc[expected],
                                    full_corpus=corpus), columns)


def concatenate(parts):
    return Dataset(*(pd.concat([getattr(d, key) for d in parts]) for key in
                     ('scores', 'na', 'corpus', 'analysis')))


def validate_scope(base, successor, scope):
    old, new = set(base.scores.index), set(successor.scores.index)
    retired = unique_ids(scope['retired_ids'], 'retired')
    added = unique_ids(scope['new_ids'], 'new')
    require(old - new == retired and new - old == added, 'Retirement/new roster arithmetic differs')
    require(not new.intersection(unique_ids(scope['held_ids'], 'held')), 'Held candidate activated')
    require(scope['overlap_scope_complete'] is True, 'Main must supply complete overlap scope')
    metadata = successor.full_corpus if successor.full_corpus is not None else successor.corpus
    require(metadata.index.is_unique and metadata['in_model'].map(lambda x: type(x) is bool).all()
            and set(metadata.index[metadata['in_model']]) == new,
            'Full current corpus metadata/activity binding differs')
    for ruling in scope['parent_child_rulings']:
        require(ruling['authority_refs'] and ruling['parent_id'] in metadata.index,
                'Unbound parent/child ruling')
        children = unique_ids(ruling['child_ids'], 'children')
        require(children <= set(metadata.index) and ruling['parent_id'] not in children, 'Invalid child IDs')
        parent_active = bool(metadata.loc[ruling['parent_id'], 'in_model'])
        active_pair = parent_active and bool(children & new)
        require(ruling['ruling'] in {'parent_inactive', 'active_nonoverlap'} and
                (ruling['ruling'] != 'parent_inactive' or not parent_active) and
                (not active_pair or ruling['ruling'] == 'active_nonoverlap'),
                'Active parent/child pair lacks main non-overlap ruling')
    common = base.scores.index[base.scores.index.isin(new)]
    equal = (base.scores.loc[common].eq(successor.scores.loc[common]) |
             (base.scores.loc[common].isna() & successor.scores.loc[common].isna()))
    equal &= base.na.loc[common].eq(successor.na.loc[common])
    changed = {(event_id, col) for event_id, row in equal.iterrows() for col in equal.columns if not row[col]}
    reviewed = [(r['event_id'], r['dimension_id']) for r in scope['reviewed_existing_cells']]
    require(len(reviewed) == len(set(reviewed)) and all(e in common and c in equal.columns for e, c in reviewed),
            'Review ledger must name distinct retained-row cells')
    require(changed <= set(reviewed), 'Unassigned retained-row cell changed')
    # The inherited matrix contains fractional observations. They are not new
    # pseudo-scores and must not be rounded. Only the accepted recoding scope
    # and independently coded full new definitions use the integer instrument.
    for event_id, column in reviewed:
        value = successor.scores.loc[event_id, column]
        require(pd.isna(value) or value in (0, 1, 2, 3, 4),
                f'Accepted recoded cell is fractional: {event_id}/{column}')
    new_values = successor.scores.loc[sorted(added)].to_numpy(float)
    require(np.isin(new_values[np.isfinite(new_values)], [0, 1, 2, 3, 4]).all(),
            'New full definition contains a fractional code')
    require(len(changed) == scope['expected_actual_changed_cells'] and
            len(reviewed) - len(changed) == scope['expected_reviewed_confirmed_cells'],
            'Actual changes/confirmed arithmetic differs (4.000 equals 4)')
    require(successor.analysis.loc[sorted(added), 'duration_years'].isna().all() and
            not successor.analysis.loc[sorted(added), 'duration_eligible'].any(),
            'All fourteen new definitions have unknown process duration')
    return {'actual_changed_cells': len(changed), 'reviewed_confirmed_cells': len(reviewed) - len(changed),
            'changed_ids': sorted({e for e, _ in changed}), 'retired_ids': sorted(retired),
            'new_ids': sorted(added), 'unassigned_retained_cells_equal': True}


def acceptance_gate(acceptance, manifest):
    require(acceptance['schema'] == 'successor-model-execution-inputs-v1' and
            acceptance['status'] == 'MAIN_ACCEPTED_COMPLETE_CANDIDATE' and
            acceptance['complete_candidate'] is True and acceptance['open_packages'] == [] and
            acceptance['main_acceptance_ref'] and acceptance['release_cutoff'],
            'Requires explicit main acceptance of the complete candidate')
    require(manifest.get('complete_candidate') is True and manifest.get('fit_authorized') is True,
            'Incomplete/663 checkpoint is ineligible, regardless of its filename')


def load_contract(path, expected_sha, columns):
    reader = Reader()
    acceptance = reader.json({'path': str(path), 'sha256': expected_sha})
    # Acceptance gate precedes every historical score/metadata read.
    acceptance_gate(acceptance, reader.json(acceptance['candidate_manifest']))
    reader.read(acceptance['baseline_manifest'])
    require(acceptance['baseline_release'] == 'second_pass_v6_675', 'Wrong immutable baseline')
    datasets = {name: load_dataset(reader, spec, columns, archive=name not in {'baseline', 'successor'})
                for name, spec in acceptance['datasets'].items()}
    require(len(datasets['baseline'].scores) == 675, 'Frozen v6 roster must have 675 active rows')
    scope = reader.json(acceptance['scope'])
    arithmetic = validate_scope(datasets['baseline'], datasets['successor'], scope)
    # Provenance comes from the accepted integration, not another coding audit.
    for cell in scope['reviewed_existing_cells']:
        reader.read(cell['authority_ref'])
    require(set(scope['new_definition_authorities']) == set(scope['new_ids']),
            'Each new full definition needs its accepted coding-output binding')
    for ref in scope['new_definition_authorities'].values():
        reader.read(ref)
    programs = reader.json(acceptance['programs'])
    require(programs['status'] == 'MAIN_ACCEPTED_PREDECLARED_PROGRAMS_AND_HORIZONS',
            'Predeclared program registry not accepted')
    authorities = programs['authority_bindings']
    for ref in authorities.values():
        reader.read(ref)
    covered = set()
    unique_ids([r['id'] for r in programs['instructions']], 'program instructions')
    for instruction in programs['instructions']:
        require(instruction['authority_ids'] and set(instruction['authority_ids']) <= set(authorities),
                'Program instruction lacks bound authority')
        covered.update(instruction['authority_ids'])
    require(covered == unique_ids(programs['required_authority_ids'], 'required program authorities'),
            'Accepted program authority coverage differs')
    reference = pd.read_csv(io.BytesIO(reader.read(acceptance['reference_loadings'])), index_col=0)
    require(list(reference.index) == columns and reference.shape == (60, 8) and
            reference.columns.is_unique and np.isfinite(reference.values).all(),
            'Explicit frozen named-eight reference loadings required, not family labels')
    reader.unchanged()
    return acceptance, datasets, scope, programs, reference, arithmetic, reader
