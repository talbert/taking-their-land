#!/usr/bin/env python3
"""Run pre-registered statistical-weight checks for the Hellenistic tranche.

All alternative groupings and weights are diagnostic only.  They never create
active corpus rows, alter the frozen v4 release, or determine admission.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import platform
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from scipy.stats import spearmanr
from sklearn.cluster import KMeans
from sklearn.impute import KNNImputer
from sklearn.metrics import adjusted_rand_score, silhouette_score


ROOT = Path(__file__).resolve().parents[3]
SECOND_PASS = ROOT / "analysis" / "second_pass"
V5 = SECOND_PASS / "v5"
BRIEFS = V5 / "hellenistic_coding_briefs.csv"
CANDIDATES = V5 / "candidates"
V4 = SECOND_PASS / "releases" / "second_pass_v4_583"
FULL = CANDIDATES / "hellenistic_full_equal_event_680"
SUCCESSOR = CANDIDATES / "hellenistic_successor_only_676"
OUT = CANDIDATES / "hellenistic_sensitivity_results"

SCENARIOS_CSV = OUT / "scenario_metrics.csv"
FACTORS_CSV = OUT / "factor_metrics.csv"
WEIGHTING_CSV = OUT / "weighting_metrics.csv"
DOCUMENTATION_CSV = OUT / "documentation_strata.csv"
IMPUTATION_CSV = OUT / "imputation_metrics.csv"
SUMMARY_JSON = OUT / "hellenistic_sensitivity_summary.json"
MANIFEST_JSON = OUT / "results_manifest.json"
REPORT = V5 / "HELLENISTIC_STATISTICAL_SENSITIVITY.md"

SEED = 22082026
N_HORN = 500


def load_pipeline_module():
    path = SECOND_PASS / "12_run_second_pass.py"
    spec = importlib.util.spec_from_file_location("second_pass_pipeline_v5", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load second-pass pipeline")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PIPELINE = load_pipeline_module()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def runtime_manifest() -> dict[str, Any]:
    packages = {}
    for distribution in (
        "numpy",
        "pandas",
        "scipy",
        "scikit-learn",
        "factor-analyzer",
    ):
        packages[distribution] = importlib.metadata.version(distribution)
    return {
        "python": sys.version.split()[0],
        "python_executable": str(Path(sys.executable)),
        "platform": platform.platform(),
        "packages": packages,
    }


def render_csv(rows: list[dict[str, Any]], fields: list[str]) -> bytes:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8")


def split_pipe(value: str) -> list[str]:
    value = value.strip()
    if not value or value == "none":
        return []
    return [part.strip() for part in value.split("|") if part.strip()]


def read_briefs() -> tuple[list[str], dict[str, list[str]]]:
    with BRIEFS.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    event_ids = [row["coding_unit_id"] for row in rows]
    groups: dict[str, list[str]] = defaultdict(list)
    for row in rows:
        for group in split_pipe(row["sensitivity_groups"]):
            groups[group].append(row["coding_unit_id"])
    if len(event_ids) != 97 or len(set(event_ids)) != 97 or len(groups) != 12:
        raise ValueError("Hellenistic event/group register changed")
    if sum(len(members) for members in groups.values()) != 42:
        raise ValueError("expected 42 linked-program memberships")
    return event_ids, dict(sorted(groups.items()))


def load_dataset(path: Path) -> dict[str, Any]:
    data = path / "data"
    scores = pd.read_csv(data / "scores_v2.csv", index_col="event_id").astype(float)
    na_types = pd.read_csv(
        data / "na_types_v2.csv",
        index_col="event_id",
        keep_default_na=False,
        dtype=str,
    ).loc[scores.index]
    corpus_all = pd.DataFrame(json.loads((data / "corpus_v2.json").read_text()))
    corpus = (
        corpus_all[corpus_all["in_model"] == True]  # noqa: E712
        .set_index("event_id")
        .loc[scores.index]
    )
    true_blank = scores.isna() & (na_types == "")
    if true_blank.any().any():
        raise ValueError(f"untyped blank cells in {path}")
    return {"scores": scores, "na_types": na_types, "corpus": corpus}


def tucker(a: pd.Series, b: pd.Series) -> float:
    denominator = float(np.sqrt(np.dot(a, a) * np.dot(b, b)))
    return float(np.dot(a, b) / denominator) if denominator else 0.0


def safe_rho(a: pd.Series | np.ndarray, b: pd.Series | np.ndarray) -> float:
    value, _ = spearmanr(a, b)
    return float(value) if np.isfinite(value) else 0.0


def weighted_correlation(x: np.ndarray, weights: np.ndarray) -> np.ndarray:
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    mean = np.sum(x * weights[:, None], axis=0)
    centered = x - mean
    covariance = (centered * weights[:, None]).T @ centered
    scale = np.sqrt(np.diag(covariance))
    corr = covariance / np.outer(scale, scale)
    corr = np.nan_to_num(corr, nan=0.0)
    np.fill_diagonal(corr, 1.0)
    return corr


def observed_eigenvalues(
    values: np.ndarray, weights: np.ndarray | None = None
) -> tuple[np.ndarray, np.ndarray]:
    corr = (
        np.corrcoef(values, rowvar=False)
        if weights is None
        else weighted_correlation(values, weights)
    )
    return np.sort(np.linalg.eigvalsh(corr))[::-1], corr


def horn_thresholds(
    n_rows: int,
    n_columns: int,
    *,
    weights: np.ndarray | None = None,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    sims = np.empty((N_HORN, n_columns), dtype=float)
    for index in range(N_HORN):
        random_x = rng.normal(size=(n_rows, n_columns))
        corr = (
            np.corrcoef(random_x, rowvar=False)
            if weights is None
            else weighted_correlation(random_x, weights)
        )
        sims[index] = np.sort(np.linalg.eigvalsh(corr))[::-1]
    return np.percentile(sims, 95, axis=0)


def fit_scores(
    scores: pd.DataFrame,
    reference_loadings: pd.DataFrame,
    *,
    imputed: pd.DataFrame | None = None,
) -> dict[str, Any]:
    matrix = scores.fillna(scores.median()) if imputed is None else imputed
    analyzer = FactorAnalyzer(n_factors=8, rotation="oblimin", method="minres")
    analyzer.fit(matrix.values)
    raw_loadings = pd.DataFrame(
        analyzer.loadings_,
        index=scores.columns,
        columns=[f"N{index + 1}" for index in range(8)],
    )
    raw_scores = pd.DataFrame(
        analyzer.transform(matrix.values),
        index=scores.index,
        columns=raw_loadings.columns,
    )
    loadings, factor_scores, alignment = PIPELINE.align_factors(
        reference_loadings, raw_loadings, raw_scores
    )
    labels = KMeans(n_clusters=6, n_init=100, random_state=0).fit_predict(
        factor_scores.values
    )
    return {
        "loadings": loadings,
        "factor_scores": factor_scores,
        "alignment": alignment,
        "labels": labels,
        "silhouette": float(silhouette_score(factor_scores.values, labels)),
        "imputed": matrix,
    }


def fit_correlation(corr: np.ndarray, columns: pd.Index) -> pd.DataFrame:
    analyzer = FactorAnalyzer(
        n_factors=8,
        rotation="oblimin",
        method="minres",
        is_corr_matrix=True,
    )
    analyzer.fit(corr)
    return pd.DataFrame(
        analyzer.loadings_,
        index=columns,
        columns=[f"W{index + 1}" for index in range(8)],
    )


def align_loadings(
    reference_loadings: pd.DataFrame,
    raw_loadings: pd.DataFrame,
) -> pd.DataFrame:
    """Align one raw solution directly to one named reference solution."""
    dummy = pd.DataFrame(
        np.zeros((1, 8)), index=["__dummy"], columns=raw_loadings.columns
    )
    aligned, _, _ = PIPELINE.align_factors(
        reference_loadings, raw_loadings, dummy
    )
    return aligned


def collapse_groups(
    scores: pd.DataFrame, groups: dict[str, list[str]], label: str
) -> pd.DataFrame:
    members = [event_id for ids in groups.values() for event_id in ids]
    if len(members) != len(set(members)):
        raise ValueError("a Hellenistic event appears in multiple sensitivity groups")
    base = scores.drop(index=members)
    rows = []
    names = []
    for group, ids in groups.items():
        rows.append(scores.loc[ids].median(axis=0, skipna=True))
        names.append(f"__hellenistic_{label}_{group}")
    pseudo = pd.DataFrame(rows, index=names, columns=scores.columns)
    return pd.concat([base, pseudo])


def scenario_metrics(
    name: str,
    mode: str,
    scores: pd.DataFrame,
    reference_loadings: pd.DataFrame,
    reference_scores: pd.DataFrame,
    reference_labels: pd.Series,
    horn_cache: dict[int, np.ndarray],
    factor_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    fit = fit_scores(scores, reference_loadings)
    shared = reference_scores.index.intersection(scores.index)
    positions = scores.index.get_indexer(shared)
    scenario_labels = fit["labels"][positions]
    prior_labels = reference_labels.loc[shared].astype(int).values
    aligned_labels, _, _ = PIPELINE.align_cluster_labels(prior_labels, scenario_labels)

    congruences = []
    correlations = []
    for factor in reference_loadings.columns:
        congruence = abs(tucker(reference_loadings[factor], fit["loadings"][factor]))
        rho = safe_rho(
            reference_scores.loc[shared, factor],
            fit["factor_scores"].loc[shared, factor],
        )
        congruences.append(congruence)
        correlations.append(rho)
        factor_rows.append(
            {
                "scenario": name,
                "mode": mode,
                "factor": factor,
                "loading_tucker_vs_v4": congruence,
                "shared_v4_score_spearman": rho,
            }
        )

    imputed = fit["imputed"]
    eigenvalues, _ = observed_eigenvalues(imputed.values)
    thresholds = horn_cache.get(len(scores))
    if thresholds is None:
        thresholds = horn_thresholds(
            len(scores), scores.shape[1], seed=SEED + len(scores)
        )
        horn_cache[len(scores)] = thresholds
    changed = int(np.sum(prior_labels != aligned_labels))
    changed_share = float(changed / len(shared))
    factor_count = int(np.sum(eigenvalues > thresholds))
    eight_axis_or_cluster_material = bool(
        min(congruences) < 0.85
        or min(correlations) < 0.90
        or changed_share > 0.05
    )
    return {
        "scenario": name,
        "mode": mode,
        "rows_in_model_or_sensitivity": len(scores),
        "pseudo_rows": int(sum(str(index).startswith("__hellenistic_") for index in scores.index)),
        "shared_v4_events": len(shared),
        "parallel_analysis_factors": factor_count,
        "factor_count_changed_vs_v4": factor_count != 8,
        "factor_8_margin": float(eigenvalues[7] - thresholds[7]),
        "factor_9_margin": float(eigenvalues[8] - thresholds[8]),
        "factor_10_margin": float(eigenvalues[9] - thresholds[9]),
        "factor_loading_tucker_min_vs_v4": float(min(congruences)),
        "factor_loading_tucker_mean_vs_v4": float(np.mean(congruences)),
        "shared_factor_score_spearman_min_vs_v4": float(min(correlations)),
        "shared_factor_score_spearman_mean_vs_v4": float(np.mean(correlations)),
        "k6_adjusted_rand_vs_v4": float(
            adjusted_rand_score(prior_labels, scenario_labels)
        ),
        "k6_changed_after_alignment": changed,
        "k6_changed_share": changed_share,
        "k6_silhouette": fit["silhouette"],
        "eight_axis_or_cluster_material_flag": eight_axis_or_cluster_material,
        "any_material_flag": bool(
            factor_count != 8 or eight_axis_or_cluster_material
        ),
    }


def era_median_imputation(scores: pd.DataFrame, eras: pd.Series) -> pd.DataFrame:
    result = scores.copy()
    for _, ids in eras.groupby(eras).groups.items():
        ids = result.index.intersection(ids)
        result.loc[ids] = result.loc[ids].fillna(result.loc[ids].median())
    return result.fillna(scores.median())


def knn_unknown_imputation(
    scores: pd.DataFrame, na_types: pd.DataFrame
) -> pd.DataFrame:
    staged = scores.copy()
    medians = scores.median()
    for column in staged.columns:
        staged.loc[na_types[column] == "NA", column] = medians[column]
    values = KNNImputer(n_neighbors=10, weights="distance").fit_transform(staged)
    return pd.DataFrame(values, index=scores.index, columns=scores.columns)


def structural_zero_imputation(
    scores: pd.DataFrame, na_types: pd.DataFrame
) -> pd.DataFrame:
    result = scores.copy()
    medians = scores.median()
    for column in result.columns:
        result.loc[na_types[column] == "NA", column] = 0.0
        result.loc[na_types[column] == "U", column] = medians[column]
    return result


def build() -> dict[str, Any]:
    event_ids, groups = read_briefs()
    datasets = {
        "v4_parent_only_583": load_dataset(V4),
        "full_equal_event_680": load_dataset(FULL),
        "successor_only_676": load_dataset(SUCCESSOR),
    }
    observed_counts = {label: len(item["scores"]) for label, item in datasets.items()}
    if observed_counts != {
        "v4_parent_only_583": 583,
        "full_equal_event_680": 680,
        "successor_only_676": 676,
    }:
        raise ValueError(f"candidate counts changed: {observed_counts}")

    full_scores = datasets["full_equal_event_680"]["scores"]
    full_na = datasets["full_equal_event_680"]["na_types"]
    full_corpus = datasets["full_equal_event_680"]["corpus"]
    if not set(event_ids).issubset(full_scores.index):
        raise ValueError("full candidate is missing Hellenistic event IDs")

    reference_loadings = pd.read_csv(
        V4 / "results" / "loadings_aligned.csv", index_col=0
    )
    reference_scores = pd.read_csv(
        V4 / "results" / "factor_scores_aligned.csv", index_col=0
    )
    reference_labels = pd.read_csv(
        V4 / "results" / "clean_k6_assignments.csv", index_col=0
    )["cluster"].astype(int)
    if not (
        list(reference_scores.index) == list(datasets["v4_parent_only_583"]["scores"].index)
        and list(reference_labels.index) == list(reference_scores.index)
    ):
        raise ValueError("v4 results and data row order differ")

    grouped_full = collapse_groups(full_scores, groups, "grouped_full")
    successor_scores = datasets["successor_only_676"]["scores"]
    grouped_successor = collapse_groups(
        successor_scores, groups, "grouped_successor"
    )
    one_tranche = full_scores.drop(index=event_ids)
    one_tranche.loc["__hellenistic_entire_tranche_median"] = full_scores.loc[
        event_ids
    ].median(axis=0, skipna=True)

    scenarios: dict[str, tuple[str, pd.DataFrame]] = {
        "v4_parent_only_583": ("parent_only_baseline", datasets["v4_parent_only_583"]["scores"]),
        "full_equal_event_680": ("equal_event", full_scores),
        "successor_only_676": ("drop_four_overlap_parents", successor_scores),
        "grouped_program_medians_650": ("collapse_42_linked_events_to_12_program_medians", grouped_full),
        "grouped_successor_only_646": ("grouped_and_drop_four_overlap_parents", grouped_successor),
        "entire_tranche_one_median_584": ("deliberately_harsh_source_density_bound", one_tranche),
    }
    for group, members in groups.items():
        scenarios[f"leave_group_out__{group}"] = (
            "leave_one_linked_program_out",
            full_scores.drop(index=members),
        )

    horn_cache: dict[int, np.ndarray] = {}
    factor_rows: list[dict[str, Any]] = []
    scenario_rows = [
        scenario_metrics(
            name,
            mode,
            scores,
            reference_loadings,
            reference_scores,
            reference_labels,
            horn_cache,
            factor_rows,
        )
        for name, (mode, scores) in scenarios.items()
    ]

    full_imputed = full_scores.fillna(full_scores.median())
    full_fit = fit_scores(full_scores, reference_loadings, imputed=full_imputed)
    hellenistic_mask = full_scores.index.isin(event_ids)
    era_counts = full_corpus["era_bucket_v2"].value_counts()
    era_weights = full_corpus["era_bucket_v2"].map(
        lambda era: 1.0 / era_counts[era]
    ).to_numpy(dtype=float)
    half_weights = np.ones(len(full_scores), dtype=float)
    half_weights[hellenistic_mask] = 0.5
    program_cap_weights = np.ones(len(full_scores), dtype=float)
    program_cap_weights[hellenistic_mask] = 12.0 / len(event_ids)
    weighting_scenarios = {
        "unweighted_equal_event": np.ones(len(full_scores), dtype=float),
        "equal_total_weight_per_era": era_weights,
        "hellenistic_half_weight_each": half_weights,
        "hellenistic_tranche_capped_to_12_program_equivalents": program_cap_weights,
    }
    weighting_rows: list[dict[str, Any]] = []
    for offset, (name, weights) in enumerate(weighting_scenarios.items()):
        eigenvalues, corr = observed_eigenvalues(full_imputed.values, weights)
        thresholds = horn_thresholds(
            len(full_scores),
            full_scores.shape[1],
            weights=weights,
            seed=SEED + 1000 + offset,
        )
        raw_weighted_loadings = fit_correlation(corr, full_scores.columns)
        loadings_vs_full = align_loadings(
            full_fit["loadings"], raw_weighted_loadings
        )
        loadings_vs_v4 = align_loadings(
            reference_loadings, raw_weighted_loadings
        )
        vs_full = [
            abs(
                tucker(
                    full_fit["loadings"][factor],
                    loadings_vs_full[factor],
                )
            )
            for factor in full_fit["loadings"].columns
        ]
        vs_v4 = [
            abs(tucker(reference_loadings[factor], loadings_vs_v4[factor]))
            for factor in reference_loadings.columns
        ]
        weighting_rows.append(
            {
                "weighting": name,
                "sum_weights": float(weights.sum()),
                "effective_sample_size": float(weights.sum() ** 2 / np.sum(weights**2)),
                "parallel_analysis_factors": int(np.sum(eigenvalues > thresholds)),
                "factor_8_margin": float(eigenvalues[7] - thresholds[7]),
                "factor_9_margin": float(eigenvalues[8] - thresholds[8]),
                "factor_10_margin": float(eigenvalues[9] - thresholds[9]),
                "minimum_loading_tucker_vs_full_equal_event": float(min(vs_full)),
                "mean_loading_tucker_vs_full_equal_event": float(np.mean(vs_full)),
                "minimum_loading_tucker_vs_v4": float(min(vs_v4)),
                "mean_loading_tucker_vs_v4": float(np.mean(vs_v4)),
            }
        )

    documentation_rows: list[dict[str, Any]] = []
    for label in ("v4_parent_only_583", "full_equal_event_680", "successor_only_676"):
        scores = datasets[label]["scores"]
        na_types = datasets[label]["na_types"]
        missing = (na_types == "U").sum(axis=1) + (na_types == "NA").sum(axis=1)
        for maximum_missing in (0, 5, 10, 15, 20, 30):
            subset = scores.loc[missing <= maximum_missing]
            row: dict[str, Any] = {
                "dataset": label,
                "maximum_missing_cells_per_event": maximum_missing,
                "n_events": len(subset),
                "hellenistic_events_retained": int(subset.index.isin(event_ids).sum()),
                "factor_model_run": False,
                "parallel_analysis_factors": "",
                "minimum_loading_tucker_vs_v4": "",
                "mean_loading_tucker_vs_v4": "",
            }
            if len(subset) >= 100:
                fit = fit_scores(subset, reference_loadings)
                eigenvalues, _ = observed_eigenvalues(fit["imputed"].values)
                thresholds = horn_cache.get(len(subset))
                if thresholds is None:
                    thresholds = horn_thresholds(
                        len(subset), subset.shape[1], seed=SEED + 5000 + len(subset)
                    )
                    horn_cache[len(subset)] = thresholds
                congruences = [
                    abs(tucker(reference_loadings[factor], fit["loadings"][factor]))
                    for factor in reference_loadings.columns
                ]
                row.update(
                    {
                        "factor_model_run": True,
                        "parallel_analysis_factors": int(np.sum(eigenvalues > thresholds)),
                        "minimum_loading_tucker_vs_v4": float(min(congruences)),
                        "mean_loading_tucker_vs_v4": float(np.mean(congruences)),
                    }
                )
            documentation_rows.append(row)

    imputation_matrices = {
        "global_median": full_imputed,
        "era_specific_median": era_median_imputation(
            full_scores, full_corpus["era_bucket_v2"]
        ),
        "unknown_knn_structural_median": knn_unknown_imputation(full_scores, full_na),
        "unknown_median_structural_zero_bound": structural_zero_imputation(
            full_scores, full_na
        ),
    }
    base_imputation_fit = full_fit
    full_thresholds = horn_cache.get(len(full_scores))
    if full_thresholds is None:
        full_thresholds = horn_thresholds(
            len(full_scores), full_scores.shape[1], seed=SEED + len(full_scores)
        )
        horn_cache[len(full_scores)] = full_thresholds
    imputation_rows: list[dict[str, Any]] = []
    for name, matrix in imputation_matrices.items():
        fit = fit_scores(full_scores, reference_loadings, imputed=matrix)
        eigenvalues, _ = observed_eigenvalues(matrix.values)
        vs_pipeline = [
            abs(
                tucker(
                    base_imputation_fit["loadings"][factor],
                    fit["loadings"][factor],
                )
            )
            for factor in reference_loadings.columns
        ]
        vs_v4 = [
            abs(tucker(reference_loadings[factor], fit["loadings"][factor]))
            for factor in reference_loadings.columns
        ]
        imputation_rows.append(
            {
                "imputation": name,
                "parallel_analysis_factors": int(np.sum(eigenvalues > full_thresholds)),
                "factor_8_margin": float(eigenvalues[7] - full_thresholds[7]),
                "factor_9_margin": float(eigenvalues[8] - full_thresholds[8]),
                "factor_10_margin": float(eigenvalues[9] - full_thresholds[9]),
                "minimum_loading_tucker_vs_global_median": float(min(vs_pipeline)),
                "mean_loading_tucker_vs_global_median": float(np.mean(vs_pipeline)),
                "minimum_loading_tucker_vs_v4": float(min(vs_v4)),
                "mean_loading_tucker_vs_v4": float(np.mean(vs_v4)),
            }
        )

    output_specs = {
        SCENARIOS_CSV: (scenario_rows, list(scenario_rows[0])),
        FACTORS_CSV: (factor_rows, list(factor_rows[0])),
        WEIGHTING_CSV: (weighting_rows, list(weighting_rows[0])),
        DOCUMENTATION_CSV: (documentation_rows, list(documentation_rows[0])),
        IMPUTATION_CSV: (imputation_rows, list(imputation_rows[0])),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    for path, (rows, fields) in output_specs.items():
        path.write_bytes(render_csv(rows, fields))

    full_unknown = (full_na.loc[event_ids] == "U").sum(axis=1)
    full_structural = (full_na.loc[event_ids] == "NA").sum(axis=1)
    full_missing = full_unknown + full_structural

    def count_summary(values: pd.Series) -> dict[str, float | int]:
        return {
            "mean": float(values.mean()),
            "median": float(values.median()),
            "minimum": int(values.min()),
            "maximum": int(values.max()),
        }

    summary = {
        "artifact_type": "hellenistic_statistical_weight_sensitivity",
        "status": "diagnostic_not_active",
        "checkpoint_date": "2026-08-22",
        "baseline_release": "second_pass_v4_583",
        "hellenistic_events": len(event_ids),
        "linked_program_groups": len(groups),
        "linked_event_memberships": sum(len(ids) for ids in groups.values()),
        "candidate_counts": observed_counts,
        "non_numeric_cells_of_hellenistic_97": {
            "combined_unknown_plus_structural_na": count_summary(full_missing),
            "unknown_only": count_summary(full_unknown),
            "structural_na_only": count_summary(full_structural),
            "interpretive_limit": (
                "Unknown and structural N/A are distinct codes; their sum is a "
                "preprocessing diagnostic, not a documentation-quality scale."
            ),
        },
        "scenario_any_material_flags": {
            row["scenario"]: row["any_material_flag"] for row in scenario_rows
        },
        "scenario_eight_axis_or_cluster_material_flags": {
            row["scenario"]: row["eight_axis_or_cluster_material_flag"]
            for row in scenario_rows
        },
        "factor_count_by_core_scenario": {
            row["scenario"]: row["parallel_analysis_factors"]
            for row in scenario_rows[:6]
        },
        "rules": [
            "Every included bounded event receives one row in the equal-event candidate.",
            "Grouped medians and weighting alternatives are diagnostic pseudo-observations only.",
            "No sensitivity result is an automatic inclusion or exclusion vote.",
            "All comparisons are against immutable second_pass_v4_583.",
        ],
    }
    SUMMARY_JSON.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    inputs = {
        "shared_second_pass_pipeline": SECOND_PASS / "12_run_second_pass.py",
        "candidate_builder": V5 / "build_hellenistic_candidates.py",
        "hellenistic_briefs": BRIEFS,
        "hellenistic_family_hypotheses": (
            V5 / "coding" / "hellenistic_family_hypotheses.json"
        ),
        "combined_candidate_family_hypotheses": (
            CANDIDATES / "hellenistic_candidate_family_hypotheses.json"
        ),
        "v4_scores": V4 / "data" / "scores_v2.csv",
        "v4_na_types": V4 / "data" / "na_types_v2.csv",
        "v4_corpus": V4 / "data" / "corpus_v2.json",
        "v4_loadings": V4 / "results" / "loadings_aligned.csv",
        "v4_factor_scores": V4 / "results" / "factor_scores_aligned.csv",
        "v4_k6": V4 / "results" / "clean_k6_assignments.csv",
        "full_manifest": FULL / "candidate_manifest.json",
        "full_scores": FULL / "data" / "scores_v2.csv",
        "full_na_types": FULL / "data" / "na_types_v2.csv",
        "successor_manifest": SUCCESSOR / "candidate_manifest.json",
        "successor_scores": SUCCESSOR / "data" / "scores_v2.csv",
        "successor_na_types": SUCCESSOR / "data" / "na_types_v2.csv",
        "successor_corpus": SUCCESSOR / "data" / "corpus_v2.json",
    }
    outputs = [
        SCENARIOS_CSV,
        FACTORS_CSV,
        WEIGHTING_CSV,
        DOCUMENTATION_CSV,
        IMPUTATION_CSV,
        SUMMARY_JSON,
    ]
    manifest = {
        "status": "reproducible_diagnostic_not_active",
        "generator": str(Path(__file__).resolve().relative_to(ROOT)),
        "generator_sha256": sha256(Path(__file__).resolve()),
        "invocation": [
            "analysis/second_pass/.venv-v5/bin/python",
            "analysis/second_pass/v5/run_hellenistic_sensitivities.py",
        ],
        "runtime": runtime_manifest(),
        "randomness": {
            "complete_normal_horn_seed_base": SEED,
            "complete_normal_horn_draws_per_scenario": N_HORN,
            "kmeans_random_state": 0,
            "kmeans_n_init": 100,
        },
        "horn_null_specification": (
            "complete independent normal matrices; this primary specification "
            "does not replay the observed missingness mask"
        ),
        "input_sha256": {name: sha256(path) for name, path in inputs.items()},
        "output_sha256": {path.name: sha256(path) for path in outputs},
        "report_sha256": sha256(REPORT) if REPORT.exists() else None,
    }
    MANIFEST_JSON.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return summary


def output_paths() -> list[Path]:
    return [
        SCENARIOS_CSV,
        FACTORS_CSV,
        WEIGHTING_CSV,
        DOCUMENTATION_CSV,
        IMPUTATION_CSV,
        SUMMARY_JSON,
        MANIFEST_JSON,
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check",
        action="store_true",
        help="Re-run and fail if any existing output byte changes.",
    )
    args = parser.parse_args()
    before = {path: path.read_bytes() for path in output_paths() if path.exists()}
    summary = build()
    if args.check:
        missing_before = [path for path in output_paths() if path not in before]
        if missing_before:
            raise SystemExit(
                "--check requires existing outputs; missing before rebuild: "
                + ", ".join(str(path) for path in missing_before)
            )
        changed = [path for path, payload in before.items() if path.read_bytes() != payload]
        if changed:
            raise SystemExit(
                "sensitivity rebuild changed bytes: "
                + ", ".join(str(path) for path in changed)
            )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
