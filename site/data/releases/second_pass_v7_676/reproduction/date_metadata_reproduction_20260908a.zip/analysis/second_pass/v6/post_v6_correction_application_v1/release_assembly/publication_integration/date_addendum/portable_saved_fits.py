"""Read a consumer's completed reproduction, never the private research cache.

This adapter changes storage/root binding only. The exported runner requires
the reproduced full scientific result to match the published historical hash.
Checkpoint records remain typed JSON, with identity and payload validation.
"""
from pathlib import Path

from inputs import require
from numerics import ROOT, digest
from resume_cache import json_bytes, pack, parse, unpack
from run_successor import public_result

OLD = ROOT / 'analysis/second_pass/v6/post_v6_correction_application_v1/model_execution_v1/reproduced'


class SavedFits:
    def __init__(self, reader):
        self.reader, self.cache = reader, {}
        state = self.read('RUN_STATE.json')
        manifest = self.read('MANIFEST.json')
        require(state['status'] == 'complete', 'Historical reproduction is incomplete')
        self.binding = state['bindings_sha256']
        require(digest(json_bytes(state['bindings'])) == self.binding,
                'Historical reproduction binding changed')
        require(manifest['checkpointing']['run_bindings_sha256'] == self.binding,
                'Historical run state/manifest disagree')
        require(manifest['output_sha256']['RESULTS.json'] ==
                '91cd3d38aaf3bae80a4d7972c935d020bd48c56e4e78d0cada34104ecd5008f9',
                'Historical result differs; do not relabel numerical drift as exact reproduction')

    def read(self, relative):
        path = OLD / relative
        require(path.is_file() and not path.is_symlink() and
                path.resolve().is_relative_to(OLD.resolve()) and
                not any(p.is_symlink() for p in path.parents if p.is_relative_to(OLD)),
                'Missing/unsafe consumer reproduction file: ' + relative)
        body = path.read_bytes()
        ref = {'path': str(path.relative_to(ROOT)), 'sha256': digest(body)}
        return parse(self.reader.read(ref))

    def fit(self, result):
        identity = (result['matrix_sha256'], result['preprocessing'], result['seed'])
        key = digest(json_bytes({'kind': 'fit', 'identity': pack(identity)}))
        if key not in self.cache:
            record = self.read('resume_items/' + key + '.json')
            require(record['status'] == 'complete' and record['kind'] == 'fit'
                    and record['bindings_sha256'] == self.binding
                    and record['identity'] == pack(identity), 'Consumer fit identity differs')
            require(digest(json_bytes(record['payload'])) == record['payload_sha256'],
                    'Consumer fit payload changed')
            self.cache[key] = unpack(record['payload'])['result']
        fit = self.cache[key]
        require(json_bytes(public_result(fit)) == json_bytes(public_result(result)),
                'Consumer fit differs from the published historical result')
        return fit
