# Main metadata decisions — fourteen qualified definitions

2026-09-06. Ordinary editorial/consumer implementation, not another historical
review. Original proposals are preserved at ae9bc013. Main read all14 row and
proposal pairs,36 source records, the complete403-line validator and complete
COMPATIBILITY.md. Both normal and optimized read-only validation reproduce
the receipt with37 upstream bindings and24 controls. Earlier qualification and
coding readings remain at their own source-bound paths; no new full-source
inspection is claimed by this metadata review.

## Accepted content and families

Accept the bounded definitions, source uses, dependent-witness cautions,
uncertainty and parent/cohort rules, subject to the specific clarification below.
The proposed family reasons follow the established outcome-first codebook,
which main reread; its historical679-row/sample procedure is not a new gate.

| Defined unit | Family | Normalized macroregion |
| --- | --- | --- |
| Ashkelon604 | expulsion_or_flight_without_replacement | WEST_ASIA |
| Tīl-karme555-person placement | state_directed_demographic_remaking | WEST_ASIA |
| Judean597/587–586 program | state_directed_demographic_remaking | WEST_ASIA |
| Sutrium colonial transition | conquest_and_incorporation | EUROPE |
| Nepet colonial transition | conquest_and_incorporation | EUROPE |
| Qin Rang281 | state_directed_demographic_remaking | EAST_ASIA |
| Qin Nanyang280 | state_directed_demographic_remaking | EAST_ASIA |
| Qin Yan-Deng279 | state_directed_demographic_remaking | EAST_ASIA |
| Circeii early-fifth-century takeover | conquest_and_incorporation | EUROPE |
| Egypt639/640–646 | conquest_and_incorporation | NORTH_AFRICA |
| Mutsu720–724 | conquest_and_incorporation | EAST_ASIA |
| Mutsu725 outward transfer | state_directed_demographic_remaking | EAST_ASIA |
| Kitakami774–811 | conquest_and_incorporation | EAST_ASIA |
| Iberia711–c.716 | conquest_and_incorporation | EUROPE |

These are explicit editorial choices using the proposals' per-event locators,
resident/land outcomes and rejected alternatives, not a statistical partition.
Ashkelon's destruction and lost community have no demonstrated immediate
successor population/project use; bounded royal captivity does not turn it
into whole-city resettlement. The six remaking cases are defined by selected
cohort placement/removal. The seven incorporation cases establish territorial
or political control/use without demonstrated durable replacement population;
their unresolved resident outcomes are not rewritten as measured continuity.
Sutrium/Nepet's colonial names and Circeii's garrison do not prove replacement.
No model fit or existing score decided these classifications. Existing two
family holds are not changed. This sidecar itself activates nothing.

The16-category geography vocabulary and territory-centered event exceptions
are established in build_candidate_676_macroregions.py, which main inspected.
The new mappings concern the bounded taken/receiving or removed-population
geography, not actor nationality/capital. Ashkelon's Babylon follow-up and
Judean source/destinations remain within WEST_ASIA; all three Japanese and
Qin placements remain within EAST_ASIA. Egypt and Iberia retain separate
approach geography without treating the conquering army's approach as a
different displaced population. Do not silently map all cross-sea invasions
to MULTIREGIONAL or inherit a retired parent's label without reasoning.

## Consumer distinctions fixed before fits

- Preserve full confidence statements. They are already a supported corpus
  representation, not missing categorical values, family-review confidence,
  documentation weights or a licence to infer unsupported cell values. Main's
  initial concern about an obligatory enum was a hypothesis; the actual
  consumer inspection disproved it. No new confidence class is required.
- Preserve detailed geographic prose. Join a separate complete event-ID
  macroregion crosswalk for normalized-region weighting, including unchanged
  baseline IDs and retained-row corrections. Raw-region-string weighting,
  if retained as an established stress test, must keep that explicit label
  and limitation. Fourteen new descriptions must not masquerade as fourteen
  equal macroregions. No fit is used to choose the crosswalk.
- Circeii start/end stay null; no traditional488 sort proxy is selected for
  this statistical metadata build. Preserve its explicit ancient era. Exclude
  absent/proxy observed dates from continuous-time diagnostics and disclose
  the eligible subset; include the event in the ordinary factor matrix.
  Never substitute zero, a parent midpoint or the modern era. Handle the
  twelve already-null active checkpoint rows by the same explicit rules.
- All14 duration_years remain null. Annual notices, alternative dates,
  discontinuous departure envelopes and administrative/campaign boundaries
  are not measured transport/influx durations. A duration sensitivity needs
  an explicit eligibility/measurand input across the whole roster. A retained
  legacy calendar-envelope stress test must not be described as observed
  historical movement tempo. Numeric equality at start/end is not observed
  one-year migration, and the Judean envelope is not twelve inclusive years
  of continuous deportation. Date-only alternatives cannot change raw cells.
- Source IDs/editions/loci/roles remain separate. Metadata-only KAKEN,
  dissertation-to-book crosswalks and duplicate digital representations are
  not independent historical witnesses. Any legacy reference-count stress
  test stays named as such; source-role detail remains available for reuse.
- Exact event/action IDs control provenance and roster membership. No old
  constructor may silently inherit parent regions, scores, dates or activation.

## Iberia clarification

The operative711–c.716 event boundary is retained. Its *original cohort's*
later legal ratification/aftermath remains eligible for constructs whose
observation horizons require it: specifically Manzano172n16 distinguishes
confirmation of original claimants' holdings from al-Samh's new troops.
Do not backdate later instruments into711–716, but do not use the old blanket
post716 exclusion to discard linked aftermath either. New al-Samh/741 cohorts
remain separate. Record this clarification in derived date/overlap/source-use
limits with explicit before/after provenance; never rewrite the original
proposal or frozen source-review record. The same point is already explicit
in main's Iberia coding reconciliation and source points at0a5cfbd4.

## Derivation and remaining execution

McClintock may prepare main_accepted_projection/ under these directions:
readable spacing in the fourteen descriptions without changing historical
meaning; exact per-ID family/geography/date choices; the Iberia clarification;
and a source/field correction ledger. Keep original proposals and all
unedited fields unchanged and prove the derived projection from those bytes
plus the authored patch ledger. Both activity/display flags remain false.
Main must inspect actual changed values before accepting the projection.
That is ordinary editing and technical verification, not a fresh audit round.

Actual activation waits for the completed candidate: final Iberia coding
inspection, all17 authoritative coding packages, exact raw/NA integration,
metadata/family/program/horizon and overlap inputs, and conditional retirement
of the Qin parent with all three children. Frozen v6 and intermediate v1/v2
are immutable. This record does not certify a fit, promote a release or
publish new cases. Model conclusions and monograph fairness claims await
the already-prescribed complete-candidate comparisons.
