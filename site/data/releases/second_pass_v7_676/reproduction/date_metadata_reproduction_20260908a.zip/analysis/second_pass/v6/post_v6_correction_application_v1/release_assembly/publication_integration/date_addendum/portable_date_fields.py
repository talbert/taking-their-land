from pathlib import Path
TARGET = Path(__file__).resolve().parents[1] / 'prior_metadata_application'
DATE_IDS = {'atlas-canary-la-gomera-revolt-repression', 'prospective-israeli-settlements-west-bank-east-jerusalem'}
DATE_FIELDS = {'start', 'end', 'date_label', 'date_numeric_proxy_used', 'date_numeric_proxy_basis', 'era_bucket_v2'}
