# Exact remaining input interface

This documents the saved adapter, not a new historical gate or a completed
candidate. Main authors the closed integration/acceptance and the whole-roster
joins. Do not populate this interface from the incomplete663 checkpoint or from
the accepted-but-inactive fourteen-row metadata sidecar alone.

## File binding

Every `REF` below is exactly `{"path": "...", "sha256": "64 lowercase hex characters"}`.
Paths may be absolute or repository-relative. They resolve canonically; the
exact bytes are hashed before parsing and checked again before completion.
No absent hash, glob, most-recent-file inference or parent-path default exists.

## Top-level main execution acceptance JSON

Required fields consumed by `load_contract`:

```text
schema: "successor-model-execution-inputs-v1"
status: "MAIN_ACCEPTED_COMPLETE_CANDIDATE"
complete_candidate: true
open_packages: []
main_acceptance_ref: nonempty main acceptance identifier/reference
release_cutoff: nonempty exact release cutoff
baseline_release: "second_pass_v6_675"
candidate_manifest: REF
baseline_manifest: REF
datasets: {baseline: DATASET, successor: DATASET, optional_archive_name: DATASET, ...}
scope: REF to SCOPE JSON below
programs: REF to PROGRAMS JSON below
reference_loadings: REF to frozen named-eight loading CSV
historical_fit_authorized: boolean (must be true only for --execute)
```

The bound candidate manifest must itself have root fields
`complete_candidate: true` and `fit_authorized: true`. These represent main's
complete-candidate readiness, not automatic execution or publication authority.
The separately supplied acceptance SHA-256 binds the entire interface. Existing
partial manifests with false/missing readiness fields remain ineligible even if
renamed. No real acceptance JSON was produced during this preparation.

The reference-loading CSV must have the exact original60 dimension IDs in its
first/index column and eight finite, uniquely named loading columns. These are
axis-alignment references, not family membership or data-selection labels.

## DATASET

```text
event_ids: exact ordered unique score-row ID list
scores: REF to CSV, first column event_id, then original60 ordered dimensions
na_types: REF to CSV with the identical row/column order
corpus: REF to full JSON array of metadata objects, including inactive parents
analysis_metadata: REF to JSON array with exactly one row per event_ids member
```

Score blanks correspond exactly to `U` or `NA` in the sidecar; observed cells
have empty NA-type strings. Finite inherited observations anywhere in [0,4]
are permitted without rounding. -1/-2 sentinels are not the analytical CSV
representation. Accepted recoded/new cells have the stricter scope rules below.
Float spelling such as4.000 is numerically identical to4, not a new change.

For baseline/successor, full corpus IDs must be unique and its boolean
`in_model:true` ID set must exactly equal the score roster. Baseline has675
active rows. Inactive rows are retained separately for overlap dispositions;
they are not inserted into the factor matrix. The full corpus must include
every parent/child named by the complete overlap ledger. Alternative/archive
datasets supply their own explicitly selected, already-coded profiles; they
are analytical inputs and do not acquire active status.

Consumed corpus fields are `event_id`, boolean `in_model`, supplied valid
`era_bucket_v2`, nullable numeric `start`/`end`, and detailed `region` (used only
in the separately named raw-string stress). `date_numeric_proxy_used`, if
present, must agree with the explicit analysis join. Other metadata, including
confidence prose, sources and retained family holds, is not coerced or used
to select rows. The adapter never calls the old era/date/new-event constructor.

Each `analysis_metadata` object has:

```text
event_id: exact ID
normalized_macroregion: one of the established16 categories
date_is_proxy: boolean
continuous_date_eligible: boolean
observed_date_year: finite numeric year when eligible; null otherwise
duration_eligible: boolean
duration_years: finite nonnegative measured value when eligible; null otherwise
duration_measurand: nonempty statement of measurand or unknown-duration reason
observation_horizons: nonempty object of main's operative/aftermath limits
authority_refs: nonempty list of accepted authority references
```

The entire join file is hash-bound; main supplies its substantive assignments.
Eligible continuous dates must be nonproxy and have a finite supplied source
start; absent/proxy rows remain in full-factor analysis. All fourteen new
definitions have duration_eligible:false and duration_years:null. No date
subtraction, parent midpoint, year0 or modern-era fallback is performed.

The existing16 macroregions are CENTRAL_ASIA, CENTRAL_AFRICA, EAST_ASIA,
EAST_AFRICA, EUROPE, LATIN_AMERICA_CARIBBEAN, MULTIREGIONAL, NORTH_AFRICA,
NORTH_AMERICA, NORTH_ASIA, OCEANIA, SOUTH_ASIA, SOUTHEAST_ASIA,
SOUTHERN_AFRICA, WEST_AFRICA and WEST_ASIA. Main's accepted fourteen-ID mapping
is available in the metadata projection, but **both** the frozen-v6 and full
successor joins are still needed for comparable weighting. No new mapping is
inferred here.

## SCOPE JSON

```text
retired_ids: unique IDs, exactly baseline minus successor
new_ids: unique IDs, exactly successor minus baseline
held_ids: unique IDs, none active in successor
overlap_scope_complete: true
parent_child_rulings: [
  {parent_id, child_ids: [...], ruling: "parent_inactive" | "active_nonoverlap",
   authority_refs: nonempty list}, ...
]
reviewed_existing_cells: [
  {event_id, dimension_id, authority_ref: REF to accepted selected coding output}, ...
]
new_definition_authorities: {each_new_id: REF to accepted full coding output, ...}
expected_actual_changed_cells: integer
expected_reviewed_confirmed_cells: integer
```

`reviewed_existing_cells` is the exact, duplicate-free retained-row coding
scope projected from the accepted integration—not a claim that every reviewed
cell changed. Both raw scores and U/NA type differences are compared. Every
changed retained cell must be covered; all uncovered retained cells must remain
equal. Every observed covered cell and every observed new-definition cell must
be one of0/1/2/3/4. Inherited fractions outside that recoding scope remain exact.
Authority files are hash-read; the consumer does not reopen their historical
rationales or rerun raw-journal reconciliation. Their accepted integration and
the candidate/acceptance hashes supply provenance.

Parent membership and current inactive status come from full successor corpus
metadata, not just old/new active matrices. Already-inactive historical parents
are legal references. `parent_inactive` requires an actually inactive parent;
an active parent with any active child requires `active_nonoverlap`. Main's
complete ledger is consumed without dropping inconvenient inactive references.

## PROGRAMS JSON

```text
status: "MAIN_ACCEPTED_PREDECLARED_PROGRAMS_AND_HORIZONS"
authority_bindings: {authority_id: REF, ...}
required_authority_ids: unique complete required authority ID list
instructions: [INSTRUCTION, ...]
```

Each instruction has a unique `id`, a `kind` below, and nonempty `authority_ids`
drawn from the bound authority dictionary. Across instructions these IDs must
cover the complete declared required-authority set. Main projects the existing
cutoff inventory's `batch_wide_actions` and event-specific instructions,
including Assyrian/Roman/B47–49/B50 authorities, into this finite registry.
The runner does not discover a new queue or choose the historical alternatives.

Supported instructions:

| kind | Additional consumed fields |
| --- | --- |
| omission | `drop_ids`; `expected_event_ids` in exact resulting order |
| boundary | `drop_ids`; optional `add:[{dataset: archive_or_baseline_name,event_ids:[...]}]`; `expected_event_ids` |
| metadata_only | `expected_event_ids` equal to successor; optional bound replacement `corpus` and/or `analysis_metadata` |
| weighting | `expected_event_ids` equal to successor; `weight_kind`, `weights:REF`, `seed_offset`, `reason`, `eligibility_measurand_ref:REF` |
| editorial_only | nonempty `reason`; no factor fit or row filter |
| unestimable | nonempty `reason` identifying unavailable independently coded alternative; no fabricated values |

Omission/boundary instructions may also bind replacement `corpus` and/or
`analysis_metadata` arrays covering their exact resulting ID set. Additions
come only from explicitly bound datasets; no averaging, median pseudo-profile
or inherited child score is generated. Expected order is retained successor
order followed by the declared additions. Date/weight-only instructions cannot
drop or add raw rows. Date-only changes cannot change raw/NA values.

Weight kinds are `linked_program_total_one`, `illustrative_upper_bound`, or
`legacy_calendar_envelope_stress_NOT_observed_duration`. A weight file is an
exact event-ID→positive finite weight object. Main supplies the already-declared
vector and bound eligibility/measurand explanation; the runner does not infer
duration from dates or certify the historical meaning of a weight. Program
seed offsets are fixed integers≥10, reserved separately from builtins1/2/3
(era/normalized-region/raw-region). This is seed bookkeeping, not a data cutoff.

No duration weighting is silently added. Missing phase/region coding should
be an `unestimable` instruction; a family-only alternative is `editorial_only`.
Repeated numerical cases may reuse cached fits while all instruction and
authority records remain visible. Distinct historical rows are never collapsed.

## Running only after the blocker is resolved

Read-only validation is `run_successor.py --acceptance PATH
--acceptance-sha256 SHA --check-inputs`. It refuses incomplete inputs before
historical score access. Actual execution additionally requires
`historical_fit_authorized:true`, `--execute`, and `--output` naming a fresh
directory inside model_execution_v1. There is no default acceptance path and
no automatic execution, repair, activation, output overwrite or promotion.

For this handoff only synthetic fixtures were run. The main-authored complete
candidate, full joins and exact program/scope files remain absent dependencies,
not grounds for filling Iberia with unknowns or fitting a partial candidate.
