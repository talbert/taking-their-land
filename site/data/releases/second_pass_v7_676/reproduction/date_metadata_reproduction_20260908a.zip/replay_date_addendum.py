#!/usr/bin/env python3
"""Public export-root launcher. Default: verify inputs and two matrices; no fits.

--execute requires the separately reproduced historical run and performs only
the two-fit addendum. There is no private-project or original-cache fallback.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import platform
import sys

BASE = 'analysis/second_pass/v6/post_v6_correction_application_v1'
PUB = BASE + '/release_assembly/publication_integration'
ADD = PUB + '/date_addendum'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--forbid-root', type=Path, help='Test only: deny reads from the private source project')
    args = parser.parse_args()
    if args.resume and not args.execute:
        parser.error('--resume requires --execute')
    root = Path(__file__).resolve().parent
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    from portable_preflight import validate_export, readonly_guard, require, safe_path, sha
    validate_export(root)
    manifest = json.loads((root / 'DATE_ADDENDUM_EXPORT.json').read_bytes())
    for name, expected in manifest['members_sha256'].items():
        path = root / safe_path(name)
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root)
                and sha(path.read_bytes()) == expected, 'Changed/missing addendum export member: ' + name)
    platform.platform()  # Read-only platform query before the preflight guard.
    if not args.execute:
        readonly_guard(root, args.forbid_root.resolve() if args.forbid_root else None)
    else:
        require(args.forbid_root is None, '--forbid-root is a read-only test option')
    sys.path.insert(0, str(root / ADD))
    spec = importlib.util.spec_from_file_location('portable_date_run', root / ADD / 'portable_date_run.py')
    run = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(run)
    require(run.ROOT == root, 'Wrong numerical root selected')
    if args.execute:
        run.execute(run.prepare(), resume=args.resume)
        return
    # No historical fits/cache/results are necessary for this input preflight.
    def no_fit(*args, **kwargs):
        raise RuntimeError('Numerical estimator/simulation forbidden by input preflight')
    run.Engine._compute = no_fit
    h = run.helpers()
    h.legacy.fit_scores = h.legacy.horn_thresholds = h.subspace.fit_loadings = no_fit
    columns, _ = h.overlap.battery_columns()
    _, datasets, _, _, _, _, reader = run.load_contract(
        root / BASE / 'complete_candidate_v1/complete/ACCEPTANCE.json', run.ACCEPTANCE_SHA, columns)
    app = reader.json({'path': PUB + '/prior_metadata_application/MANIFEST.json', 'sha256': run.APPLICATION_SHA})
    delta = reader.json({'path': PUB + '/prior_metadata_application/DATE_ADDENDUM_INPUTS.json',
                         'sha256': app['output_sha256']['DATE_ADDENDUM_INPUTS.json']})
    data, ids = run.amended(datasets['successor'], delta)
    weighted = run.frame_key(data.scores.fillna(data.scores.median()),
        h.fairness.reciprocal_group_weights(data.corpus['era_bucket_v2']))
    imputed = run.frame_key(h.legacy.era_median_imputation(data.scores, data.corpus['era_bucket_v2']))
    require(weighted == '4b76c6f5caf4c8bfd9dd8a98e90d66da719ce14da285be2dc995a35707c22bd9'
            and imputed == 'f5337e7f01fbb432a0d3d8eb63e36400eadbfe2e3cdd3e1d45cc0f4444351bf1',
            'Amended matrix fingerprint differs')
    require(set(ids) == run.application.DATE_IDS and int(data.analysis.continuous_date_eligible.sum()) == 629
            and int(data.analysis.duration_eligible.sum()) == 0, 'Date scope/eligibility differs')
    reader.unchanged()
    print(json.dumps({'status': 'PORTABLE_DATE_INPUTS_PASS_NO_FITS',
        'input_bindings': len(reader.bindings), 'affected_events': ids,
        'eligible_candidate_onsets': 629, 'measured_durations': 0,
        'amended_matrix_sha256': [weighted, imputed],
        'historical_cache_required_for_this_check': False,
        'network_and_file_writes_forbidden': True}))


if __name__ == '__main__':
    main()
